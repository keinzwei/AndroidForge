# NusaTube 1.1.0 Native SABR

Aplikasi video Android berbahasa Indonesia dengan header dan footer NusaTube, serta mesin pemutaran Native InnerTube + SABR dari basis yang dilampirkan.

## Perubahan

- Logo, header, tombol muat ulang/pencarian, dan kategori mengikuti NusaTube 1.0.6.
- Footer tetap saat menggulir: Beranda, Langganan, Koleksi.
- Kategori Beranda memiliki pencarian video Indonesia dan halaman lanjutan sendiri; Mix mempertahankan rekomendasi aplikasi.
- Nama produk, package kode, kelas, tema, aksi notifikasi, nama ekspor dan identitas launcher menjadi NusaTube.
- Antarmuka Indonesia, wilayah konten ID, subtitle awal Indonesia, serta konteks Native InnerTube/SABR Indonesia.
- Tema awal gelap, langsung ke Beranda, dan pembaruan otomatis upstream dinonaktifkan untuk turunan ini.
- Shorts tetap tersedia dalam konten dan koleksi; footer mengikuti tiga menu NusaTube.

## Build

Gunakan JDK 17 dan Android SDK 35, build-tools 34.0.0. Buat `local.properties` dengan `sdk.dir` sesuai lokasi SDK.

```sh
chmod +x gradlew
./gradlew :app:testNativeEngine :app:assembleFossRelease
```

`assembleFossRelease` menghasilkan APK unsigned jika `release.keystore` tidak tersedia. Untuk rilis bertanda tangan yang bisa memperbarui APK hasil ini, gunakan keystore dari arsip cadangan tanda tangan yang disertakan terpisah, lalu isi `storePassword`, `keyAlias`, dan `keyPassword` di `local.properties`. Jangan unggah berkas rahasia itu ke repository publik.

Package APK: `id.nusatube.nativeclient`, versionCode 100. Package ini terpisah dari NusaTube 1.0.6 sehingga dapat dipasang berdampingan. Minimum Android 8.0/API 26.

Workflow `.github/workflows/native-apk.yml` dapat membangun APK pengujian melalui GitHub Actions.

## Atribusi

Nama aplikasi sudah menjadi NusaTube. Nama asal pada pemberitahuan hak cipta, tautan sumber atribusi, dan lisensi dipertahankan untuk menghormati lisensi komponen. Rincian terdapat dalam `THIRD-PARTY-NOTICES.md` dan `licenses/`. Lisensi distribusi gabungan: AGPL-3.0.
