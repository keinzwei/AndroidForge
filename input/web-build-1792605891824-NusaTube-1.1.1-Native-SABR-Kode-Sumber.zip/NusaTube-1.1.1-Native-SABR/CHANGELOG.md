# Perubahan NusaTube

## 1.1.0 Native SABR — 20 Oktober 2026

- Menggabungkan header/footer NusaTube 1.0.6 dengan basis mesin pemutar Native InnerTube + SABR.
- Mengganti seluruh identitas produk menjadi NusaTube.
- Menjadikan bahasa serta wilayah konten Indonesia sebagai bawaan.
- Menghubungkan kategori dan mempertahankan footer tiga menu saat menggulir.
