# Verifikasi NusaTube 1.1.1 Native SABR

Tanggal: 21 Oktober 2026.

- Build `:app:testNativeEngine :app:assembleFossRelease` berhasil.
- 66 tes lulus; 0 gagal, 0 error, 0 dilewati. Termasuk lima regresi Shorts: URL watch dengan penanda Shorts, URL Shorts, video biasa berdurasi pendek, video biasa berdurasi panjang, dan durasi belum diketahui.
- Pemeriksaan sintaks: 491 berkas Kotlin, 0 error sintaks.
- APK rilis memakai minifikasi R8 dan tidak debuggable.
- Label `NusaTube`; package `id.nusatube.nativeclient`; versi `1.1.1-native-sabr`; versionCode 101; minimum Android 8.0/API 26.
- Tanda tangan APK terverifikasi dan sertifikat sama dengan cadangan 1.1.0. Alignment APK terverifikasi dengan build-tools Android.
- 62 berkas sumber utama mesin Native InnerTube/SABR identik dengan sumber 1.1.0 yang diunggah.
- Source di ZIP diperiksa identik dengan sumber pembuat APK. Keystore dan kata sandi tidak disertakan dalam ZIP sumber.

## Batas pemeriksaan

Belum diuji di emulator atau HP fisik. Tes protokol menggunakan fixture dan tidak membuktikan ketersediaan semua video pada jaringan pengguna. Suite UI lama dari basis tetap disertakan, tetapi tidak dijalankan karena memakai API lama.

## Sidik berkas

- SHA-256 APK: `6a72421df66a3b955d0c66ef9684538332df42169ca56969faab149f302c9d7a`.
- SHA-256 sertifikat: `a70f5393c14f2fc47b232283a7547f5627a9dc3792270a93aaf117baedfe48bc`.
