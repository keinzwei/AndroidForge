package id.nusatube.nativeapp.nativeflow.network

import id.nusatube.nativeapp.innertube.YouTube
import okhttp3.OkHttpClient

/** Adapts the ported clients to NusaTube's existing proxy preference. */
object AppProxyManager {
    fun currentSignature(): String = YouTube.proxy?.toString().orEmpty()

    fun applyTo(builder: OkHttpClient.Builder): OkHttpClient.Builder =
        builder.proxy(YouTube.proxy)
}
