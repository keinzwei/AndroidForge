package id.nusatube.nativeapp.innertube.pages

import id.nusatube.nativeapp.innertube.models.YTItem

data class ArtistItemsContinuationPage(
    val items: List<YTItem>,
    val continuation: String?,
)
