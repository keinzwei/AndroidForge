package id.nusatube.nativeapp.innertube.pages

import id.nusatube.nativeapp.innertube.models.AlbumItem

data class ExplorePage(
    val newReleaseAlbums: List<AlbumItem>,
    val moodAndGenres: List<MoodAndGenres.Item>,
)
