package id.nusatube.nativeapp.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra("type") ?: return
        
        when (type) {
            "bedtime" -> {
                NotificationHelper.showReminderNotification(
                    context,
                    "Sudah waktunya tidur! 😴",
                    "Saatnya beristirahat sesuai jadwal tidur Anda."
                )
            }
            "break" -> {
                 NotificationHelper.showReminderNotification(
                    context,
                    "Saatnya beristirahat! ☕",
                    "Anda sudah cukup lama menonton."
                )
                
                // Reschedule if it's a repeating break reminder
                val frequency = intent.getIntExtra("frequency", -1)
                if (frequency > 0) {
                    ReminderManager.scheduleBreakReminder(context, frequency)
                }
            }
        }
    }
}
