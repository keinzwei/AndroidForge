package id.nusatube.nativeapp.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import id.nusatube.nativeapp.data.local.PlayerPreferences
import id.nusatube.nativeapp.data.local.VideoQuality
import kotlinx.coroutines.launch

@Composable
fun VideoQualitySettingsScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val playerPreferences = remember { PlayerPreferences(context) }
    
    val wifiQuality by playerPreferences.defaultQualityWifi.collectAsState(initial = VideoQuality.Q_1080p)
    val cellularQuality by playerPreferences.defaultQualityCellular.collectAsState(initial = VideoQuality.Q_480p)
    
    val qualities = listOf(
        VideoQuality.AUTO,
        VideoQuality.Q_2160p,
        VideoQuality.Q_1440p,
        VideoQuality.Q_1080p,
        VideoQuality.Q_720p,
        VideoQuality.Q_480p,
        VideoQuality.Q_360p,
        VideoQuality.Q_240p,
        VideoQuality.Q_144p
    )

    Scaffold(
        topBar = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.background
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, androidx.compose.ui.res.stringResource(id.nusatube.nativeapp.R.string.btn_back))
                    }
                    Text(
                        text = androidx.compose.ui.res.stringResource(id.nusatube.nativeapp.R.string.video_quality_title),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                Text(
                    text = androidx.compose.ui.res.stringResource(id.nusatube.nativeapp.R.string.video_quality_warning),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
            
            // Wi-Fi Section
            item {
                SectionHeader(text = androidx.compose.ui.res.stringResource(id.nusatube.nativeapp.R.string.video_quality_wifi_header))
            }
            
            item {
                SettingsGroup {
                    qualities.forEachIndexed { index, quality ->
                        QualitySelectionItem(
                            quality = quality,
                            isSelected = wifiQuality == quality,
                            onClick = { coroutineScope.launch { playerPreferences.setDefaultQualityWifi(quality) } }
                        )
                        if (index < qualities.size - 1) {
                            HorizontalDivider(Modifier.padding(start = 56.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        }
                    }
                }
            }
            
            // Cellular Section
            item {
                SectionHeader(text = androidx.compose.ui.res.stringResource(id.nusatube.nativeapp.R.string.video_quality_cellular_header))
            }
            
            item {
                SettingsGroup {
                    qualities.forEachIndexed { index, quality ->
                        QualitySelectionItem(
                            quality = quality,
                            isSelected = cellularQuality == quality,
                            onClick = { coroutineScope.launch { playerPreferences.setDefaultQualityCellular(quality) } }
                        )
                         if (index < qualities.size - 1) {
                            HorizontalDivider(Modifier.padding(start = 56.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QualitySelectionItem(
    quality: VideoQuality,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Radio button look
        RadioButton(
            selected = isSelected,
            onClick = null // Handled by row click
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Text(
            text = androidx.compose.ui.res.stringResource(getQualityNameRes(quality)),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

private fun getQualityNameRes(quality: VideoQuality): Int {
    return when (quality) {
        VideoQuality.AUTO -> id.nusatube.nativeapp.R.string.quality_auto
        VideoQuality.Q_144p -> id.nusatube.nativeapp.R.string.quality_144p
        VideoQuality.Q_240p -> id.nusatube.nativeapp.R.string.quality_240p
        VideoQuality.Q_360p -> id.nusatube.nativeapp.R.string.quality_360p
        VideoQuality.Q_480p -> id.nusatube.nativeapp.R.string.quality_480p
        VideoQuality.Q_720p -> id.nusatube.nativeapp.R.string.quality_720p_hd
        VideoQuality.Q_1080p -> id.nusatube.nativeapp.R.string.quality_1080p_full_hd
        VideoQuality.Q_1440p -> id.nusatube.nativeapp.R.string.quality_1440p_qhd
        VideoQuality.Q_2160p -> id.nusatube.nativeapp.R.string.quality_2160p_4k
    }
}
