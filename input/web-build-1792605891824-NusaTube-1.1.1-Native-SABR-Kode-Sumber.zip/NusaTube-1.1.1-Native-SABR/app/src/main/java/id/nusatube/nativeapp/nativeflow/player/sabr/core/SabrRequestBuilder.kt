// SPDX-License-Identifier: GPL-3.0-only
// Ported from Flow v3.0.0 (A-EDev), 9b592728f96de4efdb3b0041331bb3b44bfe054c.
package id.nusatube.nativeapp.nativeflow.player.sabr.core

import android.util.Log
import id.nusatube.nativeapp.nativeflow.player.sabr.proto.ClientAbrState
import id.nusatube.nativeapp.nativeflow.player.sabr.proto.ClientInfo
import id.nusatube.nativeapp.nativeflow.player.sabr.proto.StreamerContext
import id.nusatube.nativeapp.nativeflow.player.sabr.proto.VideoPlaybackAbrRequest

object SabrRequestBuilder {
    private const val TAG = "SabrRequestBuilder"

    private const val LOG_REQUEST_SEQUENCE_LIMIT = 3

    fun buildInitialRequest(state: SabrSessionState): ByteArray = buildRequest(state, isInitial = true)

    fun buildFollowUpRequest(state: SabrSessionState): ByteArray = buildRequest(state, isInitial = false)

    private fun buildRequest(
        state: SabrSessionState,
        isInitial: Boolean,
    ): ByteArray {
        state.requestSequence++

        val playheadMs = state.playheadPositionMs
        val selectionUnacknowledged = state.initializedFormats.isEmpty()
        val selected =
            listOfNotNull(
                state.selectedVideoFormatId.takeIf {
                    state.selectedVideoItag > 0 && (selectionUnacknowledged || state.selectedVideoItag in state.initializedFormats)
                },
                state.selectedAudioFormatId.takeIf {
                    state.selectedAudioItag > 0 && (selectionUnacknowledged || state.selectedAudioItag in state.initializedFormats)
                },
            )
        val buffered = if (isInitial) emptyList() else (state.videoBufferedRanges + state.audioBufferedRanges)
        val timeSinceSeekMs =
            if (state.lastSeekAtMs > 0) {
                (System.currentTimeMillis() - state.lastSeekAtMs).coerceAtLeast(0)
            } else {
                0L
            }

        val includeFollowUpState = playheadMs > 0 || buffered.isNotEmpty()

        val effectiveResolution =
            (if (state.stickyResolution > 0) state.stickyResolution else state.selectedVideoHeight)
                .coerceAtLeast(360)

        if (state.requestSequence <= LOG_REQUEST_SEQUENCE_LIMIT) {
            Log.d(
                TAG,
                "req#${state.requestSequence} initial=$isInitial " +
                    "selectedItags=${selected.map { it.itag }} initialized=${state.initializedFormats} " +
                    "audioXtags='${state.selectedAudioXtags}' " +
                    "prefAudio=${state.selectedAudioItag}/${state.selectedAudioLmt} " +
                    "prefVideo=${state.selectedVideoItag}/${state.selectedVideoLmt} " +
                    "track='${state.audioTrackId}' enabledTracks=${state.enabledTrackTypes} " +
                    "playhead=${playheadMs}ms buffered=${buffered.size} sticky=$effectiveResolution",
            )
        }

        val request =
            VideoPlaybackAbrRequest(
                clientAbrState =
                    ClientAbrState(
                        playerTimeMs = playheadMs,
                        bandwidthEstimateBps = if (includeFollowUpState) state.estimatedBandwidthBps else 0L,
                        viewportWidthPx = if (includeFollowUpState) state.screenWidthPixels else 0,
                        viewportHeightPx = if (includeFollowUpState) state.screenHeightPixels else 0,
                        lastManualSelectedResolution = if (state.stickyResolution > 0) state.stickyResolution else 0,
                        stickyResolution = effectiveResolution,
                        timeSinceLastSeekMs = timeSinceSeekMs,
                        visibility = state.visibility,
                        playbackRate = state.playbackRate,
                        enabledTrackTypesBitfield = state.enabledTrackTypes,
                        audioTrackId = state.audioTrackId,
                    ),
                selectedFormatIds = selected,
                bufferedRanges = buffered,
                playerTimeMs = playheadMs,
                videoPlaybackUstreamerConfig = state.ustreamerConfig,
                preferredAudioFormatIds = listOfNotNull(state.selectedAudioFormatId.takeIf { state.selectedAudioItag > 0 }),
                preferredVideoFormatIds = listOfNotNull(state.selectedVideoFormatId.takeIf { state.selectedVideoItag > 0 }),
                streamerContext =
                    StreamerContext(
                        clientInfo =
                            ClientInfo(
                                clientName = state.clientNameId,
                                clientVersion = state.clientVersion,
                                osName = state.osName,
                                osVersion = state.osVersion,
                            ),
                        poToken = state.poTokenBytes(),
                        playbackCookie = state.playbackCookie,
                        sabrContexts = state.activeSabrContexts(),
                        unsentSabrContextTypes = state.unsentSabrContextTypes(),
                    ),
            )
        return request.encode()
    }
}
