// SPDX-License-Identifier: GPL-3.0-only
// Ported from Flow v3.0.0 (A-EDev), 9b592728f96de4efdb3b0041331bb3b44bfe054c.
package id.nusatube.nativeapp.nativeflow.player.sabr.core

import okio.ByteString.Companion.decodeBase64

object SabrBase64 {
    fun decode(value: String): ByteArray? {
        val normalized = value
            .filterNot(Char::isWhitespace)
            .replace('-', '+')
            .replace('_', '/')
            .replace('.', '=')
        if (normalized.isEmpty() || normalized.length % 4 == 1) return null

        val padded = normalized + "=".repeat((4 - normalized.length % 4) % 4)
        return padded.decodeBase64()?.toByteArray()
    }
}
