package id.nusatube.nativeapp.ui.screens.music

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import id.nusatube.nativeapp.data.local.PlaylistRepository
import id.nusatube.nativeapp.data.local.entity.VideoEntity
import id.nusatube.nativeapp.data.model.Video
import id.nusatube.nativeapp.data.music.DownloadManager
import id.nusatube.nativeapp.data.music.YouTubeMusicService
import id.nusatube.nativeapp.data.repository.YouTubeRepository
import id.nusatube.nativeapp.ui.screens.playlists.PlaylistInfo
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject

@HiltViewModel
class MusicPlaylistsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val playlistRepository: PlaylistRepository,
    private val downloadManager: DownloadManager,
    private val youTubeRepository: YouTubeRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(MusicPlaylistsUiState())
    val uiState: StateFlow<MusicPlaylistsUiState> = _uiState.asStateFlow()

    private val isEnrichingMusic = AtomicBoolean(false)

    init {
        loadPlaylists()
        enrichMusicPlaylistStubs()
    }

    /**
     * Background-enriches any imported music playlist stubs (videos with empty title).
     * Mirrors the lazy enrichment that PlaylistDetailScreen does, but runs proactively
     * so the music library shows proper titles/thumbnails without needing to open each playlist.
     */
    fun enrichMusicPlaylistStubs() {
        if (!isEnrichingMusic.compareAndSet(false, true)) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val db = id.nusatube.nativeapp.data.local.AppDatabase.getDatabase(context)
                val videoDao = db.videoDao()
                val playlistDao = db.playlistDao()
                val stubs = playlistDao.getMusicPlaylistStubVideos()
                if (stubs.isEmpty()) return@launch
                Log.d("MusicPlaylistsVM", "Enriching ${stubs.size} music playlist stubs")
                stubs.chunked(5).forEach { chunk ->
                    chunk.forEach { stub ->
                        try {
                            val video = youTubeRepository.getVideo(stub.id) ?: return@forEach
                            val e = VideoEntity.fromDomain(video)
                            videoDao.insertVideoOrIgnore(e)
                            videoDao.updateVideoMetadata(
                                id = e.id,
                                title = e.title,
                                channelName = e.channelName,
                                channelId = e.channelId,
                                thumbnailUrl = e.thumbnailUrl,
                                duration = e.duration,
                                viewCount = e.viewCount,
                                uploadDate = e.uploadDate,
                                description = e.description,
                                channelThumbnailUrl = e.channelThumbnailUrl
                            )
                        } catch (e: Exception) {
                            Log.w("MusicPlaylistsVM", "Failed to enrich stub ${stub.id}", e)
                        }
                    }
                    delay(300L)
                }
            } catch (e: Exception) {
                Log.e("MusicPlaylistsVM", "enrichMusicPlaylistStubs failed", e)
            } finally {
                isEnrichingMusic.set(false)
            }
        }
    }

    private fun loadPlaylists() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            launch {
                playlistRepository.getUserCreatedMusicPlaylistsFlow().collect { playlists ->
                    _uiState.update { it.copy(playlists = playlists, isLoading = false) }
                }
            }
            launch {
                playlistRepository.getSavedMusicPlaylistsFlow().collect { saved ->
                    _uiState.update { it.copy(savedPlaylists = saved) }
                }
            }
        }
    }

    fun createPlaylist(name: String, description: String, isPrivate: Boolean) {
        viewModelScope.launch {
            val id = UUID.randomUUID().toString()
            playlistRepository.createPlaylist(
                playlistId = id,
                name = name,
                description = description,
                isPrivate = isPrivate,
                isMusic = true
            )
        }
    }

    fun deletePlaylist(playlistId: String) {
        viewModelScope.launch {
            playlistRepository.deletePlaylist(playlistId)
            Toast.makeText(context, "Daftar putar dihapus", Toast.LENGTH_SHORT).show()
        }
    }

    fun renamePlaylist(playlistId: String, newName: String) {
        viewModelScope.launch {
            playlistRepository.updatePlaylistName(playlistId, newName)
            Toast.makeText(context, "Nama daftar putar diganti", Toast.LENGTH_SHORT).show()
        }
    }

    private val _playlistDownloadProgress = MutableStateFlow<Float>(0f)
    val playlistDownloadProgress = _playlistDownloadProgress.asStateFlow()

    private val _currentDownloadingTrack = MutableStateFlow<String?>(null)
    val currentDownloadingTrack = _currentDownloadingTrack.asStateFlow()

    private val _isDownloadingPlaylist = MutableStateFlow(false)
    val isDownloadingPlaylist = _isDownloadingPlaylist.asStateFlow()

    fun downloadPlaylist(playlist: PlaylistInfo) {
        viewModelScope.launch {
            if (_isDownloadingPlaylist.value) return@launch

            _isDownloadingPlaylist.value = true
            Toast.makeText(context, "Memulai unduhan ${playlist.name}…", Toast.LENGTH_SHORT).show()
            
            try {
                val videos = playlistRepository.getPlaylistVideosFlow(playlist.id).first()
                val totalTracks = videos.size
                
                if (totalTracks == 0) {
                     Toast.makeText(context, "Daftar putar kosong", Toast.LENGTH_SHORT).show()
                     _isDownloadingPlaylist.value = false
                     return@launch
                }

                var successCount = 0
                var processedCount = 0

                videos.forEach { video ->
                    _currentDownloadingTrack.value = video.title
                    
                    try {
                        val musicTrack = MusicTrack(
                            videoId = video.id,
                            title = video.title,
                            artist = video.channelName,
                            thumbnailUrl = video.thumbnailUrl,
                            duration = video.duration,
                            sourceUrl = ""
                        )
                        
                        val result = downloadManager.downloadTrack(musicTrack)
                        if (result.isSuccess) successCount++
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    
                    processedCount++
                    _playlistDownloadProgress.value = processedCount.toFloat() / totalTracks
                }
                
                if (successCount > 0) {
                    Toast.makeText(context, "$successCount lagu dari ${playlist.name} berhasil diunduh", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "Daftar putar tidak dapat diunduh", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("MusicViewModel", "Daftar putar tidak dapat diunduh", e)
                Toast.makeText(context, "Daftar putar tidak dapat diunduh", Toast.LENGTH_SHORT).show()
            } finally {
                 _isDownloadingPlaylist.value = false
                 _currentDownloadingTrack.value = null
                 _playlistDownloadProgress.value = 0f
            }
        }
    }

    fun downloadPlaylistTracks(playlistDetails: PlaylistDetails) {
         viewModelScope.launch {
            if (_isDownloadingPlaylist.value) return@launch

            _isDownloadingPlaylist.value = true
            Toast.makeText(context, "Memulai unduhan ${playlistDetails.title}…", Toast.LENGTH_SHORT).show()
            
            try {
                val tracks = playlistDetails.tracks
                val totalTracks = tracks.size

                if (totalTracks == 0) {
                     _isDownloadingPlaylist.value = false
                     return@launch
                }

                var successCount = 0
                val processedCount = java.util.concurrent.atomic.AtomicInteger(0)
                
                val semaphore = kotlinx.coroutines.sync.Semaphore(3)
                
                tracks.map { track ->
                    async {
                        val isSuccess = semaphore.withPermit {
                            _currentDownloadingTrack.value = track.title
                            var currentTrack = track
                            
                            try {
                                if (currentTrack.duration == 0) {
                                    try {
                                        val duration = YouTubeMusicService.fetchVideoDuration(track.videoId)
                                        if (duration > 0) {
                                            currentTrack = currentTrack.copy(duration = duration)
                                        }
                                    } catch (e: Exception) {
                                    }
                                }

                                val result = downloadManager.downloadTrack(currentTrack)
                                return@withPermit result.isSuccess
                            } catch (e: Exception) {
                                Log.e("MusicViewModel", "Failed to download track ${track.title}", e)
                            }
                            false
                        }
                        
                        val currentProcessed = processedCount.incrementAndGet()
                        _playlistDownloadProgress.value = currentProcessed.toFloat() / totalTracks
                        
                        isSuccess
                    }
                }.awaitAll().count { it }
                
                successCount = tracks.size 

                
                if (successCount > 0) {
                    Toast.makeText(context, "$successCount lagu berhasil diunduh", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                 Log.e("MusicViewModel", "Error downloading playlist details", e)
                 Toast.makeText(context, "Daftar putar tidak dapat diunduh", Toast.LENGTH_SHORT).show()
            } finally {
                 _isDownloadingPlaylist.value = false
                 _currentDownloadingTrack.value = null
                 _playlistDownloadProgress.value = 0f
            }
        }
    }

    // ── Track search (used on user playlists) ─────────────────────────────────

    private val _trackSearchResults = MutableStateFlow<List<MusicTrack>>(emptyList())
    val trackSearchResults = _trackSearchResults.asStateFlow()

    private val _isSearchingTracks = MutableStateFlow(false)
    val isSearchingTracks = _isSearchingTracks.asStateFlow()

    private val _addedTrackIds = MutableStateFlow<Set<String>>(emptySet())
    val addedTrackIds = _addedTrackIds.asStateFlow()

    private val _locallyAddedTracks = MutableStateFlow<List<MusicTrack>>(emptyList())
    val locallyAddedTracks = _locallyAddedTracks.asStateFlow()

    fun searchTracks(query: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _isSearchingTracks.value = true
            try {
                val results = YouTubeMusicService.searchMusic(query, limit = 30)
                _trackSearchResults.value = results
            } catch (e: Exception) {
                Log.e("MusicPlaylistsVM", "searchTracks failed", e)
                _trackSearchResults.value = emptyList()
            } finally {
                _isSearchingTracks.value = false
            }
        }
    }

    fun addTrackToPlaylist(playlistId: String, track: MusicTrack) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val video = Video(
                    id = track.videoId,
                    title = track.title,
                    channelName = track.artist,
                    channelId = track.channelId,
                    thumbnailUrl = track.thumbnailUrl,
                    duration = track.duration,
                    viewCount = 0L,
                    uploadDate = "",
                    timestamp = System.currentTimeMillis(),
                    description = track.album,
                    isMusic = true
                )
                playlistRepository.addVideoToPlaylist(playlistId, video)
                _addedTrackIds.update { it + track.videoId }
                _locallyAddedTracks.update { it + track }
                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Ditambahkan ke daftar putar", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("MusicPlaylistsVM", "addTrackToPlaylist failed", e)
                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Lagu tidak dapat ditambahkan", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun removeTrackFromPlaylist(playlistId: String, videoId: String) {
        viewModelScope.launch {
            try {
                playlistRepository.removeVideoFromPlaylist(playlistId, videoId)
                
                _addedTrackIds.update { it - videoId }
                _locallyAddedTracks.update { list -> list.filter { it.videoId != videoId } }
                
                Toast.makeText(context, "Dihapus dari daftar putar", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Log.e("MusicPlaylistsVM", "removeTrackFromPlaylist failed", e)
                Toast.makeText(context, "Lagu tidak dapat dihapus", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun clearTrackSearch() {
        _trackSearchResults.value = emptyList()
        _addedTrackIds.value = emptySet()
        _locallyAddedTracks.value = emptyList()
    }

    // ── Save/unsave external music playlists to library ───────────────────────

    private val _isSavedPlaylist = MutableStateFlow(false)
    val isSavedPlaylist = _isSavedPlaylist.asStateFlow()

    fun checkIfPlaylistSaved(playlistId: String) {
        viewModelScope.launch {
            _isSavedPlaylist.value = playlistRepository.isExternalPlaylistSaved(playlistId)
        }
    }

    fun savePlaylistToLibrary(details: PlaylistDetails) {
        viewModelScope.launch {
            try {
                playlistRepository.saveExternalMusicPlaylist(
                    id = details.id,
                    name = details.title,
                    description = details.description ?: "",
                    thumbnailUrl = details.thumbnailUrl
                )
                details.tracks.forEach { track ->
                    val video = id.nusatube.nativeapp.data.model.Video(
                        id = track.videoId,
                        title = track.title,
                        channelName = track.artist,
                        channelId = track.channelId,
                        thumbnailUrl = track.thumbnailUrl,
                        duration = track.duration,
                        viewCount = track.views,
                        uploadDate = "",
                        isMusic = true
                    )
                    playlistRepository.addVideoToPlaylist(details.id, video)
                }
                _isSavedPlaylist.value = true
                Toast.makeText(context, "Daftar putar disimpan ke koleksi musik Anda", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Log.e("MusicPlaylistsVM", "savePlaylistToLibrary failed", e)
                Toast.makeText(context, "Daftar putar tidak dapat disimpan", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun unsavePlaylistFromLibrary(playlistId: String) {
        viewModelScope.launch {
            try {
                playlistRepository.unsaveExternalPlaylist(playlistId)
                _isSavedPlaylist.value = false
                Toast.makeText(context, "Daftar putar dihapus dari koleksi", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Log.e("MusicPlaylistsVM", "unsavePlaylistFromLibrary failed", e)
            }
        }
    }

    // ── Merge external playlist into a local user playlist ────────────────────

    val userCreatedMusicPlaylists: StateFlow<List<PlaylistInfo>> =
        playlistRepository.getUserCreatedMusicPlaylistsFlow()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    fun mergeTracksIntoPlaylist(targetPlaylistId: String, tracks: List<MusicTrack>) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val videos = tracks.map { track ->
                    Video(
                        id = track.videoId,
                        title = track.title,
                        channelName = track.artist,
                        channelId = track.channelId,
                        thumbnailUrl = track.thumbnailUrl,
                        duration = track.duration,
                        viewCount = track.views,
                        uploadDate = "",
                        isMusic = true
                    )
                }
                playlistRepository.addVideosToPlaylist(targetPlaylistId, videos)
                val targetInfo = playlistRepository.getPlaylistInfo(targetPlaylistId)
                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        context.getString(
                            id.nusatube.nativeapp.R.string.merge_playlist_success,
                            tracks.size,
                            targetInfo?.name ?: ""
                        ),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                Log.e("MusicPlaylistsVM", "mergeTracksIntoPlaylist failed", e)
                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Daftar putar tidak dapat digabungkan", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

data class MusicPlaylistsUiState(
    val playlists: List<PlaylistInfo> = emptyList(),
    val savedPlaylists: List<PlaylistInfo> = emptyList(),
    val isLoading: Boolean = false
)
