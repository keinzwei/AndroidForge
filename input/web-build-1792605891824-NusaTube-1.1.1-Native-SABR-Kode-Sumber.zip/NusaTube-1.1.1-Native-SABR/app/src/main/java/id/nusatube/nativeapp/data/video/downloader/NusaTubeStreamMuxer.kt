package id.nusatube.nativeapp.data.video.downloader

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.util.Log
import java.io.File
import java.nio.ByteBuffer

object NusaTubeStreamMuxer {
    private const val TAG = "NusaTubeStreamMuxer"
    private const val BUFFER_SIZE = 8 * 1024 * 1024  // 8 MB — handles large frames at 4K/8K

    /**
     * Muxes video and audio streams into a single MP4 file.
     * @param videoPath Path to the temporary video file
     * @param audioPath Path to the temporary audio file
     * @param outputPath Path where the final video should be saved
     * @param onProgress Optional callback with progress (0..1)
     * @return true if successful, false otherwise
     */
    fun mux(
        videoPath: String,
        audioPath: String,
        outputPath: String,
        onProgress: ((Float) -> Unit)? = null
    ): Boolean {
        var videoExtractor: MediaExtractor? = null
        var audioExtractor: MediaExtractor? = null
        var muxer: MediaMuxer? = null

        try {
            val vf = File(videoPath)
            val af = File(audioPath)
            if (!vf.exists() || vf.length() == 0L) {
                Log.e(TAG, "Video tmp file missing or empty: $videoPath (size=${vf.length()})")
                return false
            }
            if (!af.exists() || af.length() == 0L) {
                Log.e(TAG, "Audio tmp file missing or empty: $audioPath (size=${af.length()})")
                return false
            }
            Log.d(TAG, "Muxing: video=${vf.length()} bytes, audio=${af.length()} bytes -> $outputPath")

            videoExtractor = MediaExtractor().apply { setDataSource(videoPath) }
            audioExtractor = MediaExtractor().apply { setDataSource(audioPath) }

            // Ensure output directory exists
            File(outputPath).parentFile?.mkdirs()

            val videoTrackIndex = selectTrack(videoExtractor, "video/")
            if (videoTrackIndex < 0) {
                Log.e(TAG, "No video track found in $videoPath")
                return false
            }
            videoExtractor.selectTrack(videoTrackIndex)
            val videoFormat = videoExtractor.getTrackFormat(videoTrackIndex)
            val videoMime = videoFormat.getString(MediaFormat.KEY_MIME) ?: ""

            val useWebM = videoMime.contains("vp9", ignoreCase = true) ||
                          videoMime.contains("vp8", ignoreCase = true) ||
                          videoMime.contains("vp09", ignoreCase = true)
            val isAv1   = videoMime.contains("av01", ignoreCase = true)

            val audioTrackIndex = selectTrack(audioExtractor, "audio/")
            if (audioTrackIndex < 0) {
                Log.e(TAG, "No audio track found in $audioPath")
                return false
            }
            audioExtractor.selectTrack(audioTrackIndex)
            val audioFormat = audioExtractor.getTrackFormat(audioTrackIndex)
            val audioMime = audioFormat.getString(MediaFormat.KEY_MIME) ?: ""

            val isOpusOrVorbisAudio = audioMime.contains("opus", ignoreCase = true) ||
                                      audioMime.contains("vorbis", ignoreCase = true)

            // ── AV1 and VP9/VP8 routing → NusaTubeMkvMuxer ───────────────────────────────
            // AV1 requires MKV on API < 34. VP9/VP8 routes here too because Android's
            // MediaMuxer WebM implementation is significantly slower than our Matroska writer
            // for the same data, and MKV (Matroska superset of WebM) plays fine in ExoPlayer.
            if (isAv1 || useWebM) {
                Log.d(TAG, "${if (isAv1) "AV1" else "VP9/VP8"}: delegating to NusaTubeMkvMuxer (API=${Build.VERSION.SDK_INT}, audio=$audioMime)")
                return NusaTubeMkvMuxer.mux(videoPath, audioPath, outputPath)
            }

            if (!useWebM && !isAv1 && isOpusOrVorbisAudio) {
                Log.e(TAG, "INCOMPATIBLE audio codec for MP4 container: '$audioMime'. " +
                    "Require AAC (audio/mp4a-latm) for H264/H265/HEVC video. " +
                    "Audio path: $audioPath")
                return false
            }

            val muxerFormat = if (useWebM)
                MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM
            else
                MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4

            Log.d(TAG, "Video codec: $videoMime → ${if (useWebM) "WebM" else "MPEG-4"} container")
            muxer = MediaMuxer(outputPath, muxerFormat)
            val muxerVideoTrack = muxer.addTrack(videoFormat)

            val muxerAudioTrack = muxer.addTrack(audioFormat)

            muxer.start()

            val buffer = ByteBuffer.allocate(BUFFER_SIZE)
            val bufferInfo = MediaCodec.BufferInfo()

            // Get durations for progress calc
            val videoDuration = videoFormat.getLongOrDefault(MediaFormat.KEY_DURATION, 0L)
            val audioDuration = audioFormat.getLongOrDefault(MediaFormat.KEY_DURATION, 0L)
            val totalDuration = maxOf(videoDuration, audioDuration)

            // Copy video samples
            copySamples(videoExtractor, muxer, muxerVideoTrack, buffer, bufferInfo) { timeUs ->
                if (totalDuration > 0) {
                    onProgress?.invoke(timeUs.toFloat() / totalDuration / 2f) // 0..0.5
                }
            }

            // Copy audio samples
            copySamples(audioExtractor, muxer, muxerAudioTrack, buffer, bufferInfo) { timeUs ->
                if (totalDuration > 0) {
                    onProgress?.invoke(0.5f + timeUs.toFloat() / totalDuration / 2f)
                }
            }

            muxer.stop()
            onProgress?.invoke(1f)
            Log.d(TAG, "Muxing successful: $outputPath (${File(outputPath).length()} bytes)")
            return true

        } catch (e: Exception) {
            Log.e(TAG, "Muxing failed", e)
            try {
                File(outputPath).takeIf { it.exists() }?.delete()
            } catch (cleanupErr: Exception) {
                Log.w(TAG, "Failed to clean up partial output", cleanupErr)
            }
            return false
        } finally {
            try { videoExtractor?.release() } catch (_: Exception) {}
            try { audioExtractor?.release() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }

    /**
     * Extracts just the audio from a video file (no transcoding — raw copy).
     * Useful for audio-only downloads from a combined source.
     */
    fun extractAudio(inputPath: String, outputPath: String): Boolean {
        var extractor: MediaExtractor? = null
        var muxer: MediaMuxer? = null

        try {
            extractor = MediaExtractor().apply { setDataSource(inputPath) }

            val audioTrackIndex = selectTrack(extractor, "audio/")
            if (audioTrackIndex < 0) {
                Log.e(TAG, "No audio track found in $inputPath")
                return false
            }
            extractor.selectTrack(audioTrackIndex)
            val audioFormat = extractor.getTrackFormat(audioTrackIndex)

            File(outputPath).parentFile?.mkdirs()
            muxer = MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerTrack = muxer.addTrack(audioFormat)
            muxer.start()

            val buffer = ByteBuffer.allocate(BUFFER_SIZE)
            val bufferInfo = MediaCodec.BufferInfo()
            copySamples(extractor, muxer, muxerTrack, buffer, bufferInfo)

            muxer.stop()
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Audio extraction failed", e)
            try { File(outputPath).takeIf { it.exists() }?.delete() } catch (_: Exception) {}
            return false
        } finally {
            try { extractor?.release() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }

    private fun selectTrack(extractor: MediaExtractor, mimePrefix: String): Int {
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith(mimePrefix)) {
                return i
            }
        }
        return -1
    }

    private fun copySamples(
        extractor: MediaExtractor,
        muxer: MediaMuxer,
        muxerTrackIndex: Int,
        buffer: ByteBuffer,
        bufferInfo: MediaCodec.BufferInfo,
        onSample: ((Long) -> Unit)? = null
    ) {
        extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        while (true) {
            if (Thread.interrupted()) throw InterruptedException("Mux cancelled")
            
            bufferInfo.offset = 0
            bufferInfo.size = extractor.readSampleData(buffer, 0)
            if (bufferInfo.size < 0) break

            bufferInfo.presentationTimeUs = extractor.sampleTime
            bufferInfo.flags = extractor.sampleFlags
            muxer.writeSampleData(muxerTrackIndex, buffer, bufferInfo)
            onSample?.invoke(bufferInfo.presentationTimeUs)
            extractor.advance()
        }
    }

    private fun MediaFormat.getLongOrDefault(key: String, default: Long): Long {
        return try {
            getLong(key)
        } catch (_: Exception) {
            default
        }
    }
}
