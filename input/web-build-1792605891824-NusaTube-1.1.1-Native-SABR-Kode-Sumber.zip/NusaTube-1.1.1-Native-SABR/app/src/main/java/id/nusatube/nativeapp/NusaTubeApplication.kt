package id.nusatube.nativeapp

import android.app.Application
import android.util.Log
import id.nusatube.nativeapp.notification.SubscriptionCheckWorker
import id.nusatube.nativeapp.data.local.PlayerPreferences
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import id.nusatube.nativeapp.data.repository.NewPipeDownloader
import id.nusatube.nativeapp.notification.NotificationHelper
import id.nusatube.nativeapp.utils.NusaTubeCrashHandler
import id.nusatube.nativeapp.utils.PerformanceDispatcher
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization

import dagger.hilt.android.HiltAndroidApp
import coil.ImageLoader
import coil.ImageLoaderFactory
import javax.inject.Inject
import java.security.Security
import org.conscrypt.Conscrypt
import id.nusatube.nativeapp.innertube.YouTube
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@HiltAndroidApp
class NusaTubeApplication : Application(), ImageLoaderFactory {
    
    @Inject
    lateinit var imageLoader: ImageLoader

    override fun newImageLoader(): ImageLoader = imageLoader
    
    companion object {
        private const val TAG = "NusaTubeApplication"
    }
    
    override fun attachBaseContext(base: android.content.Context) {
        super.attachBaseContext(id.nusatube.nativeapp.utils.BahasaIndonesia.wrap(base))
    }

    override fun onCreate() {
        super.onCreate()
        
        // Injects modern TLS/SSL certificates so OkHttp and Ktor don't crash
        if (android.os.Build.VERSION.SDK_INT <= android.os.Build.VERSION_CODES.N_MR1) {
            Security.insertProviderAt(Conscrypt.newProvider(), 1)
        }

        // Install crash handler for real-time monitoring
        NusaTubeCrashHandler.install(this)
        
        try {
            val country = ContentCountry("ID")
            val localization = Localization("id", "ID")
            NewPipe.init(NewPipeDownloader.getInstance(this), localization, country)
            Log.d(TAG, "NewPipe initialized successfully with id-ID settings")
        } catch (e: Exception) {
            // Log error but don't crash the app
            Log.e(TAG, "Failed to initialize NewPipe", e)
        }

        try {
            id.nusatube.nativeapp.utils.cipher.CipherDeobfuscator.initialize(this)
            id.nusatube.nativeapp.nativeflow.NativePlaybackBridge.initialize(this)
            Log.d(TAG, "CipherDeobfuscator initialized")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize CipherDeobfuscator", e)
        }
        
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                id.nusatube.nativeapp.nativeflow.NativePlaybackBridge.initializeIdentity(this@NusaTubeApplication)
            } catch (e: Exception) {
                Log.w(TAG, "Native session warmup deferred", e)
            }
        }

        // Initialize notification channels
        NotificationHelper.createNotificationChannels(this)
        Log.d(TAG, "Notification channels created")
        
        /*
        try {
            // Initialize YoutubeDL
            com.yausername.youtubedl_android.YoutubeDL.getInstance().init(this)
            Log.d(TAG, "YoutubeDL initialized")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize YoutubeDL", e)
        }
        */
        
        // Schedule periodic subscription checks for new videos
        val savedIntervalMinutes = runBlocking { PlayerPreferences(this@NusaTubeApplication).subscriptionCheckIntervalMinutes.first() }
        SubscriptionCheckWorker.schedulePeriodicCheck(this, intervalMinutes = savedIntervalMinutes.toLong())
        
        // Schedule periodic update checks (every 12 hours) — github flavor only
        if (BuildConfig.UPDATER_ENABLED) {
            id.nusatube.nativeapp.notification.UpdateCheckWorker.schedulePeriodicCheck(this)
        }
        
        Log.d(TAG, "Workers scheduled successfully")

        // Fetch and cache visitor data for the lifetime of the install.
        // The X-Goog-Visitor-Id header prevents YouTube from returning empty
        // search results on tablets and fresh Android 16 installs (Issue #223).
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val prefs = getSharedPreferences("flow_prefs", MODE_PRIVATE)
                val cached = prefs.getString("visitor_data", null)
                if (!cached.isNullOrEmpty()) {
                    YouTube.visitorData = cached
                    Log.d(TAG, "visitorData restored from prefs")
                } else {
                    YouTube.visitorData().onSuccess { data ->
                        if (!data.isNullOrEmpty()) {
                            prefs.edit().putString("visitor_data", data).apply()
                            YouTube.visitorData = data
                            Log.d(TAG, "visitorData fetched and cached")
                        }
                    }.onFailure { e ->
                        Log.w(TAG, "visitorData fetch failed: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "visitorData init error: ${e.message}")
            }
        }
    }
    
    override fun onTerminate() {
        super.onTerminate()
        // Clean up performance dispatcher resources
        PerformanceDispatcher.shutdown()
    }
}
