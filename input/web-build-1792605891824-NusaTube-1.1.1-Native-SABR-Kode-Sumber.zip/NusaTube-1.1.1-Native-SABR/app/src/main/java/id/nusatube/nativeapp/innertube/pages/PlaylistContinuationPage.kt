package id.nusatube.nativeapp.innertube.pages

import id.nusatube.nativeapp.innertube.models.SongItem

data class PlaylistContinuationPage(
    val songs: List<SongItem>,
    val continuation: String?,
)
