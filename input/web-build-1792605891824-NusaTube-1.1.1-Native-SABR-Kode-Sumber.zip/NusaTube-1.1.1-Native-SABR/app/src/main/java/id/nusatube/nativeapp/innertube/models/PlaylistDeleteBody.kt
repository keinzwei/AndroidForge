package id.nusatube.nativeapp.innertube.models.body

import id.nusatube.nativeapp.innertube.models.Context
import kotlinx.serialization.Serializable

@Serializable
data class PlaylistDeleteBody(
    val context: Context,
    val playlistId: String
)
