package id.nusatube.nativeapp.di

import android.content.Context
import id.nusatube.nativeapp.data.local.PlayerPreferences
import id.nusatube.nativeapp.data.repository.YouTubeRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideYouTubeRepository(playerPreferences: PlayerPreferences): YouTubeRepository {
        return YouTubeRepository.getInstance(playerPreferences)
    }

    @Provides
    @Singleton
    fun provideSubscriptionRepository(@ApplicationContext context: Context): id.nusatube.nativeapp.data.local.SubscriptionRepository {
        return id.nusatube.nativeapp.data.local.SubscriptionRepository.getInstance(context)
    }

    @Provides
    @Singleton
    fun provideLikedVideosRepository(@ApplicationContext context: Context): id.nusatube.nativeapp.data.local.LikedVideosRepository {
        return id.nusatube.nativeapp.data.local.LikedVideosRepository.getInstance(context)
    }

    @Provides
    @Singleton
    fun provideViewHistory(@ApplicationContext context: Context): id.nusatube.nativeapp.data.local.ViewHistory {
        return id.nusatube.nativeapp.data.local.ViewHistory.getInstance(context)
    }

    @Provides
    @Singleton
    fun provideInterestProfile(@ApplicationContext context: Context): id.nusatube.nativeapp.data.recommendation.InterestProfile {
        return id.nusatube.nativeapp.data.recommendation.InterestProfile.getInstance(context)
    }

    @Provides
    @Singleton
    fun provideMusicPlaylistRepository(@ApplicationContext context: Context): id.nusatube.nativeapp.data.music.PlaylistRepository {
        return id.nusatube.nativeapp.data.music.PlaylistRepository(context)
    }


    // VideoDownloadManager is now @Singleton @Inject — Hilt provides it automatically
    @Provides
    @Singleton
    fun providePlayerPreferences(@ApplicationContext context: Context): id.nusatube.nativeapp.data.local.PlayerPreferences {
        return id.nusatube.nativeapp.data.local.PlayerPreferences(context)
    }

    @Provides
    @Singleton
    fun provideShortsRepository(@ApplicationContext context: Context): id.nusatube.nativeapp.data.shorts.ShortsRepository {
        return id.nusatube.nativeapp.data.shorts.ShortsRepository.getInstance(context)
    }
}
