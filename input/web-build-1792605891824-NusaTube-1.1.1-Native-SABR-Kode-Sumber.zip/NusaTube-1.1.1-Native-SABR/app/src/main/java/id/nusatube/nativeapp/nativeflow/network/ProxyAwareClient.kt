// SPDX-License-Identifier: GPL-3.0-only
// Ported from Flow v3.0.0 (A-EDev), 9b592728f96de4efdb3b0041331bb3b44bfe054c.
package id.nusatube.nativeapp.nativeflow.network

import okhttp3.OkHttpClient

/**
 * One [OkHttpClient] per proxy configuration, rebuilt only when that configuration changes: calls
 * share one connection pool, while a proxy switch still takes effect without a restart.
 */
class ProxyAwareClient(
    private val configure: OkHttpClient.Builder.() -> OkHttpClient.Builder = { this },
) {
    private val lock = Any()

    @Volatile
    private var cachedClient: OkHttpClient? = null

    @Volatile
    private var cachedProxySignature: String? = null

    fun get(): OkHttpClient {
        val signature = AppProxyManager.currentSignature()
        cachedClient?.let { if (cachedProxySignature == signature) return it }
        return synchronized(lock) {
            cachedClient?.let { if (cachedProxySignature == signature) return it }
            AppProxyManager
                .applyTo(OkHttpClient.Builder())
                .configure()
                .build()
                .also {
                    cachedClient = it
                    cachedProxySignature = signature
                }
        }
    }
}
