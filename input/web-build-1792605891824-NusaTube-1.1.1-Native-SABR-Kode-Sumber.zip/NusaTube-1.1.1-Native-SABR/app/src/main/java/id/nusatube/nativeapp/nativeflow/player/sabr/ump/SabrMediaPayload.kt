// SPDX-License-Identifier: GPL-3.0-only
// Ported from Flow v3.0.0 (A-EDev), 9b592728f96de4efdb3b0041331bb3b44bfe054c.
package id.nusatube.nativeapp.nativeflow.player.sabr.ump

/**
 * MEDIA and MEDIA_END payloads address their MEDIA_HEADER with one unsigned byte.
 * This byte is not encoded with the variable-width integer used by the outer UMP envelope.
 */
object SabrMediaPayload {
    const val HEADER_ID_BYTES = 1

    fun headerId(payload: ByteArray): Int? =
        payload.firstOrNull()?.toInt()?.and(0xFF)

    fun dataOffset(payload: ByteArray): Int =
        if (payload.isEmpty()) 0 else HEADER_ID_BYTES
}
