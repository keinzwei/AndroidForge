package id.nusatube.nativeapp.innertube.pages

import id.nusatube.nativeapp.innertube.models.Album
import id.nusatube.nativeapp.innertube.models.AlbumItem
import id.nusatube.nativeapp.innertube.models.Artist
import id.nusatube.nativeapp.innertube.models.ArtistItem
import id.nusatube.nativeapp.innertube.models.MusicResponsiveListItemRenderer
import id.nusatube.nativeapp.innertube.models.MusicTwoRowItemRenderer
import id.nusatube.nativeapp.innertube.models.PlaylistItem
import id.nusatube.nativeapp.innertube.models.SongItem
import id.nusatube.nativeapp.innertube.models.YTItem
import id.nusatube.nativeapp.innertube.models.oddElements
import id.nusatube.nativeapp.innertube.utils.parseTime

data class LibraryAlbumsPage(
    val albums: List<AlbumItem>,
    val continuation: String?,
) {
    companion object {
        fun fromMusicTwoRowItemRenderer(renderer: MusicTwoRowItemRenderer): AlbumItem? {
            return AlbumItem(
                        browseId = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        playlistId = renderer.thumbnailOverlay?.musicItemThumbnailOverlayRenderer?.content
                            ?.musicPlayButtonRenderer?.playNavigationEndpoint
                            ?.watchPlaylistEndpoint?.playlistId ?: return null,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        artists = null,
                        year = renderer.subtitle?.runs?.lastOrNull()?.text?.toIntOrNull(),
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit = renderer.subtitleBadges?.find {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } != null
                    )
        }
    }
}
