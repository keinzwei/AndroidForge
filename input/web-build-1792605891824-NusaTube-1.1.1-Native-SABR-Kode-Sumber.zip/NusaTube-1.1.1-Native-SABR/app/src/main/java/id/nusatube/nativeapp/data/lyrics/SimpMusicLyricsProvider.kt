// ============================================================================
// THIS IMPLEMENTATION WAS INSPIRED BY METROLIST
// ============================================================================

package id.nusatube.nativeapp.data.lyrics

/**
 * LyricsProvider implementation for the SimpMusic service.
 * Delegates to SimpMusicLyrics service which returns structured LyricsEntry with word timestamps.
 */
class SimpMusicLyricsProvider : LyricsProvider {
    override val name = "SimpMusic"

    override suspend fun getLyrics(
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?
    ): Result<List<LyricsEntry>> {
        return SimpMusicLyrics.getLyrics(id, duration)
    }
}
