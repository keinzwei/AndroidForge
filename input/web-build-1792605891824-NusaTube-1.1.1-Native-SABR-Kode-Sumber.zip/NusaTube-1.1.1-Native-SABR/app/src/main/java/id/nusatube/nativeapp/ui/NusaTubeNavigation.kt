package id.nusatube.nativeapp.ui

import id.nusatube.nativeapp.ui.screens.categories.CategoriesScreen as NusaImportedCategoriesScreen
import id.nusatube.nativeapp.ui.screens.library.DownloadsScreen as NusaImportedDownloadsScreen
import id.nusatube.nativeapp.ui.screens.library.SavedShortsGridScreen as NusaImportedSavedShortsGridScreen
import id.nusatube.nativeapp.ui.screens.settings.AboutScreen as NusaImportedAboutScreen
import id.nusatube.nativeapp.ui.screens.settings.AppearanceScreen as NusaImportedAppearanceScreen
import id.nusatube.nativeapp.ui.screens.settings.BufferSettingsScreen as NusaImportedBufferSettingsScreen
import id.nusatube.nativeapp.ui.screens.settings.ContentSettingsScreen as NusaImportedContentSettingsScreen
import id.nusatube.nativeapp.ui.screens.settings.DiagnosticsScreen as NusaImportedDiagnosticsScreen
import id.nusatube.nativeapp.ui.screens.settings.DonationsScreen as NusaImportedDonationsScreen
import id.nusatube.nativeapp.ui.screens.settings.DownloadSettingsScreen as NusaImportedDownloadSettingsScreen
import id.nusatube.nativeapp.ui.screens.settings.NotificationSettingsScreen as NusaImportedNotificationSettingsScreen
import id.nusatube.nativeapp.ui.screens.settings.PlayerAppearanceScreen as NusaImportedPlayerAppearanceScreen
import id.nusatube.nativeapp.ui.screens.settings.PlayerSettingsScreen as NusaImportedPlayerSettingsScreen
import id.nusatube.nativeapp.ui.screens.settings.SearchHistorySettingsScreen as NusaImportedSearchHistorySettingsScreen
import id.nusatube.nativeapp.ui.screens.settings.ShortsVideoQualitySettingsScreen as NusaImportedShortsVideoQualitySettingsScreen
import id.nusatube.nativeapp.ui.screens.settings.TimeManagementScreen as NusaImportedTimeManagementScreen
import id.nusatube.nativeapp.ui.screens.settings.UserPreferencesScreen as NusaImportedUserPreferencesScreen
import id.nusatube.nativeapp.ui.screens.settings.VideoQualitySettingsScreen as NusaImportedVideoQualitySettingsScreen

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import androidx.hilt.navigation.compose.hiltViewModel
import id.nusatube.nativeapp.data.model.Video
import id.nusatube.nativeapp.player.GlobalPlayerState
import id.nusatube.nativeapp.ui.components.PlayerSheetValue
import id.nusatube.nativeapp.ui.components.PlayerDraggableState
import id.nusatube.nativeapp.ui.components.MusicPlayerSheetState
import id.nusatube.nativeapp.ui.screens.home.HomeScreen
import id.nusatube.nativeapp.ui.screens.history.HistoryScreen
import id.nusatube.nativeapp.ui.screens.library.LibraryScreen
import id.nusatube.nativeapp.ui.screens.library.WatchLaterScreen
import id.nusatube.nativeapp.ui.screens.likedvideos.LikedVideosScreen
import id.nusatube.nativeapp.ui.screens.playlists.PlaylistsScreen
import id.nusatube.nativeapp.ui.screens.playlists.PlaylistDetailScreen
import id.nusatube.nativeapp.ui.screens.notifications.NotificationScreen
import id.nusatube.nativeapp.ui.screens.player.VideoPlayerViewModel
import id.nusatube.nativeapp.ui.screens.player.VideoPlayerUiState
import id.nusatube.nativeapp.ui.screens.search.SearchScreen
import id.nusatube.nativeapp.ui.screens.settings.SettingsScreen
import id.nusatube.nativeapp.ui.screens.settings.ImportDataScreen
import id.nusatube.nativeapp.ui.screens.personality.NusaTubePersonalityScreen
import id.nusatube.nativeapp.ui.screens.shorts.ShortsScreen
import id.nusatube.nativeapp.ui.screens.subscriptions.SubscriptionsScreen
import id.nusatube.nativeapp.ui.screens.channel.ChannelScreen
import id.nusatube.nativeapp.ui.screens.onboarding.OnboardingScreen
import id.nusatube.nativeapp.ui.theme.ThemeMode
import androidx.media3.common.util.UnstableApi
import java.net.URLEncoder

@UnstableApi
fun NavGraphBuilder.flowAppGraph(
    navController: NavHostController,
    currentRoute: MutableState<String>,
    showBottomNav: MutableState<Boolean>,
    selectedBottomNavIndex: MutableIntState,
    playerSheetState: PlayerDraggableState,
    musicPlayerSheetState: MusicPlayerSheetState,
    playerViewModel: VideoPlayerViewModel,
    playerUiStateResult: State<VideoPlayerUiState>, 
    playerVisibleState: MutableState<Boolean>, 
    currentTheme: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit,
    onOnboardingComplete: () -> Unit = {},
    disableShortsPlayer: Boolean = false
) {
    // =============================================
    // ONBOARDING (First-time user experience)
    // =============================================
    composable("onboarding") {
        currentRoute.value = "onboarding"
        showBottomNav.value = false
        OnboardingScreen(
            onComplete = {
                onOnboardingComplete()
                // Navigate to home and clear the backstack so user can't go back to onboarding
                navController.navigate("home") {
                    popUpTo("onboarding") { inclusive = true }
                }
            }
        )
    }
    
    composable("home") {
        currentRoute.value = "home"
        showBottomNav.value = playerSheetState.currentValue != PlayerSheetValue.Expanded
        selectedBottomNavIndex.intValue = 0
        val density = LocalDensity.current
        val config = LocalConfiguration.current
        // Use miniSizeScale live value: wide = screenWidth * 9/16 height, normal = 0
        val inlinePlayerHeight by remember {
            derivedStateOf {
                val scale = playerSheetState.miniSizeScale.value
                val isMini = playerSheetState.expandFraction.value > 0.5f
                if (isMini && scale > 1.5f) {
                    with(density) { (config.screenWidthDp.dp.toPx() * (9f / 16f)).toDp() }
                } else 0.dp
            }
        }
        HomeScreen(
            onVideoClick = { video ->
                if (video.isShort && !disableShortsPlayer) {
                    navController.navigate("shorts?startVideoId=${video.id}")
                } else {
                    playerViewModel.playVideo(video)
                    GlobalPlayerState.setCurrentVideo(video)
                }
            },
            onShortClick = { video ->
                navController.navigate("shorts?startVideoId=${video.id}")
            },
            onSearchClick = {
                navController.navigate("search")
            },
            onNotificationClick = {
                navController.navigate("notifications")
            },
            onSettingsClick = {
                navController.navigate("settings")
            },
            onChannelClick = { channelId ->
                val encodedUrl = java.net.URLEncoder.encode("https://www.youtube.com/channel/$channelId", "UTF-8")
                navController.navigate("channel?url=$encodedUrl")
            }
        )
    }

    // Notifications Screen
    composable("notifications") {
        currentRoute.value = "notifications"
        showBottomNav.value = false
        NotificationScreen(
            onBackClick = { navController.popBackStack() },
            onNotificationClick = { videoId ->
                navController.navigate("player/$videoId")
            }
        )
    }

    composable(
        route = "shorts?startVideoId={startVideoId}",
        arguments = listOf(
            navArgument("startVideoId") { 
                type = NavType.StringType
                nullable = true
                defaultValue = null
            }
        )
    ) { backStackEntry ->
        currentRoute.value = "shorts"
        showBottomNav.value = true
        selectedBottomNavIndex.intValue = 1
        val startVideoId = backStackEntry.arguments?.getString("startVideoId")
        ShortsScreen(
            startVideoId = startVideoId,
            onBack = {
                navController.popBackStack()
            },
            onChannelClick = { channelId ->
                navController.navigate("channel?url=$channelId")
            }
        )
    }

    composable("subscriptions") {
        currentRoute.value = "subscriptions"
        showBottomNav.value = true
        selectedBottomNavIndex.intValue = 3
        SubscriptionsScreen(
            onVideoClick = { video ->
                if (video.isShort && !disableShortsPlayer) {
                    navController.navigate("shorts?startVideoId=${video.id}")
                } else {
                    navController.navigate("player/${video.id}")
                }
            },
            onShortClick = { videoId ->
                navController.navigate("shorts?startVideoId=$videoId")
            },
            onChannelClick = { channelUrl ->
                val encodedUrl = channelUrl.replace("/", "%2F").replace(":", "%3A")
                navController.navigate("channel?url=$encodedUrl")
            }
        )
    }

    composable("library") {
        currentRoute.value = "library"
        showBottomNav.value = true
        selectedBottomNavIndex.intValue = 4
        LibraryScreen(
            onSearchClick = { navController.navigate("search") },
            onNavigateToHistory = { 
                navController.navigate("history")
            },
            onNavigateToPlaylists = { 
                navController.navigate("playlists")
            },
            onNavigateToLikedVideos = { 
                navController.navigate("likedVideos")
            },
            onNavigateToWatchLater = {
                navController.navigate("watchLater")
            },
            onNavigateToSavedShorts = {
                navController.navigate("savedShorts")
            },
            onNavigateToDownloads = {
                navController.navigate("downloads")
            },
            onManageData = {
                navController.navigate("settings")
            }
        )
    }

    composable("search") {
        currentRoute.value = "search"
        showBottomNav.value = true
        selectedBottomNavIndex.intValue = 5
        SearchScreen(
            onVideoClick = { video ->
                if (video.isShort && !disableShortsPlayer) {
                    navController.navigate("shorts?startVideoId=${video.id}")
                } else {
                    navController.navigate("player/${video.id}")
                }
            },
            onChannelClick = { channel ->
                val channelUrl = if (channel.url.isNotBlank()) {
                    channel.url
                } else {
                    "https://www.youtube.com/channel/${channel.id}"
                }
                val encodedUrl = java.net.URLEncoder.encode(channelUrl, "UTF-8")
                navController.navigate("channel?url=$encodedUrl")
            },
            onPlaylistClick = { playlist ->
                navController.navigate("playlist/${playlist.id}")
            }
        )
    }

    composable("categories") {
        currentRoute.value = "categories"
        showBottomNav.value = true
        selectedBottomNavIndex.intValue = 6
        NusaImportedCategoriesScreen(
            onBackClick = { navController.popBackStack() },
            onVideoClick = { video ->
                if (video.isShort && !disableShortsPlayer) {
                    navController.navigate("shorts?startVideoId=${video.id}")
                } else {
                    navController.navigate("player/${video.id}")
                }
            }
        )
    }

    composable("settings") {
        currentRoute.value = "settings"
        showBottomNav.value = false
        SettingsScreen(
            currentTheme = currentTheme,
            onThemeChange = onThemeChange,

            onNavigateBack = { navController.popBackStack() },
            onNavigateToPlayerAppearance = { navController.navigate("settings/player_appearance") },
            onNavigateToDonations = { navController.navigate("donations") },
            onNavigateToPersonality = { navController.navigate("personality") },
            onNavigateToDownloads = { navController.navigate("settings/downloads") },
            onNavigateToTimeManagement = { navController.navigate("settings/time_management") },
            onNavigateToImport = { navController.navigate("settings/import") },
            onNavigateToPlayerSettings = { navController.navigate("settings/player") },
            onNavigateToVideoQuality = { navController.navigate("settings/video_quality") },
            onNavigateToShortsQuality = { navController.navigate("settings/shorts_quality") },
            onNavigateToContentSettings = { navController.navigate("settings/content") },
            onNavigateToBufferSettings = { navController.navigate("settings/buffer") },
            onNavigateToSearchHistory = { navController.navigate("settings/search_history") },
            onNavigateToAbout = { navController.navigate("settings/about") },
            onNavigateToUserPreferences = { navController.navigate("settings/user_preferences") },
            onNavigateToNotifications = { navController.navigate("settings/notifications") },
            onNavigateToDiagnostics = { navController.navigate("settings/diagnostics") }
        )
    }

    composable("settings/user_preferences") {
        currentRoute.value = "settings/user_preferences"
        showBottomNav.value = false
        NusaImportedUserPreferencesScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }

    composable("settings/player") {
        currentRoute.value = "settings/player"
        showBottomNav.value = false
        NusaImportedPlayerSettingsScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }
    
    composable("settings/buffer") {
        currentRoute.value = "settings/buffer"
        showBottomNav.value = false
        NusaImportedBufferSettingsScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }
    
    composable("settings/search_history") {
        currentRoute.value = "settings/search_history"
        showBottomNav.value = false
        NusaImportedSearchHistorySettingsScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }

    composable("settings/video_quality") {
        currentRoute.value = "settings/video_quality"
        showBottomNav.value = false
        NusaImportedVideoQualitySettingsScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }

    composable("settings/shorts_quality") {
        currentRoute.value = "settings/shorts_quality"
        showBottomNav.value = false
        NusaImportedShortsVideoQualitySettingsScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }
    
    composable("settings/content") {
        currentRoute.value = "settings/content"
        showBottomNav.value = false
        NusaImportedContentSettingsScreen(
            onBackClick = { navController.popBackStack() }
        )
    }
    
    composable("settings/import") {
        currentRoute.value = "settings/import"
        ImportDataScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }

    composable("settings/time_management") {
        currentRoute.value = "settings/time_management"
        showBottomNav.value = false
        NusaImportedTimeManagementScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }

    composable("settings/about") {
        currentRoute.value = "settings/about"
        showBottomNav.value = false
        NusaImportedAboutScreen(
            onNavigateBack = { navController.popBackStack() },
            onNavigateToDonations = { navController.navigate("donations") }
        )
    }

    composable("settings/appearance") {
        currentRoute.value = "settings/appearance"
        showBottomNav.value = false
        NusaImportedAppearanceScreen(
            currentTheme = currentTheme,
            onThemeChange = onThemeChange,
            onNavigateBack = { navController.popBackStack() }
        )
    }

    composable("settings/player_appearance") {
        currentRoute.value = "settings/player_appearance"
        showBottomNav.value = false
        NusaImportedPlayerAppearanceScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }

    composable("settings/downloads") {
        currentRoute.value = "settings/downloads"
        showBottomNav.value = false
        NusaImportedDownloadSettingsScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }

    composable("settings/notifications") {
        currentRoute.value = "settings/notifications"
        showBottomNav.value = false
        NusaImportedNotificationSettingsScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }

    composable("settings/diagnostics") {
        currentRoute.value = "settings/diagnostics"
        showBottomNav.value = false
        NusaImportedDiagnosticsScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }

    composable("donations") {
        currentRoute.value = "donations"
        showBottomNav.value = false
        NusaImportedDonationsScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }

    composable("personality") {
        currentRoute.value = "personality"
        showBottomNav.value = false
        NusaTubePersonalityScreen(
            onNavigateBack = { navController.popBackStack() }
        )
    }
    
    composable(
        route = "channel?url={channelUrl}",
        arguments = listOf(navArgument("channelUrl") { type = NavType.StringType })
    ) { backStackEntry ->
        currentRoute.value = "channel"
        showBottomNav.value = false
        val channelUrl = backStackEntry.arguments?.getString("channelUrl")?.let {
            java.net.URLDecoder.decode(it, "UTF-8")
        } ?: ""
        
        ChannelScreen(
            channelUrl = channelUrl,
            onVideoClick = { video ->
                if (video.isShort && !disableShortsPlayer) {
                    navController.navigate("shorts?startVideoId=${video.id}")
                } else {
                    navController.navigate("player/${video.id}")
                }
            },
            onShortClick = { videoId ->
                navController.navigate("shorts?startVideoId=$videoId")
            },
            onPlaylistClick = { playlistId ->
                navController.navigate("playlist/$playlistId")
            },
            onBackClick = { navController.popBackStack() }
        )
    }

    // History Screen
    composable("history") {
        currentRoute.value = "history"
        showBottomNav.value = false
        HistoryScreen(
            onVideoClick = { track ->
                navController.navigate("player/${track.videoId}")
            },
            onBackClick = { navController.popBackStack() },
            onArtistClick = { channelId ->
                navController.navigate("channel?url=$channelId")
            }
        )
    }

    // Liked Videos Screen
    composable("likedVideos") {
        currentRoute.value = "likedVideos"
        showBottomNav.value = false
        LikedVideosScreen(
            onVideoClick = { track ->
                navController.navigate("player/${track.videoId}")
            },
            onBackClick = { navController.popBackStack() },
            onArtistClick = { channelId ->
                navController.navigate("channel?url=$channelId")
            }
        )
    }

    // Watch Later Screen
    composable("watchLater") {
        currentRoute.value = "watchLater"
        showBottomNav.value = false
        WatchLaterScreen(
            onBackClick = { navController.popBackStack() },
            onVideoClick = { video ->
                if (video.isShort && !disableShortsPlayer) {
                    navController.navigate("shorts?startVideoId=${video.id}")
                } else {
                    navController.navigate("player/${video.id}")
                }
            },
            onPlayPlaylist = { videos, index ->
                playerViewModel.playPlaylist(videos, index, "Tonton Nanti")
            }
        )
    }

    // Playlists Screen
    composable("playlists") {
        currentRoute.value = "playlists"
        showBottomNav.value = false
        PlaylistsScreen(
            onBackClick = { navController.popBackStack() },
            onPlaylistClick = { playlist ->
                navController.navigate("playlist/${playlist.id}")
            },
            onNavigateToWatchLater = { navController.navigate("watchLater") },
            onNavigateToLikedVideos = { navController.navigate("likedVideos") }
        )
    }

    // Playlist Detail Screen
    composable("playlist/{playlistId}") { _ ->
        currentRoute.value = "playlist"
        showBottomNav.value = false
        PlaylistDetailScreen(
            // playlistId is handled by ViewModel via SavedStateHandle
            // playlistRepository is injected by Hilt
            onNavigateBack = { navController.popBackStack() },
            onVideoClick = { video ->
                if (video.isShort && !disableShortsPlayer) {
                    navController.navigate("shorts?startVideoId=${video.id}")
                } else {
                    navController.navigate("player/${video.id}")
                }
            },
            onPlayPlaylist = { videos, index ->
                playerViewModel.playPlaylist(videos, index, "Daftar Putar")
            }
        )
    }

    // Saved Shorts Grid
    composable("savedShorts") {
        currentRoute.value = "savedShorts"
        showBottomNav.value = false
        NusaImportedSavedShortsGridScreen(
            onBackClick = { navController.popBackStack() },
            onVideoClick = { videoId ->
                navController.navigate("savedShortsPlayer/$videoId")
            }
        )
    }

    // Saved Shorts Player
    composable(
        route = "savedShortsPlayer/{startVideoId}",
        arguments = listOf(navArgument("startVideoId") { type = NavType.StringType })
    ) { backStackEntry ->
        currentRoute.value = "savedShortsPlayer"
        showBottomNav.value = false
        val startVideoId = backStackEntry.arguments?.getString("startVideoId")
        ShortsScreen(
            startVideoId = startVideoId,
            isSavedMode = true,
            onBack = {
                navController.popBackStack()
            },
            onChannelClick = { channelId ->
                navController.navigate("channel?url=$channelId")
            }
        )
    }
    composable("downloads") {
        currentRoute.value = "downloads"
        showBottomNav.value = false

        NusaImportedDownloadsScreen(
            onBackClick = { navController.popBackStack() },
            onVideoClick = { videos, index ->
                val videoList = videos.map { it.video }
                playerViewModel.playPlaylist(videoList, index, "Unduhan")
                GlobalPlayerState.setCurrentVideo(videoList[index])
            },
            onHomeClick = {
                navController.navigate("home") {
                    popUpTo("home") { inclusive = true }
                }
            }
        )
    }
    composable(
        route = "player/{videoId}",
        arguments = listOf(navArgument("videoId") { type = NavType.StringType }),
        deepLinks = listOf(
            navDeepLink {
                uriPattern = "http://www.youtube.com/watch?v={videoId}"
                action = android.content.Intent.ACTION_VIEW
            },
            navDeepLink {
                uriPattern = "https://www.youtube.com/watch?v={videoId}"
                action = android.content.Intent.ACTION_VIEW
            },
            navDeepLink {
                uriPattern = "http://youtube.com/watch?v={videoId}"
                action = android.content.Intent.ACTION_VIEW
            },
            navDeepLink {
                uriPattern = "https://youtube.com/watch?v={videoId}"
                action = android.content.Intent.ACTION_VIEW
            },
            navDeepLink {
                uriPattern = "http://youtu.be/{videoId}"
                action = android.content.Intent.ACTION_VIEW
            },
            navDeepLink {
                uriPattern = "https://youtu.be/{videoId}"
                action = android.content.Intent.ACTION_VIEW
            },
            navDeepLink {
                uriPattern = "http://m.youtube.com/watch?v={videoId}"
                action = android.content.Intent.ACTION_VIEW
            },
            navDeepLink {
                uriPattern = "https://m.youtube.com/watch?v={videoId}"
                action = android.content.Intent.ACTION_VIEW
            },
            navDeepLink {
                uriPattern = "https://www.youtube.com/shorts/{videoId}"
                action = android.content.Intent.ACTION_VIEW
            },
            navDeepLink {
                uriPattern = "https://youtube.com/shorts/{videoId}"
                action = android.content.Intent.ACTION_VIEW
            }
        )
    ) { backStackEntry ->
        val videoId = backStackEntry.arguments?.getString("videoId")
        val effectiveVideoId = when {
            !videoId.isNullOrEmpty() && videoId != "sample" -> videoId
            else -> "jNQXAC9IVRw"
        }

        // Use passed state
        val playerUiState = playerUiStateResult.value
        val playerVisible = playerVisibleState.value

        LaunchedEffect(effectiveVideoId) {
            if (playerUiState.cachedVideo?.id != effectiveVideoId || !playerVisible) {
                val placeholder = Video(
                    id = effectiveVideoId,
                    title = "",
                    channelName = "",
                    channelId = "",
                    thumbnailUrl = "",
                    duration = 0,
                    viewCount = 0L,
                    uploadDate = "",
                    description = "",
                    channelThumbnailUrl = ""
                )
                playerViewModel.playVideo(placeholder)
                GlobalPlayerState.setCurrentVideo(placeholder)
            } else {
                playerSheetState.expand()
            }
            navController.popBackStack()
        }
        
        Box(modifier = Modifier.fillMaxSize())
    }
}