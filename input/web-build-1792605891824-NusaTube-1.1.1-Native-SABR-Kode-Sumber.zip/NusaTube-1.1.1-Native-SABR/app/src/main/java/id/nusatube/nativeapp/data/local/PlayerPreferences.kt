package id.nusatube.nativeapp.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.playerPreferencesDataStore: DataStore<Preferences> by preferencesDataStore(name = "player_preferences")

class PlayerPreferences(private val context: Context) {
    
    private object Keys {
        val DEFAULT_QUALITY_WIFI = stringPreferencesKey("default_quality_wifi")
        val DEFAULT_QUALITY_CELLULAR = stringPreferencesKey("default_quality_cellular")
        val BACKGROUND_PLAY_ENABLED = booleanPreferencesKey("background_play_enabled")
        val AUTOPLAY_ENABLED = booleanPreferencesKey("autoplay_enabled")
        val VIDEO_LOOP_ENABLED = booleanPreferencesKey("video_loop_enabled")
        val SUBTITLES_ENABLED = booleanPreferencesKey("subtitles_enabled")
        val PREFERRED_SUBTITLE_LANGUAGE = stringPreferencesKey("preferred_subtitle_language")
        val PLAYBACK_SPEED = floatPreferencesKey("playback_speed")
        val TRENDING_REGION = stringPreferencesKey("trending_region")
        val SKIP_SILENCE_ENABLED = booleanPreferencesKey("skip_silence_enabled")        
        val SPONSOR_BLOCK_ENABLED = booleanPreferencesKey("sponsor_block_enabled")        
        val AUTO_PIP_ENABLED = booleanPreferencesKey("auto_pip_enabled")
        val MANUAL_PIP_BUTTON_ENABLED = booleanPreferencesKey("manual_pip_button_enabled")
        val STABLE_VOLUME_ENABLED = booleanPreferencesKey("stable_volume_enabled")
        
        // Buffer settings
        val MIN_BUFFER_MS = intPreferencesKey("min_buffer_ms")
        val MAX_BUFFER_MS = intPreferencesKey("max_buffer_ms")
        val BUFFER_FOR_PLAYBACK_MS = intPreferencesKey("buffer_for_playback_ms")
        val BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS = intPreferencesKey("buffer_for_playback_after_rebuffer_ms")
        
        // Buffer profiles
        val BUFFER_PROFILE = stringPreferencesKey("buffer_profile")
        
        // Download settings
        val DOWNLOAD_THREADS = intPreferencesKey("download_threads")
        val PARALLEL_DOWNLOAD_ENABLED = booleanPreferencesKey("parallel_download_enabled")
        val DOWNLOAD_OVER_WIFI_ONLY = booleanPreferencesKey("download_over_wifi_only")
        val DEFAULT_DOWNLOAD_QUALITY = stringPreferencesKey("default_download_quality")
        val DOWNLOAD_LOCATION = stringPreferencesKey("download_location")
        val SURFACE_READY_TIMEOUT_MS = longPreferencesKey("surface_ready_timeout_ms")
        
        // Audio track preference
        val PREFERRED_AUDIO_LANGUAGE = stringPreferencesKey("preferred_audio_language")

        // Shorts quality preferences
        val SHORTS_QUALITY_WIFI = stringPreferencesKey("shorts_quality_wifi")
        val SHORTS_QUALITY_CELLULAR = stringPreferencesKey("shorts_quality_cellular")
        
        // UI preferences
        val GRID_ITEM_SIZE = stringPreferencesKey("grid_item_size")
        val SLIDER_STYLE = stringPreferencesKey("slider_style")
        val SQUIGGLY_SLIDER_ENABLED = booleanPreferencesKey("squiggly_slider_enabled")
        val SHORTS_SHELF_ENABLED = booleanPreferencesKey("shorts_shelf_enabled")
        val HOME_SHORTS_SHELF_ENABLED = booleanPreferencesKey("home_shorts_shelf_enabled")
        val SHORTS_NAVIGATION_ENABLED = booleanPreferencesKey("shorts_navigation_enabled")
        val MUSIC_NAVIGATION_ENABLED = booleanPreferencesKey("music_navigation_enabled")
        val SEARCH_NAV_TAB_ENABLED = booleanPreferencesKey("search_nav_tab_enabled")
        val CATEGORIES_NAV_TAB_ENABLED = booleanPreferencesKey("categories_nav_tab_enabled")
        val PREFERRED_LYRICS_PROVIDER = stringPreferencesKey("preferred_lyrics_provider")
        val SWIPE_GESTURES_ENABLED = booleanPreferencesKey("swipe_gestures_enabled")
        val CONTINUE_WATCHING_ENABLED = booleanPreferencesKey("continue_watching_enabled")
        val SHOW_RELATED_VIDEOS = booleanPreferencesKey("show_related_videos")
        val DOUBLE_TAP_SEEK_SECONDS = intPreferencesKey("double_tap_seek_seconds")
        val HOME_VIEW_MODE = stringPreferencesKey("home_view_mode")
        val HOME_FEED_ENABLED = booleanPreferencesKey("home_feed_enabled")
        val RELATED_CARD_STYLE = stringPreferencesKey("related_card_style")

        // SponsorBlock per-category action keys
        val SB_ACTION_SPONSOR = stringPreferencesKey("sb_action_sponsor")
        val SB_ACTION_INTRO = stringPreferencesKey("sb_action_intro")
        val SB_ACTION_OUTRO = stringPreferencesKey("sb_action_outro")
        val SB_ACTION_SELFPROMO = stringPreferencesKey("sb_action_selfpromo")
        val SB_ACTION_INTERACTION = stringPreferencesKey("sb_action_interaction")
        val SB_ACTION_MUSIC_OFFTOPIC = stringPreferencesKey("sb_action_music_offtopic")
        val SB_ACTION_FILLER = stringPreferencesKey("sb_action_filler")
        val SB_ACTION_PREVIEW = stringPreferencesKey("sb_action_preview")
        val SB_ACTION_EXCLUSIVE_ACCESS = stringPreferencesKey("sb_action_exclusive_access")

        // SponsorBlock per-category color keys
        val SB_COLOR_SPONSOR = intPreferencesKey("sb_color_sponsor")
        val SB_COLOR_INTRO = intPreferencesKey("sb_color_intro")
        val SB_COLOR_OUTRO = intPreferencesKey("sb_color_outro")
        val SB_COLOR_SELFPROMO = intPreferencesKey("sb_color_selfpromo")
        val SB_COLOR_INTERACTION = intPreferencesKey("sb_color_interaction")
        val SB_COLOR_MUSIC_OFFTOPIC = intPreferencesKey("sb_color_music_offtopic")
        val SB_COLOR_FILLER = intPreferencesKey("sb_color_filler")
        val SB_COLOR_PREVIEW = intPreferencesKey("sb_color_preview")
        val SB_COLOR_EXCLUSIVE_ACCESS = intPreferencesKey("sb_color_exclusive_access")

        // SponsorBlock submit
        val SB_SUBMIT_ENABLED = booleanPreferencesKey("sb_submit_enabled")
        val SB_USER_ID = stringPreferencesKey("sb_user_id")

        // DeArrow
        val DEARROW_ENABLED = booleanPreferencesKey("dearrow_enabled")

        // Notification preferences
        val NOTIF_NEW_VIDEOS_ENABLED = booleanPreferencesKey("notif_new_videos_enabled")
        val NOTIF_DOWNLOADS_ENABLED = booleanPreferencesKey("notif_downloads_enabled")
        val NOTIF_REMINDERS_ENABLED = booleanPreferencesKey("notif_reminders_enabled")
        val NOTIF_UPDATES_ENABLED = booleanPreferencesKey("notif_updates_enabled")
        val NOTIF_GENERAL_ENABLED = booleanPreferencesKey("notif_general_enabled")
        
        // Overlay Controls preferences
        val OVERLAY_CAST_ENABLED = booleanPreferencesKey("overlay_cast_enabled")
        val OVERLAY_CC_ENABLED = booleanPreferencesKey("overlay_cc_enabled")
        val OVERLAY_PIP_ENABLED = booleanPreferencesKey("overlay_pip_enabled")
        val OVERLAY_AUTOPLAY_ENABLED = booleanPreferencesKey("overlay_autoplay_enabled")
        val OVERLAY_SLEEPTIMER_ENABLED = booleanPreferencesKey("overlay_sleeptimer_enabled")
        
        // Mini Player Customizations
        val MINI_PLAYER_SCALE = floatPreferencesKey("mini_player_scale")
        val MINI_PLAYER_SHOW_SKIP_CONTROLS = booleanPreferencesKey("mini_player_show_skip_controls")
        val MINI_PLAYER_SHOW_NEXT_PREV_CONTROLS = booleanPreferencesKey("mini_player_show_next_prev_controls")
        val MINI_PLAYER_CONTINUE_WATCHING_ENABLED = booleanPreferencesKey("mini_player_continue_watching_enabled")

        // Audio focus during calls
        val PLAY_DURING_CALLS = booleanPreferencesKey("play_during_calls")

        // Subscriptions feed view mode
        val SUBS_FULL_WIDTH_VIEW = booleanPreferencesKey("subs_full_width_view")

        // Remember playback speed
        val REMEMBER_PLAYBACK_SPEED = booleanPreferencesKey("remember_playback_speed")

        // Subscription check interval
        val SUBSCRIPTION_CHECK_INTERVAL_MINUTES = intPreferencesKey("subscription_check_interval_minutes")

        // Custom playback speeds
        val CUSTOM_SPEEDS_ENABLED = booleanPreferencesKey("custom_speeds_enabled")
        val CUSTOM_SPEED_PRESETS = stringPreferencesKey("custom_speed_presets")
        val SPEED_SLIDER_ENABLED = booleanPreferencesKey("speed_slider_enabled")

        // Content filtering
        val HIDE_WATCHED_VIDEOS = booleanPreferencesKey("hide_watched_videos")
        val DISABLE_SHORTS_PLAYER = booleanPreferencesKey("disable_shorts_player")

        // Cache size
        val MEDIA_CACHE_SIZE_MB = intPreferencesKey("media_cache_size_mb")

        // Explore screen quick region picker
        val SHOW_REGION_PICKER_IN_EXPLORE = booleanPreferencesKey("show_region_picker_in_explore")

        // One-time support prompt after onboarding
        val POST_ONBOARDING_SUPPORT_PROMPT_SEEN = booleanPreferencesKey("post_onboarding_support_prompt_seen")

        // App icon — stores the component suffix of the currently selected launcher icon
        val APP_ICON_SUFFIX = stringPreferencesKey("app_icon_suffix")

        // Video title display — max lines in the player info section (0 = no limit)
        val VIDEO_TITLE_MAX_LINES = intPreferencesKey("video_title_max_lines")

        // Screen-level view mode toggles
        val SEARCH_IS_GRID_MODE = booleanPreferencesKey("search_is_grid_mode")
        val CHANNEL_IS_GRID_VIEW = booleanPreferencesKey("channel_is_grid_view")
        val CATEGORIES_IS_LIST_VIEW = booleanPreferencesKey("categories_is_list_view")
    }
    
    // Grid item size preference
    val gridItemSize: Flow<String> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.GRID_ITEM_SIZE] ?: "BIG"
        }
    
    suspend fun setGridItemSize(size: String) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.GRID_ITEM_SIZE] = size
        }
    }

    // Swipe gestures (brightness/volume) enabled preference
    val swipeGesturesEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SWIPE_GESTURES_ENABLED] ?: true
        }

    suspend fun setSwipeGesturesEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SWIPE_GESTURES_ENABLED] = enabled
        }
    }

    // SponsorBlock per-category action preferences
    fun sbActionForCategory(category: String): Flow<SponsorBlockAction> {
        val key = when (category) {
            "sponsor" -> Keys.SB_ACTION_SPONSOR
            "intro" -> Keys.SB_ACTION_INTRO
            "outro" -> Keys.SB_ACTION_OUTRO
            "selfpromo" -> Keys.SB_ACTION_SELFPROMO
            "interaction" -> Keys.SB_ACTION_INTERACTION
            "music_offtopic" -> Keys.SB_ACTION_MUSIC_OFFTOPIC
            "filler" -> Keys.SB_ACTION_FILLER
            "preview" -> Keys.SB_ACTION_PREVIEW
            "exclusive_access" -> Keys.SB_ACTION_EXCLUSIVE_ACCESS
            else -> Keys.SB_ACTION_SPONSOR
        }
        return context.playerPreferencesDataStore.data.map { preferences ->
            SponsorBlockAction.fromString(preferences[key] ?: SponsorBlockAction.SKIP.name)
        }
    }

    suspend fun setSbActionForCategory(category: String, action: SponsorBlockAction) {
        val key = when (category) {
            "sponsor" -> Keys.SB_ACTION_SPONSOR
            "intro" -> Keys.SB_ACTION_INTRO
            "outro" -> Keys.SB_ACTION_OUTRO
            "selfpromo" -> Keys.SB_ACTION_SELFPROMO
            "interaction" -> Keys.SB_ACTION_INTERACTION
            "music_offtopic" -> Keys.SB_ACTION_MUSIC_OFFTOPIC
            "filler" -> Keys.SB_ACTION_FILLER
            "preview" -> Keys.SB_ACTION_PREVIEW
            "exclusive_access" -> Keys.SB_ACTION_EXCLUSIVE_ACCESS
            else -> Keys.SB_ACTION_SPONSOR
        }
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[key] = action.name
        }
    }

    // SponsorBlock per-category color preferences (stored as ARGB Int)
    fun sbColorForCategory(category: String): Flow<Int?> {
        val key = when (category) {
            "sponsor" -> Keys.SB_COLOR_SPONSOR
            "intro" -> Keys.SB_COLOR_INTRO
            "outro" -> Keys.SB_COLOR_OUTRO
            "selfpromo" -> Keys.SB_COLOR_SELFPROMO
            "interaction" -> Keys.SB_COLOR_INTERACTION
            "music_offtopic" -> Keys.SB_COLOR_MUSIC_OFFTOPIC
            "filler" -> Keys.SB_COLOR_FILLER
            "preview" -> Keys.SB_COLOR_PREVIEW
            "exclusive_access" -> Keys.SB_COLOR_EXCLUSIVE_ACCESS
            else -> Keys.SB_COLOR_SPONSOR
        }
        return context.playerPreferencesDataStore.data.map { prefs -> prefs[key] }
    }

    suspend fun setSbColorForCategory(category: String, colorArgb: Int?) {
        val key = when (category) {
            "sponsor" -> Keys.SB_COLOR_SPONSOR
            "intro" -> Keys.SB_COLOR_INTRO
            "outro" -> Keys.SB_COLOR_OUTRO
            "selfpromo" -> Keys.SB_COLOR_SELFPROMO
            "interaction" -> Keys.SB_COLOR_INTERACTION
            "music_offtopic" -> Keys.SB_COLOR_MUSIC_OFFTOPIC
            "filler" -> Keys.SB_COLOR_FILLER
            "preview" -> Keys.SB_COLOR_PREVIEW
            "exclusive_access" -> Keys.SB_COLOR_EXCLUSIVE_ACCESS
            else -> Keys.SB_COLOR_SPONSOR
        }
        context.playerPreferencesDataStore.edit { prefs ->
            if (colorArgb != null) prefs[key] = colorArgb else prefs.remove(key)
        }
    }

    // NusaTube for reading the stored SB User ID (may be null)
    val sbUserId: Flow<String?> = context.playerPreferencesDataStore.data
        .map { prefs -> prefs[Keys.SB_USER_ID]?.takeIf { it.isNotBlank() } }

    suspend fun setSbUserId(id: String) {
        context.playerPreferencesDataStore.edit { prefs ->
            prefs[Keys.SB_USER_ID] = id
        }
    }

    val sbSubmitEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.SB_SUBMIT_ENABLED] ?: false }

    suspend fun setSbSubmitEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SB_SUBMIT_ENABLED] = enabled
        }
    }

    /** Returns the stored SponsorBlock user ID, generating a new UUID if not set. */
    suspend fun getOrCreateSbUserId(): String {
        val prefs = context.playerPreferencesDataStore.data.first()
        val existing = prefs[Keys.SB_USER_ID]
        if (!existing.isNullOrBlank()) return existing
        val newId = java.util.UUID.randomUUID().toString().replace("-", "")
        context.playerPreferencesDataStore.edit { it[Keys.SB_USER_ID] = newId }
        return newId
    }

    // Slider Style preference
    val sliderStyle: Flow<SliderStyle> = context.playerPreferencesDataStore.data
        .map { preferences ->
            SliderStyle.valueOf(preferences[Keys.SLIDER_STYLE] ?: SliderStyle.DEFAULT.name)
        }

    suspend fun setSliderStyle(style: SliderStyle) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SLIDER_STYLE] = style.name
        }
    }

    val squigglySliderEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SQUIGGLY_SLIDER_ENABLED] ?: false
        }

    suspend fun setSquigglySliderEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SQUIGGLY_SLIDER_ENABLED] = enabled
        }
    }

    // Shorts shelf enabled preference
    val shortsShelfEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            false
        }

    suspend fun setShortsShelfEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SHORTS_SHELF_ENABLED] = false
        }
    }

    // Home Shorts shelf enabled preference
    val homeShortsShelfEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            false
        }

    suspend fun setHomeShortsShelfEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.HOME_SHORTS_SHELF_ENABLED] = false
        }
    }

    // Shorts navigation enabled preference
    val shortsNavigationEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            false
        }

    suspend fun setShortsNavigationEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SHORTS_NAVIGATION_ENABLED] = false
        }
    }

    // Music navigation enabled preference
    val musicNavigationEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.MUSIC_NAVIGATION_ENABLED] ?: true
        }

    suspend fun setMusicNavigationEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.MUSIC_NAVIGATION_ENABLED] = enabled
        }
    }

    // Search nav tab enabled preference
    val searchNavigationEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SEARCH_NAV_TAB_ENABLED] ?: false
        }

    suspend fun setSearchNavigationEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SEARCH_NAV_TAB_ENABLED] = enabled
        }
    }

    // Categories nav tab enabled preference
    val categoriesNavigationEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.CATEGORIES_NAV_TAB_ENABLED] ?: false
        }

    suspend fun setCategoriesNavigationEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.CATEGORIES_NAV_TAB_ENABLED] = enabled
        }
    }

    // Continue Watching shelf enabled preference
    val continueWatchingEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.CONTINUE_WATCHING_ENABLED] ?: true
        }

    suspend fun setContinueWatchingEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.CONTINUE_WATCHING_ENABLED] = enabled
        }
    }

    // Show related videos preference
    val showRelatedVideos: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SHOW_RELATED_VIDEOS] ?: true
        }

    suspend fun setShowRelatedVideos(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SHOW_RELATED_VIDEOS] = enabled
        }
    }

    // Double-tap seek duration preference (default 10 seconds)
    val doubleTapSeekSeconds: Flow<Int> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.DOUBLE_TAP_SEEK_SECONDS] ?: 10
        }

    suspend fun setDoubleTapSeekSeconds(seconds: Int) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.DOUBLE_TAP_SEEK_SECONDS] = seconds
        }
    }

    // Home view mode preference
    val homeViewMode: Flow<HomeViewMode> = context.playerPreferencesDataStore.data
        .map { preferences ->
            HomeViewMode.valueOf(preferences[Keys.HOME_VIEW_MODE] ?: HomeViewMode.GRID.name)
        }

    suspend fun setHomeViewMode(mode: HomeViewMode) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.HOME_VIEW_MODE] = mode.name
        }
    }

    // Home feed enabled preference
    val homeFeedEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.HOME_FEED_ENABLED] ?: true
        }

    suspend fun setHomeFeedEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.HOME_FEED_ENABLED] = enabled
        }
    }

    // Related video card style preference (tablet/player panel)
    val playerRelatedCardStyle: Flow<PlayerRelatedCardStyle> = context.playerPreferencesDataStore.data
        .map { preferences ->
            try {
                PlayerRelatedCardStyle.valueOf(preferences[Keys.RELATED_CARD_STYLE] ?: PlayerRelatedCardStyle.FULL_WIDTH.name)
            } catch (_: IllegalArgumentException) {
                PlayerRelatedCardStyle.FULL_WIDTH
            }
        }

    suspend fun setPlayerRelatedCardStyle(style: PlayerRelatedCardStyle) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.RELATED_CARD_STYLE] = style.name
        }
    }
    val trendingRegion: Flow<String> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.TRENDING_REGION] ?: "ID"
        }
    
    suspend fun setTrendingRegion(region: String) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.TRENDING_REGION] = region
        }
    }
    
    // Quality preferences
    val defaultQualityWifi: Flow<VideoQuality> = context.playerPreferencesDataStore.data
        .map { preferences ->
            VideoQuality.fromString(preferences[Keys.DEFAULT_QUALITY_WIFI] ?: "1080p")
        }
    
    val defaultQualityCellular: Flow<VideoQuality> = context.playerPreferencesDataStore.data
        .map { preferences ->
            VideoQuality.fromString(preferences[Keys.DEFAULT_QUALITY_CELLULAR] ?: "480p")
        }
    
    suspend fun setDefaultQualityWifi(quality: VideoQuality) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.DEFAULT_QUALITY_WIFI] = quality.label
        }
    }
    
    suspend fun setDefaultQualityCellular(quality: VideoQuality) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.DEFAULT_QUALITY_CELLULAR] = quality.label
        }
    }

    // Shorts quality preferences (default to 720p WiFi, 480p Cellular)
    val shortsQualityWifi: Flow<VideoQuality> = context.playerPreferencesDataStore.data
        .map { preferences ->
            VideoQuality.fromString(preferences[Keys.SHORTS_QUALITY_WIFI] ?: "720p")
        }

    val shortsQualityCellular: Flow<VideoQuality> = context.playerPreferencesDataStore.data
        .map { preferences ->
            VideoQuality.fromString(preferences[Keys.SHORTS_QUALITY_CELLULAR] ?: "480p")
        }

    suspend fun setShortsQualityWifi(quality: VideoQuality) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SHORTS_QUALITY_WIFI] = quality.label
        }
    }

    suspend fun setShortsQualityCellular(quality: VideoQuality) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SHORTS_QUALITY_CELLULAR] = quality.label
        }
    }
    
    // Background play
    val backgroundPlayEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.BACKGROUND_PLAY_ENABLED] ?: false
        }
    
    suspend fun setBackgroundPlayEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.BACKGROUND_PLAY_ENABLED] = enabled
        }
    }
    
    // Autoplay
    val autoplayEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.AUTOPLAY_ENABLED] ?: true
        }
    
    suspend fun setAutoplayEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.AUTOPLAY_ENABLED] = enabled
        }
    }

    // Video Loop
    val videoLoopEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.VIDEO_LOOP_ENABLED] ?: false
        }
    
    suspend fun setVideoLoopEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.VIDEO_LOOP_ENABLED] = enabled
        }
    }

    // Skip Silence
    val skipSilenceEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SKIP_SILENCE_ENABLED] ?: false
        }

    suspend fun setSkipSilenceEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SKIP_SILENCE_ENABLED] = enabled
        }
    }

    // Stable Volume
    val stableVolumeEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.STABLE_VOLUME_ENABLED] ?: false
        }

    suspend fun setStableVolumeEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.STABLE_VOLUME_ENABLED] = enabled
        }
    }

    // SponsorBlock
    val sponsorBlockEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SPONSOR_BLOCK_ENABLED] ?: false
        }

    suspend fun setSponsorBlockEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SPONSOR_BLOCK_ENABLED] = enabled
        }
    }

    // DeArrow
    val deArrowEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.DEARROW_ENABLED] ?: false
        }

    suspend fun setDeArrowEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.DEARROW_ENABLED] = enabled
        }
    }

    // ========== NOTIFICATION PREFERENCES ==========

    val notifNewVideosEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.NOTIF_NEW_VIDEOS_ENABLED] ?: true }

    suspend fun setNotifNewVideosEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.NOTIF_NEW_VIDEOS_ENABLED] = enabled
        }
    }

    val notifDownloadsEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.NOTIF_DOWNLOADS_ENABLED] ?: true }

    suspend fun setNotifDownloadsEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.NOTIF_DOWNLOADS_ENABLED] = enabled
        }
    }

    val notifRemindersEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.NOTIF_REMINDERS_ENABLED] ?: true }

    suspend fun setNotifRemindersEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.NOTIF_REMINDERS_ENABLED] = enabled
        }
    }

    val notifUpdatesEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.NOTIF_UPDATES_ENABLED] ?: true }

    suspend fun setNotifUpdatesEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.NOTIF_UPDATES_ENABLED] = enabled
        }
    }

    val notifGeneralEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.NOTIF_GENERAL_ENABLED] ?: true }

    suspend fun setNotifGeneralEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.NOTIF_GENERAL_ENABLED] = enabled
        }
    }
    
    // ========== OVERLAY CONTROLS PREFERENCES ==========

    val overlayCastEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.OVERLAY_CAST_ENABLED] ?: true }

    suspend fun setOverlayCastEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.OVERLAY_CAST_ENABLED] = enabled
        }
    }
    
    val overlayCcEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.OVERLAY_CC_ENABLED] ?: false }

    suspend fun setOverlayCcEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.OVERLAY_CC_ENABLED] = enabled
        }
    }
    
    val overlayPipEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.OVERLAY_PIP_ENABLED] ?: false }

    suspend fun setOverlayPipEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.OVERLAY_PIP_ENABLED] = enabled
        }
    }

    val overlayAutoplayEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.OVERLAY_AUTOPLAY_ENABLED] ?: false }

    suspend fun setOverlayAutoplayEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.OVERLAY_AUTOPLAY_ENABLED] = enabled
        }
    }
    
    val overlaySleepTimerEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.OVERLAY_SLEEPTIMER_ENABLED] ?: true }

    suspend fun setOverlaySleepTimerEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.OVERLAY_SLEEPTIMER_ENABLED] = enabled
        }
    }
    
    // Subtitles
    val subtitlesEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SUBTITLES_ENABLED] ?: false
        }
    
    suspend fun setSubtitlesEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SUBTITLES_ENABLED] = enabled
        }
    }
    
    val preferredSubtitleLanguage: Flow<String> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.PREFERRED_SUBTITLE_LANGUAGE] ?: "id"
        }
    
    suspend fun setPreferredSubtitleLanguage(language: String) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.PREFERRED_SUBTITLE_LANGUAGE] = language
        }
    }
    
    // Audio Language Preference
    val preferredAudioLanguage: Flow<String> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.PREFERRED_AUDIO_LANGUAGE] ?: "original" // Default to original/native
        }
    
    suspend fun setPreferredAudioLanguage(language: String) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.PREFERRED_AUDIO_LANGUAGE] = language
        }
    }
    
    // Playback speed
    val playbackSpeed: Flow<Float> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.PLAYBACK_SPEED] ?: 1.0f
        }
    
    suspend fun setPlaybackSpeed(speed: Float) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.PLAYBACK_SPEED] = speed
        }
    }

    // Remember playback speed
    val rememberPlaybackSpeed: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.REMEMBER_PLAYBACK_SPEED] ?: false
        }

    suspend fun setRememberPlaybackSpeed(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.REMEMBER_PLAYBACK_SPEED] = enabled
        }
    }

    // Subscription check interval (default: 360 minutes / 6 hours)
    val subscriptionCheckIntervalMinutes: Flow<Int> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SUBSCRIPTION_CHECK_INTERVAL_MINUTES] ?: 360
        }

    suspend fun setSubscriptionCheckIntervalMinutes(minutes: Int) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SUBSCRIPTION_CHECK_INTERVAL_MINUTES] = minutes
        }
    }

    // Custom playback speeds
    val customSpeedsEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.CUSTOM_SPEEDS_ENABLED] ?: false
        }

    suspend fun setCustomSpeedsEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.CUSTOM_SPEEDS_ENABLED] = enabled
        }
    }

    val customSpeedPresets: Flow<String> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.CUSTOM_SPEED_PRESETS] ?: ""
        }

    suspend fun setCustomSpeedPresets(presets: String) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.CUSTOM_SPEED_PRESETS] = presets
        }
    }

    val speedSliderEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SPEED_SLIDER_ENABLED] ?: false
        }

    suspend fun setSpeedSliderEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SPEED_SLIDER_ENABLED] = enabled
        }
    }

    // Subscriptions feed view mode
    val subsFullWidthView: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SUBS_FULL_WIDTH_VIEW] ?: false
        }

    suspend fun setSubsFullWidthView(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SUBS_FULL_WIDTH_VIEW] = enabled
        }
    }

    // PiP Preferences
    val autoPipEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.AUTO_PIP_ENABLED] ?: false
        }

    suspend fun setAutoPipEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.AUTO_PIP_ENABLED] = enabled
        }
    }

    val manualPipButtonEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.MANUAL_PIP_BUTTON_ENABLED] ?: true // Default ON
        }

    suspend fun setManualPipButtonEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.MANUAL_PIP_BUTTON_ENABLED] = enabled
        }
    }

    // Content filtering
    val hideWatchedVideos: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.HIDE_WATCHED_VIDEOS] ?: false
        }

    suspend fun setHideWatchedVideos(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.HIDE_WATCHED_VIDEOS] = enabled
        }
    }

    val disableShortsPlayer: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            true
        }

    suspend fun setDisableShortsPlayer(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.DISABLE_SHORTS_PLAYER] = true
        }
    }

    // Cache size — 0 means unlimited. Default 500 MB.
    val mediaCacheSizeMb: Flow<Int> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.MEDIA_CACHE_SIZE_MB] ?: 500
        }

    suspend fun setMediaCacheSizeMb(sizeMb: Int) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.MEDIA_CACHE_SIZE_MB] = sizeMb
        }
    }

    // Show region picker globe icon in CategoriesScreen top bar
    val showRegionPickerInExplore: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SHOW_REGION_PICKER_IN_EXPLORE] ?: true
        }

    suspend fun setShowRegionPickerInExplore(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SHOW_REGION_PICKER_IN_EXPLORE] = enabled
        }
    }

    val postOnboardingSupportPromptSeen: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.POST_ONBOARDING_SUPPORT_PROMPT_SEEN] ?: false }

    suspend fun setPostOnboardingSupportPromptSeen(seen: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.POST_ONBOARDING_SUPPORT_PROMPT_SEEN] = seen
        }
    }

    // Selected app icon — component suffix string saved on each icon switch so it can be backed up/restored
    val selectedAppIcon: Flow<String?> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.APP_ICON_SUFFIX]
        }

    suspend fun setSelectedAppIcon(suffix: String) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.APP_ICON_SUFFIX] = suffix
        }
    }

    // Video title max lines in the player info section — 0 means no limit (Int.MAX_VALUE)
    val videoTitleMaxLines: Flow<Int> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.VIDEO_TITLE_MAX_LINES] ?: 1
        }

    suspend fun setVideoTitleMaxLines(lines: Int) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.VIDEO_TITLE_MAX_LINES] = lines
        }
    }

    // Screen-level view mode toggles
    val searchIsGridMode: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.SEARCH_IS_GRID_MODE] ?: false }

    suspend fun setSearchIsGridMode(isGrid: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SEARCH_IS_GRID_MODE] = isGrid
        }
    }

    val channelIsGridView: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.CHANNEL_IS_GRID_VIEW] ?: false }

    suspend fun setChannelIsGridView(isGrid: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.CHANNEL_IS_GRID_VIEW] = isGrid
        }
    }

    val categoriesIsListView: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences -> preferences[Keys.CATEGORIES_IS_LIST_VIEW] ?: false }

    suspend fun setCategoriesIsListView(isList: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.CATEGORIES_IS_LIST_VIEW] = isList
        }
    }

    // Buffer Preferences - Optimized for fast startup while maintaining stability
    // These are the defaults that balance quick playback start with smooth streaming
    val minBufferMs: Flow<Int> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.MIN_BUFFER_MS] ?: 15_000 // 15s - reduced from 25s for faster start
        }

    suspend fun setMinBufferMs(ms: Int) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.MIN_BUFFER_MS] = ms
        }
    }

    val maxBufferMs: Flow<Int> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.MAX_BUFFER_MS] ?: 50_000 // 50s - reduced from 80s, still plenty for seeking
        }

    suspend fun setMaxBufferMs(ms: Int) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.MAX_BUFFER_MS] = ms
        }
    }

    val bufferForPlaybackMs: Flow<Int> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.BUFFER_FOR_PLAYBACK_MS] ?: 1_000 // 1s - start playback ASAP (from 1.5s)
        }

    suspend fun setBufferForPlaybackMs(ms: Int) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.BUFFER_FOR_PLAYBACK_MS] = ms
        }
    }
    
    val bufferForPlaybackAfterRebufferMs: Flow<Int> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS] ?: 2_500 // 2.5s - reduced from 4s for faster resume
        }

    suspend fun setBufferForPlaybackAfterRebufferMs(ms: Int) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS] = ms
        }
    }

    val bufferProfile: Flow<BufferProfile> = context.playerPreferencesDataStore.data
        .map { preferences ->
            BufferProfile.fromString(preferences[Keys.BUFFER_PROFILE] ?: "STABLE")
        }

    suspend fun setBufferProfile(profile: BufferProfile) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.BUFFER_PROFILE] = profile.name
            
            // If not custom, apply the profile values immediately
            if (profile != BufferProfile.CUSTOM) {
                preferences[Keys.MIN_BUFFER_MS] = profile.minBuffer
                preferences[Keys.MAX_BUFFER_MS] = profile.maxBuffer
                preferences[Keys.BUFFER_FOR_PLAYBACK_MS] = profile.playbackBuffer
                preferences[Keys.BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS] = profile.rebufferBuffer
            }
        }
    }

    
    // Download Preferences
    val downloadThreads: Flow<Int> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.DOWNLOAD_THREADS] ?: 3
        }

    suspend fun setDownloadThreads(threads: Int) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.DOWNLOAD_THREADS] = threads
        }
    }

    val parallelDownloadEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.PARALLEL_DOWNLOAD_ENABLED] ?: true
        }

    suspend fun setParallelDownloadEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.PARALLEL_DOWNLOAD_ENABLED] = enabled
        }
    }

    val downloadOverWifiOnly: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.DOWNLOAD_OVER_WIFI_ONLY] ?: false
        }

    suspend fun setDownloadOverWifiOnly(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.DOWNLOAD_OVER_WIFI_ONLY] = enabled
        }
    }

    val defaultDownloadQuality: Flow<VideoQuality> = context.playerPreferencesDataStore.data
        .map { preferences ->
            VideoQuality.fromString(preferences[Keys.DEFAULT_DOWNLOAD_QUALITY] ?: "720p")
        }

    suspend fun setDefaultDownloadQuality(quality: VideoQuality) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.DEFAULT_DOWNLOAD_QUALITY] = quality.label
        }
    }

    /** Custom download directory path (null = default Movies/NusaTube or Music/NusaTube) */
    val downloadLocation: Flow<String?> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.DOWNLOAD_LOCATION]
        }

    suspend fun setDownloadLocation(path: String?) {
        context.playerPreferencesDataStore.edit { preferences ->
            if (path != null) {
                preferences[Keys.DOWNLOAD_LOCATION] = path
            } else {
                preferences.remove(Keys.DOWNLOAD_LOCATION)
            }
        }
    }

    // Surface timeout
    val surfaceReadyTimeoutMs: Flow<Long> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.SURFACE_READY_TIMEOUT_MS] ?: 1500L // Default 1.5s
        }

    suspend fun setSurfaceReadyTimeoutMs(timeoutMs: Long) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.SURFACE_READY_TIMEOUT_MS] = timeoutMs
        }
    }

    // Lyrics Provider preference
    val preferredLyricsProvider: Flow<String> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.PREFERRED_LYRICS_PROVIDER] ?: "LRCLIB"
        }

    suspend fun setPreferredLyricsProvider(provider: String) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.PREFERRED_LYRICS_PROVIDER] = provider
        }
    }

    // ========== MINI PLAYER PREFERENCES ==========

    val miniPlayerScale: Flow<Float> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.MINI_PLAYER_SCALE] ?: 0.45f
        }

    suspend fun setMiniPlayerScale(scale: Float) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.MINI_PLAYER_SCALE] = scale
        }
    }


    val miniPlayerContinueWatchingEnabled: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.MINI_PLAYER_CONTINUE_WATCHING_ENABLED] ?: true
        }

    suspend fun setMiniPlayerContinueWatchingEnabled(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.MINI_PLAYER_CONTINUE_WATCHING_ENABLED] = enabled
        }
    }

    val playDuringCalls: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.PLAY_DURING_CALLS] ?: false
        }

    suspend fun setPlayDuringCalls(enabled: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.PLAY_DURING_CALLS] = enabled
        }
    }

    val miniPlayerShowSkipControls: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.MINI_PLAYER_SHOW_SKIP_CONTROLS] ?: false
        }

    suspend fun setMiniPlayerShowSkipControls(show: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.MINI_PLAYER_SHOW_SKIP_CONTROLS] = show
        }
    }

    val miniPlayerShowNextPrevControls: Flow<Boolean> = context.playerPreferencesDataStore.data
        .map { preferences ->
            preferences[Keys.MINI_PLAYER_SHOW_NEXT_PREV_CONTROLS] ?: false
        }

    suspend fun setMiniPlayerShowNextPrevControls(show: Boolean) {
        context.playerPreferencesDataStore.edit { preferences ->
            preferences[Keys.MINI_PLAYER_SHOW_NEXT_PREV_CONTROLS] = show
        }
    }

    suspend fun getExportData(): SettingsBackup {
        val prefs = context.playerPreferencesDataStore.data.first()
        val strings = mutableMapOf<String, String>()
        val booleans = mutableMapOf<String, Boolean>()
        val ints = mutableMapOf<String, Int>()
        val floats = mutableMapOf<String, Float>()
        val longs = mutableMapOf<String, Long>()

        prefs.asMap().forEach { (key, value) ->
            when (value) {
                is String -> strings[key.name] = value
                is Boolean -> booleans[key.name] = value
                is Int -> ints[key.name] = value
                is Float -> floats[key.name] = value
                is Long -> longs[key.name] = value
            }
        }
        return SettingsBackup(strings, booleans, ints, floats, longs)
    }

    suspend fun restoreData(backup: SettingsBackup) {
        context.playerPreferencesDataStore.edit { prefs ->
            backup.strings.forEach { (k, v) -> prefs[stringPreferencesKey(k)] = v }
            backup.booleans.forEach { (k, v) -> prefs[booleanPreferencesKey(k)] = v }
            backup.ints.forEach { (k, v) -> prefs[intPreferencesKey(k)] = v }
            backup.floats.forEach { (k, v) -> prefs[floatPreferencesKey(k)] = v }
            backup.longs.forEach { (k, v) -> prefs[longPreferencesKey(k)] = v }
        }
    }
}

/** Action to take when a SponsorBlock segment is encountered. */
enum class SponsorBlockAction(val displayName: String) {
    SKIP("Lewati"),
    MUTE("Bisukan"),
    SHOW_TOAST("Hanya beri tahu"),
    IGNORE("Abaikan");

    companion object {
        fun fromString(name: String): SponsorBlockAction =
            values().find { it.name == name } ?: SKIP
    }
}

enum class BufferProfile(
    val label: String,
    val minBuffer: Int,
    val maxBuffer: Int,
    val playbackBuffer: Int,
    val rebufferBuffer: Int
) {
    // Fast Start: Prioritize quick playback start over buffer stability
    AGGRESSIVE("Mulai Cepat", 10_000, 30_000, 500, 1_500),      
    // Balanced: Good default for most connections
    STABLE("Seimbang", 15_000, 50_000, 1_000, 2_500),        
    // Data Saver: Minimize data usage with smaller buffers
    DATASAVER("Hemat Data", 12_000, 25_000, 1_500, 3_000),                   
    // Custom: User-defined values
    CUSTOM("Khusus", -1, -1, -1, -1);                                    

    companion object {
        fun fromString(name: String): BufferProfile = values().find { it.name == name } ?: STABLE
    }
}

enum class VideoQuality(val label: String, val height: Int) {
    Q_144p("144p", 144),
    Q_240p("240p", 240),
    Q_360p("360p", 360),
    Q_480p("480p", 480),
    Q_720p("720p", 720),
    Q_1080p("1080p", 1080),
    Q_1440p("1440p", 1440),
    Q_2160p("2160p", 2160), // 4K
    AUTO("Otomatis", 0);
    
    companion object {
        fun fromString(label: String): VideoQuality {
            return values().find { it.label == label } ?: AUTO
        }
        
        fun fromHeight(height: Int): VideoQuality {
            return values()
                .filter { it != AUTO }
                .minByOrNull { kotlin.math.abs(it.height - height) } ?: Q_720p
        }
    }
}

enum class SliderStyle {
    DEFAULT,
    METROLIST,      
    METROLIST_SLIM, 
    SQUIGGLY,
    SLIM         
}

enum class HomeViewMode {
    GRID,
    LIST
}

enum class PlayerRelatedCardStyle {
    COMPACT,    
    FULL_WIDTH 
}


