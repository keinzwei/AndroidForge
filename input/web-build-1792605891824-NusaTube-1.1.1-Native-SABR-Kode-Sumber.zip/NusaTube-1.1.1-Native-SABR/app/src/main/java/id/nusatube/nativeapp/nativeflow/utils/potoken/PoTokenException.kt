// SPDX-License-Identifier: GPL-3.0-only
// Ported from Flow v3.0.0 (A-EDev), 9b592728f96de4efdb3b0041331bb3b44bfe054c.
package id.nusatube.nativeapp.nativeflow.utils.potoken

/**
 * This is based and ported from Metrolist,
 * see https://github.com/MetrolistGroup/Metrolist for the original code and license.
 */
class PoTokenException(message: String) : Exception(message)

// to be thrown if the WebView provided by the system is broken
class BadWebViewException(message: String) : Exception(message)

fun buildExceptionForJsError(error: String): Exception {
    return if (error.contains("SyntaxError"))
        BadWebViewException(error)
    else
        PoTokenException(error)
}
