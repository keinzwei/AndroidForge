package id.nusatube.nativeapp.data.model

import org.schabi.newpipe.extractor.stream.StreamInfoItem

/** Shorts may use a regular watch URL, so the extractor flag takes precedence.
 * Duration alone cannot distinguish a Short from a normal short video.
 */
val StreamInfoItem.isShortVideo: Boolean
    get() = isShortFormContent || url.orEmpty().contains("/shorts/", ignoreCase = true)
