package id.nusatube.nativeapp.ui.screens.home

import android.content.Context
import id.nusatube.nativeapp.ui.components.NusaHomeCategories
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import id.nusatube.nativeapp.data.recommendation.NusaTubeNeuroEngine
import id.nusatube.nativeapp.data.local.SubscriptionRepository
import id.nusatube.nativeapp.data.local.ViewHistory
import id.nusatube.nativeapp.data.model.Video
import id.nusatube.nativeapp.data.model.toVideo
import id.nusatube.nativeapp.data.repository.YouTubeRepository
import id.nusatube.nativeapp.data.shorts.ShortsRepository
import id.nusatube.nativeapp.ui.components.FeedInvalidationBus
import id.nusatube.nativeapp.utils.PerformanceDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withTimeoutOrNull
import org.schabi.newpipe.extractor.Page

import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: YouTubeRepository,
    private val subscriptionRepository: SubscriptionRepository, 
    private val shortsRepository: ShortsRepository,
    private val playerPreferences: id.nusatube.nativeapp.data.local.PlayerPreferences
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()
    
    private var currentPage: Page? = null
    private var feedJob: Job? = null
    private var pagingJob: Job? = null
    private var isLoadingMore = false
    private var isInitialized = false
    
    private var currentQueryIndex = 0
    private val discoveryQueries = mutableListOf<String>()
    
    private var viewHistory: ViewHistory? = null
    
    private val sessionWatchedTopics = mutableListOf<String>()

    // Video IDs the user has watched >=90 % — excluded from recommendations.
    private val watchedVideoIds = MutableStateFlow<Set<String>>(emptySet())
    
    init {
        if (HomeFeedCache.isFresh()) {
            _uiState.update {
                it.copy(
                    videos = HomeFeedCache.videos.filterNot { it.isShort },
                    shorts = emptyList(),
                    isLoading = false,
                    isNusaTubeFeed = true,
                    lastRefreshTime = HomeFeedCache.timestamp
                )
            }
        } else {
            loadNusaTubeFeed(forceRefresh = true)
        }
    }
    

    fun initialize(context: Context) {
        if (isInitialized) return
        isInitialized = true
        
        viewHistory = ViewHistory.getInstance(context)
        
        // Keep the watched-IDs set up to date so the feed can filter them out.
        // When hideWatchedVideos is ON: filter ALL history items from the feed.
        // When OFF: keep current behaviour (only >=90% watched are excluded).
        viewModelScope.launch {
            viewHistory!!.getVideoHistoryFlow()
                .combine(playerPreferences.hideWatchedVideos) { history, hideWatched ->
                    if (hideWatched) {
                        history.map { it.videoId }.toHashSet()
                    } else {
                        history.filter { it.progressPercentage >= 90f }
                            .map { it.videoId }
                            .toHashSet()
                    }
                }
                .collect { ids -> watchedVideoIds.value = ids }
        }
        
        viewModelScope.launch {
            NusaTubeNeuroEngine.initialize(context)
        }

        viewModelScope.launch {
            FeedInvalidationBus.events.collect { event ->
                when (event) {
                    is FeedInvalidationBus.Event.ChannelBlocked -> {
                        HomeFeedCache.filterOut(channelId = event.channelId)
                        _uiState.update { state ->
                            state.copy(
                                videos = state.videos.filter { it.channelId != event.channelId },
                                shorts = state.shorts.filter { it.channelId != event.channelId }
                            )
                        }
                        // Targeted eviction — preserves other channel caches in discovery engine
                        shortsRepository.evictChannel(event.channelId)
                    }
                    is FeedInvalidationBus.Event.NotInterested -> {
                        HomeFeedCache.filterOut(videoId = event.videoId)
                        _uiState.update { state ->
                            state.copy(
                                videos = state.videos.filter { it.id != event.videoId }
                            )
                        }
                        // Full clear — topic signals changed, discovery queries will differ
                        shortsRepository.clearCaches()
                    }
                    is FeedInvalidationBus.Event.MarkedWatched -> {
                        HomeFeedCache.filterOut(videoId = event.videoId)
                        _uiState.update { state ->
                            state.copy(
                                videos = state.videos.filter { it.id != event.videoId }
                            )
                        }
                    }
                }
            }
        }

        viewModelScope.launch {
            playerPreferences.continueWatchingEnabled.collect { enabled ->
                if (!enabled) {
                    _uiState.update { it.copy(continueWatchingVideos = emptyList()) }
                } else {
                    loadContinueWatching()
                }
            }
        }
    }

    private fun loadContinueWatching() {
        viewModelScope.launch {
            viewHistory?.getVideoHistoryFlow()?.collect { history ->
                val inProgress = history
                    .filter { it.progressPercentage in 3f..90f }
                    .sortedByDescending { it.timestamp }
                    .take(20)
                _uiState.update { it.copy(continueWatchingVideos = inProgress) }
            }
        }
    }
    

    private fun updateVideosAndShorts(newVideos: List<Video>, append: Boolean = false) {
        val regularVideos = newVideos.filterNot { it.isShort }
        
        _uiState.update { state ->
            val updatedVideos = if (append) (state.videos + regularVideos) else regularVideos
            state.copy(
                videos = updatedVideos.distinctBy { it.id },
                shorts = emptyList()
            )
        }
    }

    
    fun loadNusaTubeFeed(forceRefresh: Boolean = false) {
        if (_uiState.value.selectedCategory != NusaHomeCategories.MIX) {
            loadCategoryVideos(append = false)
            return
        }
        if (_uiState.value.isLoading && !forceRefresh) return
        
        feedJob?.cancel()
        pagingJob?.cancel()
        isLoadingMore = false
        _uiState.update { it.copy(isLoading = true, isLoadingMore = false, error = null) }

        feedJob = viewModelScope.launch(PerformanceDispatcher.networkIO) {
            try {
                discoveryQueries.clear()
                discoveryQueries.addAll(NusaTubeNeuroEngine.generateDiscoveryQueries())
                currentQueryIndex = 0
                
                val userSubs = subscriptionRepository.getAllSubscriptionIds()
                val region = playerPreferences.trendingRegion.first()

                val results = supervisorScope {
                    val deferredSubs = async {
                        if (userSubs.isNotEmpty()) {
                            runCatching { 
                                repository.getSubscriptionFeed(userSubs.toList())
                            }.getOrElse { emptyList() }
                        } else emptyList()
                    }

                    val deferredDiscovery = async {
                        val queries = discoveryQueries.take(3)
                        queries.map { query ->
                            async { 
                                runCatching { 
                                    repository.searchVideos(query).first
                                }.getOrElse { emptyList() }
                            }
                        }.awaitAll().flatten()
                    }
                    
                    val deferredViral = async {
                        runCatching {
                             repository.getTrendingVideos(region).first
                        }.getOrElse { emptyList() }
                    }

                    // ── Fast first paint ────────────────────────────────────────
                    val viralResult = deferredViral.await()
                    if (viralResult.isNotEmpty()) {
                        val watched = watchedVideoIds.value
                        val quickFeed = NusaTubeNeuroEngine.rank(
                            viralResult.filterValid().filterWatched(watched), userSubs
                        ).take(15)
                        if (quickFeed.isNotEmpty()) {
                            _uiState.update { state ->
                                state.copy(
                                    videos = quickFeed,
                                    isLoading = true,
                                    isNusaTubeFeed = true
                                )
                            }
                        }
                    }

                    Triple(deferredSubs.await(), deferredDiscovery.await(), viralResult)
                }
                
                currentQueryIndex = 3
                
                val (rawSubs, rawDiscovery, rawViral) = results

                val subAvatarMap: Map<String, String> = runCatching {
                    subscriptionRepository.getAllSubscriptions().first()
                        .filter { it.channelThumbnail.isNotEmpty() }
                        .associate { it.channelId to it.channelThumbnail }
                }.getOrElse { emptyMap() }

                fun List<Video>.enrichAvatars(): List<Video> =
                    if (subAvatarMap.isEmpty()) this
                    else map { v ->
                        if (v.channelThumbnailUrl.isEmpty() && subAvatarMap.containsKey(v.channelId))
                            v.copy(channelThumbnailUrl = subAvatarMap.getValue(v.channelId))
                        else v
                    }

                // Filter to regular videos for the main feed
                val watched = watchedVideoIds.value
                val subsPool = rawSubs.filterValid().filterWatched(watched).enrichAvatars()
                val discoveryPool = rawDiscovery.filterValid().filterWatched(watched)
                val viralPool = rawViral.filterValid().filterWatched(watched)
                
                val bestSubs = NusaTubeNeuroEngine.rank(subsPool, userSubs).take(10)
                val bestDiscovery = NusaTubeNeuroEngine.rank(discoveryPool, userSubs)
                    .filter { video ->
                        val isOld = video.uploadDate.contains("year") && 
                                    (video.uploadDate.filter { it.isDigit() }.toIntOrNull() ?: 0) > 4
                        
                        val isClassic = video.viewCount > 5_000_000 
                        
                        !isOld || isClassic
                    }
                    .take(15) 
                val bestViral = NusaTubeNeuroEngine.rank(viralPool, userSubs).take(10)

                val finalMix = mutableListOf<Video>()
                val usedChannelIds = mutableSetOf<String>()
                
                val qSubs = java.util.ArrayDeque(bestSubs)
                val qDisc = java.util.ArrayDeque(bestDiscovery)
                val qViral = java.util.ArrayDeque(bestViral)
                
                while (qSubs.isNotEmpty() || qDisc.isNotEmpty() || qViral.isNotEmpty()) {
                    addUnique(qDisc.pollFirst(), finalMix, usedChannelIds)
                    
                    addUnique(qSubs.pollFirst(), finalMix, usedChannelIds)
                    
                    addUnique(qDisc.pollFirst(), finalMix, usedChannelIds)
                    
                    addUnique(qViral.pollFirst(), finalMix, usedChannelIds)
                }

                if (finalMix.isEmpty()) {
                   loadTrendingFallback()
                   return@launch
                }

                val now = System.currentTimeMillis()
                _uiState.update { it.copy(
                    videos = finalMix, 
                    isLoading = false,
                    isRefreshing = false,
                    hasMorePages = true,
                    isNusaTubeFeed = true,
                    lastRefreshTime = now
                )}
                HomeFeedCache.update(finalMix, _uiState.value.shorts)
                
            } catch (e: CancellationException) { throw e } catch (e: Exception) {
                 _uiState.update { it.copy(isLoading = false, isRefreshing = false, error = "Rekomendasi tidak dapat dimuat") }
                 loadTrendingFallback() 
            }
        }
    }
    

    fun loadMoreVideos() {
        if (_uiState.value.isLoading) return
        if (_uiState.value.selectedCategory != NusaHomeCategories.MIX) {
            if (_uiState.value.hasMorePages) loadCategoryVideos(append = true)
            return
        }
        if (isLoadingMore) return
        
        isLoadingMore = true
        _uiState.update { it.copy(isLoadingMore = true) }
        
        viewModelScope.launch(PerformanceDispatcher.networkIO) {
            try {

                if (currentQueryIndex >= discoveryQueries.size) {
                    discoveryQueries.addAll(NusaTubeNeuroEngine.generateDiscoveryQueries())
                }
                
                val queryA = discoveryQueries.getOrNull(currentQueryIndex++)
                val queryB = discoveryQueries.getOrNull(currentQueryIndex++)
                
                val searchQueries = listOfNotNull(queryA, queryB)
                
                val finalQueries = if (searchQueries.isEmpty()) listOf("Viral") else searchQueries

                val rawVideos = finalQueries.map { q ->
                   async { 
                       runCatching {
                           repository.searchVideos(q).first
                       }.getOrElse { emptyList() }
                   }
                }.awaitAll().flatten()
                
                val newVideos = rawVideos.filterValid().filterWatched(watchedVideoIds.value)

                
                if (newVideos.isNotEmpty()) {
                    val userSubs = subscriptionRepository.getAllSubscriptionIds()
                    val rankedBatch = NusaTubeNeuroEngine.rank(newVideos, userSubs)
                                        .shuffled()
                                        .distinctBy { it.channelId } 
                    
                    _uiState.update { state ->
                        val currentIds = state.videos.map { it.id }.toHashSet()
                        val uniqueNew = rankedBatch.filter { !currentIds.contains(it.id) }
                        state.copy(
                            videos = state.videos + uniqueNew,
                            isLoadingMore = false,
                            hasMorePages = true
                        )
                    }
                } else {
                    _uiState.update { it.copy(isLoadingMore = false) }
                }
            } catch (e: CancellationException) { throw e } catch (e: Exception) {
                 _uiState.update { it.copy(isLoadingMore = false) }
            } finally {
                isLoadingMore = false
            }
        }
    }
    

    fun loadTrendingVideos() {
        if (_uiState.value.isLoading && _uiState.value.videos.isEmpty()) return
        _uiState.update { it.copy(isLoading = true, error = null) }

        viewModelScope.launch {
            try {
                val region = playerPreferences.trendingRegion.first()
                val (videos, nextPage) = repository.getTrendingVideos(region, null)
                currentPage = nextPage

                val userSubs = subscriptionRepository.getAllSubscriptionIds()
                val ranked = NusaTubeNeuroEngine.rank(videos, userSubs)
                updateVideosAndShorts(ranked, append = false)

                _uiState.update { it.copy(
                    isLoading = false,
                    hasMorePages = nextPage != null,
                    isNusaTubeFeed = false
                )}
            } catch (e: CancellationException) { throw e } catch (e: Exception) {
                _uiState.update { it.copy(
                    isLoading = false,
                    error = e.message ?: "Video tidak dapat dimuat"
                ) }
            }
        }
    }

    private suspend fun loadTrendingFallback() {
        val region = playerPreferences.trendingRegion.first()
        val (videos, nextPage) = repository.getTrendingVideos(region, null)
        currentPage = nextPage

        val userSubs = subscriptionRepository.getAllSubscriptionIds()
        val ranked = NusaTubeNeuroEngine.rank(videos, userSubs)
        updateVideosAndShorts(ranked, append = false)
        _uiState.update { it.copy(
            isLoading = false,
            hasMorePages = nextPage != null,
            isNusaTubeFeed = false,
            error = null
        )}
    }
    
    fun refreshFeed() {
        HomeFeedCache.clear()
        _uiState.update { it.copy(isRefreshing = true) }
        loadNusaTubeFeed(forceRefresh = true)
    }
    
    fun selectCategory(category: String) {
        if (category == _uiState.value.selectedCategory) return
        if (NusaHomeCategories.items.none { it.label == category }) return
        feedJob?.cancel()
        pagingJob?.cancel()
        isLoadingMore = false
        currentPage = null
        _uiState.update {
            it.copy(selectedCategory = category, videos = emptyList(), isLoading = false,
                isLoadingMore = false, isRefreshing = false, error = null, hasMorePages = true)
        }
        loadNusaTubeFeed(forceRefresh = true)
    }

    private fun loadCategoryVideos(append: Boolean) {
        if (append && (isLoadingMore || _uiState.value.isLoading || !_uiState.value.hasMorePages)) return
        val category = _uiState.value.selectedCategory
        val query = NusaHomeCategories.items.firstOrNull { it.label == category }?.query ?: return
        if (query.isBlank()) return
        if (!append) {
            feedJob?.cancel()
            pagingJob?.cancel()
            currentPage = null
        }
        isLoadingMore = append
        _uiState.update { it.copy(isLoading = !append, isLoadingMore = append, error = null) }
        val job = viewModelScope.launch(PerformanceDispatcher.networkIO) {
            try {
                val (results, next) = repository.searchVideos(query, if (append) currentPage else null)
                if (_uiState.value.selectedCategory != category) return@launch
                currentPage = next
                val videos = results.filter { !it.isShort }.filterWatched(watchedVideoIds.value)
                _uiState.update { state ->
                    val combined = (if (append) state.videos + videos else videos).distinctBy { it.id }
                    state.copy(videos = combined, isLoading = false, isRefreshing = false,
                        isLoadingMore = false, hasMorePages = next != null,
                        error = if (combined.isEmpty()) "Video belum ditemukan. Coba muat ulang." else null)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (_uiState.value.selectedCategory == category) _uiState.update {
                    it.copy(isLoading = false, isRefreshing = false, isLoadingMore = false,
                        error = "Video belum dapat dimuat. Coba lagi.")
                }
            } finally {
                if (_uiState.value.selectedCategory == category) isLoadingMore = false
            }
        }
        if (append) pagingJob = job else feedJob = job
    }

    fun retry() {
        loadNusaTubeFeed(forceRefresh = true)
    }


    private fun addUnique(
        video: Video?, 
        targetList: MutableList<Video>, 
        usedChannels: MutableSet<String>
    ) {
        if (video == null) return
        

        if (!usedChannels.contains(video.channelId)) {
            targetList.add(video)
            usedChannels.add(video.channelId)
        }
    }
    
    private fun List<Video>.filterValid(): List<Video> {
        return this.filter { 
            !it.isShort && (it.duration > 0 || it.isLive) 
        }
    }
    
    /**
     * Remove videos the user has already fully watched (≥90 % progress)
     * so they don't re-appear in the home feed.
     */
    private fun List<Video>.filterWatched(watchedIds: Set<String>): List<Video> {
        if (watchedIds.isEmpty()) return this
        return this.filter { !watchedIds.contains(it.id) }
    }
}

/**
 * Process-lifetime in-memory cache for the Home feed.
 *
 * Survives ViewModel recreation (which happens when the user navigates away
 * from Home and comes back via the bottom nav), preventing an unwanted
 * network reload on every tab switch. The cache expires after [CACHE_TTL_MS]
 * (default 30 minutes) and is explicitly cleared when the user pulls-to-refresh.
 */
internal object HomeFeedCache {
    private const val CACHE_TTL_MS = 30 * 60 * 1000L // 30 minutes

    @Volatile var videos: List<Video> = emptyList()
        private set
    @Volatile var shorts: List<Video> = emptyList()
        private set
    @Volatile var timestamp: Long = 0L
        private set

    fun isFresh(): Boolean =
        videos.isNotEmpty() && (System.currentTimeMillis() - timestamp) < CACHE_TTL_MS

    fun update(newVideos: List<Video>, newShorts: List<Video>) {
        videos = newVideos
        shorts = newShorts
        timestamp = System.currentTimeMillis()
    }

    fun clear() {
        videos = emptyList()
        shorts = emptyList()
        timestamp = 0L
    }

    /**
     * Remove videos by blocked channel/topic from the cached feed without
     * requiring a network refetch, keeping the cache TTL alive.
     */
    fun filterOut(channelId: String? = null, videoId: String? = null) {
        if (channelId != null) {
            videos = videos.filter { it.channelId != channelId }
            shorts = shorts.filter { it.channelId != channelId }
        }
        if (videoId != null) {
            videos = videos.filter { it.id != videoId }
            shorts = shorts.filter { it.id != videoId }
        }
    }
}

data class HomeUiState(
    val videos: List<Video> = emptyList(),
    val selectedCategory: String = NusaHomeCategories.MIX,
    val shorts: List<Video> = emptyList(),
    val continueWatchingVideos: List<id.nusatube.nativeapp.data.local.VideoHistoryEntry> = emptyList(),
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val isRefreshing: Boolean = false,
    val hasMorePages: Boolean = true,
    val error: String? = null,
    val isNusaTubeFeed: Boolean = false,
    val lastRefreshTime: Long = 0L
)
