package id.nusatube.nativeapp.innertube.pages

import id.nusatube.nativeapp.innertube.models.YTItem

data class LibraryContinuationPage(
    val items: List<YTItem>,
    val continuation: String?,
)
