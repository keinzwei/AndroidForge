package id.nusatube.nativeapp.nativeflow

import id.nusatube.nativeapp.nativeflow.innertube.models.response.PlayerResponse
import id.nusatube.nativeapp.nativeflow.player.sabr.integration.SabrStreamInfo

internal object NativeSabrSelection {
    fun select(
        base: SabrStreamInfo,
        formats: List<PlayerResponse.StreamingData.Format>,
        videoItag: String?,
        audioItag: String?,
        audioTrack: String,
    ): SabrStreamInfo {
        val video = formats.firstOrNull { !it.isAudio && it.itag.toString() == videoItag }
        val audio = formats.firstOrNull {
            it.isAudio && it.itag.toString() == audioItag && it.audioTrack?.id.orEmpty() == audioTrack
        } ?: formats.firstOrNull { it.isAudio && it.itag == base.audioItag }
        return base.copy(
            videoItag = video?.itag ?: base.videoItag,
            videoLmt = video?.lastModified ?: base.videoLmt,
            videoMimeType = video?.mimeType ?: base.videoMimeType,
            videoXtags = video?.xtags ?: base.videoXtags,
            videoHeight = video?.height ?: base.videoHeight,
            targetHeight = video?.height ?: base.targetHeight,
            audioItag = audio?.itag ?: base.audioItag,
            audioLmt = audio?.lastModified ?: base.audioLmt,
            audioMimeType = audio?.mimeType ?: base.audioMimeType,
            audioXtags = audio?.xtags ?: base.audioXtags,
            audioTrackId = audio?.audioTrack?.id ?: base.audioTrackId,
        )
    }
}
