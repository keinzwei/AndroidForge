// SPDX-License-Identifier: GPL-3.0-only
// Player request bodies adapted from Flow v3.0.0, A-EDev.
package id.nusatube.nativeapp.nativeflow.innertube

import id.nusatube.nativeapp.nativeflow.innertube.models.YouTubeClient
import id.nusatube.nativeapp.nativeflow.innertube.models.YouTubeLocale
import id.nusatube.nativeapp.nativeflow.innertube.models.Context
import id.nusatube.nativeapp.nativeflow.innertube.models.body.PlayerBody
import id.nusatube.nativeapp.nativeflow.innertube.models.response.PlayerResponse
import id.nusatube.nativeapp.nativeflow.network.ProxyAwareClient
import id.nusatube.nativeapp.nativeflow.utils.potoken.VisitorIdentityStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.contentOrNull
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Request
import okhttp3.Response
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Native, account-free player transport. NusaTube's music API stays independent. */
object YouTube {
    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        coerceInputValues = true
        encodeDefaults = true
    }
    private val clients = ProxyAwareClient {
        connectTimeout(10, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS)
    }
    private var identityStore: VisitorIdentityStore? = null
    @Volatile private var visitor: String? = null

    var visitorData: String?
        get() = visitor
        set(value) {
            visitor = value
            identityStore?.save(value)
        }

    fun initialize(store: VisitorIdentityStore) {
        identityStore = store
        visitor = store.restore()
    }

    suspend fun visitorData(): Result<String> = cancellableResult {
        val request = Request.Builder().url("https://music.youtube.com/sw.js_data")
            .header("User-Agent", YouTubeClient.USER_AGENT_WEB).build()
        val text = execute(request).removePrefix(")]}'\n")
        Json.parseToJsonElement(text).jsonArray[0].jsonArray[2].jsonArray
            .firstOrNull {
                (it as? JsonPrimitive)?.contentOrNull?.let { value ->
                    value.startsWith("Cgt") || value.startsWith("Cgs")
                } == true
            }?.jsonPrimitive?.content
            ?: throw IOException("YouTube visitor identity unavailable")
    }

    suspend fun player(
        videoId: String,
        playlistId: String? = null,
        client: YouTubeClient,
        signatureTimestamp: Int? = null,
        poToken: String? = null,
        localeOverride: YouTubeLocale? = null,
        apiUrl: String? = null,
    ): Result<PlayerResponse> = cancellableResult {
        var context = client.toContext(localeOverride ?: YouTubeLocale.EXTRACTION, visitorData, null)
        if (client.isEmbedded) {
            context = context.copy(thirdParty = Context.ThirdParty("https://www.youtube.com/watch?v=$videoId"))
        }
        requestPlayer(client, visitorData, (apiUrl ?: YouTubeClient.API_URL_YOUTUBE) + "player",
            PlayerBody(
                context = context, videoId = videoId, playlistId = playlistId,
                playbackContext = signatureTimestamp?.takeIf { client.useSignatureTimestamp }?.let {
                    PlayerBody.PlaybackContext(PlayerBody.PlaybackContext.ContentPlaybackContext(it))
                },
                serviceIntegrityDimensions = poToken?.let { PlayerBody.ServiceIntegrityDimensions(it) },
            ))
    }

    suspend fun playerWeb(
        videoId: String,
        signatureTimestamp: Int?,
        poToken: String?,
        visitorData: String?,
        locale: YouTubeLocale,
        cpn: String?,
        reloadToken: String? = null,
        client: YouTubeClient = YouTubeClient.WEB,
    ): Result<PlayerResponse> = cancellableResult {
        requestPlayer(client, visitorData, YouTubeClient.API_URL_YOUTUBE + "player",
            PlayerBody(
                context = client.toContext(locale, visitorData, null),
                videoId = videoId, playlistId = null,
                playbackContext = if (signatureTimestamp != null || reloadToken != null) {
                    PlayerBody.PlaybackContext(
                        contentPlaybackContext = signatureTimestamp?.let {
                            PlayerBody.PlaybackContext.ContentPlaybackContext(it,
                                referer = "https://www.youtube.com/watch?v=$videoId", vis = 0,
                                splay = false, lactMilliseconds = "-1", html5Preference = "HTML5_PREF_WANTS")
                        },
                        reloadPlaybackContext = reloadToken?.let {
                            PlayerBody.PlaybackContext.ReloadPlaybackContext(
                                PlayerBody.PlaybackContext.ReloadPlaybackContext.ReloadPlaybackParams(it))
                        },
                    )
                } else null,
                serviceIntegrityDimensions = poToken?.let { PlayerBody.ServiceIntegrityDimensions(it) },
                cpn = cpn,
            ))
    }

    private suspend fun requestPlayer(
        client: YouTubeClient, visitorData: String?, url: String, body: PlayerBody,
    ): PlayerResponse {
        val request = Request.Builder().url("$url?prettyPrint=false")
            .header("User-Agent", client.userAgent)
            .header("X-Goog-Api-Format-Version", "1")
            .header("X-YouTube-Client-Name", client.clientId)
            .header("X-YouTube-Client-Version", client.clientVersion)
            .header("X-Origin", YouTubeClient.ORIGIN_YOUTUBE)
            .header("Referer", YouTubeClient.REFERER_YOUTUBE)
            .apply { visitorData?.let { header("X-Goog-Visitor-Id", it) } }
            .post(json.encodeToString(body).toRequestBody("application/json".toMediaType())).build()
        return json.decodeFromString<PlayerResponse>(execute(request))
    }

    private suspend fun execute(request: Request): String {
        val call = clients.get().newCall(request)
        return suspendCancellableCoroutine { continuation ->
            continuation.invokeOnCancellation { call.cancel() }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (continuation.isActive) continuation.resumeWithException(e)
                }
                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        if (!continuation.isActive) return
                        try {
                            if (!it.isSuccessful) throw IOException("YouTube HTTP ${it.code}")
                            continuation.resume(it.body?.string() ?: throw IOException("Empty YouTube response"))
                        } catch (e: Exception) {
                            continuation.resumeWithException(e)
                        }
                    }
                }
            })
        }
    }

    private suspend inline fun <T> cancellableResult(block: () -> T): Result<T> = try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }
}
