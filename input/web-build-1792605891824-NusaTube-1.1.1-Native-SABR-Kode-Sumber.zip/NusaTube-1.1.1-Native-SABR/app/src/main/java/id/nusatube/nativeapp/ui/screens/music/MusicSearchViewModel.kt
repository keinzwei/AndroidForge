package id.nusatube.nativeapp.ui.screens.music

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import id.nusatube.nativeapp.innertube.YouTube
import id.nusatube.nativeapp.innertube.YouTube.SearchFilter
import id.nusatube.nativeapp.innertube.models.SearchSuggestions
import id.nusatube.nativeapp.innertube.models.YTItem
import id.nusatube.nativeapp.innertube.pages.SearchSummaryPage
import id.nusatube.nativeapp.utils.PerformanceDispatcher
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import javax.inject.Inject

@OptIn(FlowPreview::class)
@HiltViewModel
class MusicSearchViewModel @Inject constructor() : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _uiState = MutableStateFlow(MusicSearchUiState())
    val uiState: StateFlow<MusicSearchUiState> = _uiState.asStateFlow()

    init {
        // Handle search suggestions with debounce
        _query
            .debounce(300)
            .filter { it.isNotBlank() }
            .onEach { q ->
                fetchSuggestions(q)
            }
            .launchIn(viewModelScope)
    }

    fun onQueryChange(newQuery: String) {
        _query.value = newQuery
        if (newQuery.isBlank()) {
            _uiState.update { it.copy(suggestions = emptyList(), recommendedItems = emptyList()) }
        }
    }

    /**
     *  PERFORMANCE OPTIMIZED: Fetch suggestions with timeout
     */
    private fun fetchSuggestions(q: String) {
        viewModelScope.launch(PerformanceDispatcher.networkIO) {
            val result = withTimeoutOrNull(5_000L) {
                YouTube.searchSuggestions(q)
            }
            
            result?.onSuccess { suggestions ->
                _uiState.update { it.copy(
                    suggestions = suggestions.queries,
                    recommendedItems = suggestions.recommendedItems
                ) }
            }?.onFailure { throwable ->
                android.util.Log.w("MusicSearchViewModel", "Suggestions failed: ${throwable.message}")
                _uiState.update { it.copy(suggestions = emptyList(), recommendedItems = emptyList()) }
            }
        }
    }

    /**
     *  PERFORMANCE OPTIMIZED: Perform search with timeout protection
     */
    fun performSearch(q: String = _query.value) {
        if (q.isBlank()) return
        
        _query.value = q
        _uiState.update { it.copy(isLoading = true, isSearching = true, activeFilter = null) }
        
        viewModelScope.launch(PerformanceDispatcher.networkIO) {
            val result = withTimeoutOrNull(15_000L) {
                YouTube.searchSummary(q)
            }
            
            result?.onSuccess { summaryPage ->
                _uiState.update { state -> state.copy(
                    searchSummary = summaryPage,
                    isLoading = false,
                    isSearching = true,
                    continuation = summaryPage.continuation
                ) }
            }?.onFailure { throwable ->
                _uiState.update { state -> state.copy(isLoading = false, error = throwable.message) }
            } ?: run {
                _uiState.update { state -> state.copy(isLoading = false, error = "Waktu pencarian habis") }
            }
        }
    }

    /**
     *  PERFORMANCE OPTIMIZED: Apply filter with timeout protection
     */
    fun applyFilter(filter: SearchFilter?) {
        val q = _query.value
        if (q.isBlank()) return
        
        _uiState.update { state -> state.copy(isLoading = true, activeFilter = filter) }
        
        viewModelScope.launch(PerformanceDispatcher.networkIO) {
            if (filter == null) {
                performSearch(q)
            } else {
                val result = withTimeoutOrNull(12_000L) {
                    YouTube.search(q, filter)
                }
                
                result?.onSuccess { searchResult ->
                    _uiState.update { state -> state.copy(
                        filteredResults = searchResult.items,
                        isLoading = false,
                        continuation = searchResult.continuation
                    ) }
                }?.onFailure { throwable ->
                    _uiState.update { state -> state.copy(isLoading = false, error = throwable.message) }
                } ?: run {
                    _uiState.update { state -> state.copy(isLoading = false, error = "Waktu pencarian dengan filter habis") }
                }
            }
        }
    }

    fun clearSearch() {
        _query.value = ""
        _uiState.value = MusicSearchUiState()
    }

    /**
     *  PERFORMANCE OPTIMIZED: Get artist tracks with timeout
     */
    fun getArtistTracks(artistId: String, callback: (List<YTItem>) -> Unit) {
        viewModelScope.launch(PerformanceDispatcher.networkIO) {
            val result = withTimeoutOrNull(10_000L) {
                YouTube.artist(artistId)
            }
            
            result?.onSuccess { artistPage ->
                val songsSection = artistPage.sections.find { it.title.contains("Lagu", ignoreCase = true) }
                val items = songsSection?.items ?: artistPage.sections.firstOrNull()?.items ?: emptyList()
                withContext(Dispatchers.Main) {
                    callback(items)
                }
            }
        }
    }

    fun loadMore() {
        val token = _uiState.value.continuation ?: return
        if (_uiState.value.isMoreLoading) return
        
        viewModelScope.launch(PerformanceDispatcher.networkIO) {
            _uiState.update { it.copy(isMoreLoading = true) }
            val result = YouTube.searchContinuation(token)
            
             result.onSuccess { searchResult ->
                 _uiState.update { state ->
                     if (state.activeFilter == null) {
                         val newSummary = id.nusatube.nativeapp.innertube.pages.SearchSummary(
                             title = "Hasil lainnya", 
                             items = searchResult.items
                         )
                         state.copy(
                             searchSummary = state.searchSummary?.copy(
                                 summaries = state.searchSummary.summaries + newSummary
                             ),
                             continuation = searchResult.continuation,
                             isMoreLoading = false
                         )
                     } else {
                         state.copy(
                             filteredResults = state.filteredResults + searchResult.items,
                             continuation = searchResult.continuation,
                             isMoreLoading = false
                         )
                     }
                 }
             }.onFailure {
                 _uiState.update { it.copy(isMoreLoading = false) }
             }
        }
    }
}

data class MusicSearchUiState(
    val suggestions: List<String> = emptyList(),
    val recommendedItems: List<YTItem> = emptyList(),
    val searchSummary: SearchSummaryPage? = null,
    val filteredResults: List<YTItem> = emptyList(),
    val activeFilter: SearchFilter? = null,
    val isLoading: Boolean = false,
    val isSearching: Boolean = false,
    val error: String? = null,
    val continuation: String? = null,
    val isMoreLoading: Boolean = false
)

