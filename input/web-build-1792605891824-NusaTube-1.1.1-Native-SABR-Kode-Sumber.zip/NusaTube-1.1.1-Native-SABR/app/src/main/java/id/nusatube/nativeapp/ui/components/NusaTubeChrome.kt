// Layout adapted from the supplied NusaTube 1.0.6 UI (AGPL-3.0).
package id.nusatube.nativeapp.ui.components

import android.util.DisplayMetrics
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.nusatube.nativeapp.R

private val ChromeBackground = Color.Black
private val ChromeForeground = Color(0xFFEEEEEE)
private val ChromeSecondary = Color(0xFFBDBDBD)

/** Stable navigation sizing matches the supplied NusaTube header and footer. */
private val navigationDensity: Density
    get() = Density(DisplayMetrics.DENSITY_DEVICE_STABLE / 160f, fontScale = 1f)

@Composable
private fun NavigationScale(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalDensity provides navigationDensity, content = content)
}

@Composable
fun nusaBottomBarContentHeight(): Dp = with(LocalDensity.current) {
    with(navigationDensity) { 80.dp.toPx() }.toDp()
}

data class NusaHomeCategory(val label: String, val query: String)

object NusaHomeCategories {
    const val MIX = "Mix"
    val items = listOf(
        NusaHomeCategory("Mix", ""),
        NusaHomeCategory("Musik", "musik Indonesia"),
        NusaHomeCategory("Permainan", "game Indonesia"),
        NusaHomeCategory("Berita", "berita Indonesia"),
        NusaHomeCategory("Siniar", "podcast Indonesia"),
        NusaHomeCategory("Film dan Animasi", "film animasi Indonesia"),
        NusaHomeCategory("Olahraga", "olahraga Indonesia"),
        NusaHomeCategory("Teknologi", "teknologi Indonesia"),
        NusaHomeCategory("Pendidikan", "edukasi Indonesia"),
        NusaHomeCategory("Memasak", "resep masakan Indonesia")
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NusaTubeHeader(onRefresh: () -> Unit, onSearch: () -> Unit) {
    NavigationScale {
        TopAppBar(
            title = { NusaTubeBrand() },
            actions = {
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Default.Refresh, stringResource(R.string.nusa_reload))
                }
                IconButton(onClick = onSearch) {
                    Icon(Icons.Default.Search, stringResource(R.string.search))
                }
            },
            windowInsets = WindowInsets(0),
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = ChromeBackground,
                scrolledContainerColor = ChromeBackground,
                titleContentColor = ChromeForeground,
                actionIconContentColor = ChromeSecondary
            )
        )
    }
}

@Composable
private fun NusaTubeBrand() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            Modifier.size(width = 33.dp, height = 24.dp)
                .background(Color.Red, RoundedCornerShape(7.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.PlayArrow, null, Modifier.size(23.dp), tint = Color.White)
        }
        Text(
            stringResource(R.string.app_name), fontSize = 22.sp,
            letterSpacing = (-.7).sp, fontWeight = FontWeight.Bold,
            maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
            color = ChromeForeground
        )
    }
}

@Composable
fun NusaTubeCategories(selected: String, onSelect: (String) -> Unit) {
    LazyRow(
        Modifier.fillMaxWidth().background(ChromeBackground),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 8.dp)
    ) {
        item {
            IconButton(
                onClick = { onSelect(NusaHomeCategories.MIX) },
                modifier = Modifier.size(40.dp).background(Color(0xFF424242), RoundedCornerShape(50))
            ) {
                Icon(Icons.Outlined.Explore, stringResource(R.string.nav_explore), tint = ChromeForeground)
            }
        }
        items(NusaHomeCategories.items, key = { it.label }) { category ->
            FilterChip(
                selected = selected == category.label,
                onClick = { onSelect(category.label) },
                label = { Text(category.label, fontSize = 12.sp) },
                shape = RoundedCornerShape(6.dp), border = null,
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = Color(0xFF424242).copy(alpha = .55f),
                    labelColor = ChromeForeground,
                    selectedContainerColor = ChromeForeground,
                    selectedLabelColor = ChromeBackground
                )
            )
        }
    }
}

@Composable
fun NusaTubeBottomNavBar(selectedIndex: Int, onItemSelected: (Int) -> Unit) {
    NavigationScale {
        NavigationBar(
            containerColor = ChromeBackground, contentColor = ChromeSecondary,
            tonalElevation = 0.dp
        ) {
            val indices = listOf(0, 3, 4)
            val labels = listOf(R.string.nav_home, R.string.nav_subs, R.string.nav_library)
            val icons = listOf(Icons.Filled.Home, Icons.Filled.Subscriptions, Icons.Filled.VideoLibrary)
            indices.forEachIndexed { position, index ->
                val label = stringResource(labels[position])
                NavigationBarItem(
                    selected = selectedIndex == index,
                    onClick = { onItemSelected(index) },
                    icon = { Icon(icons[position], label, Modifier.size(24.dp)) },
                    label = {
                        Text(label, fontSize = 11.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Red, selectedTextColor = Color.Red,
                        unselectedIconColor = ChromeSecondary, unselectedTextColor = ChromeSecondary,
                        indicatorColor = Color(0xFF424242).copy(alpha = .35f)
                    )
                )
            }
        }
    }
}
