package id.nusatube.nativeapp.ui.components

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import id.nusatube.nativeapp.data.local.ChannelSubscription
import id.nusatube.nativeapp.data.local.PlaylistRepository
import id.nusatube.nativeapp.data.local.SubscriptionRepository
import id.nusatube.nativeapp.data.model.Video
import id.nusatube.nativeapp.data.recommendation.NusaTubeNeuroEngine
import id.nusatube.nativeapp.data.recommendation.InteractionType
import id.nusatube.nativeapp.data.repository.YouTubeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * Lightweight singleton event bus for feed-visible state changes.
 * Emitted by QuickActionsViewModel, observed by HomeViewModel / ShortsViewModel
 * to instantly strip blocked/disliked content from the cached feed.
 */
object FeedInvalidationBus {
    sealed class Event {
        data class ChannelBlocked(val channelId: String) : Event()
        data class NotInterested(val videoId: String, val channelId: String) : Event()
        data class MarkedWatched(val videoId: String) : Event()
    }

    private val _events = MutableSharedFlow<Event>(extraBufferCapacity = 8)
    val events: SharedFlow<Event> = _events.asSharedFlow()

    fun emit(event: Event) { _events.tryEmit(event) }
}

@HiltViewModel
class QuickActionsViewModel @Inject constructor(
    private val repository: YouTubeRepository,
    private val playlistRepository: PlaylistRepository,
    private val playerPreferences: id.nusatube.nativeapp.data.local.PlayerPreferences,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val subscriptionRepository = SubscriptionRepository.getInstance(context)

    val watchLaterIds = playlistRepository.getWatchLaterIdsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    /** In-memory set of video IDs manually marked as watched this session */
    private val _watchedVideoIds = MutableStateFlow<Set<String>>(emptySet())
    val watchedVideoIds = _watchedVideoIds.asStateFlow()

    /** Per-video subscription state cache: channelId -> Boolean */
    private val _subscribedChannelIds = MutableStateFlow<Set<String>>(emptySet())
    val subscribedChannelIds = _subscribedChannelIds.asStateFlow()

    fun loadSubscriptionState(channelId: String) {
        viewModelScope.launch {
            subscriptionRepository.isSubscribed(channelId).collect { subscribed ->
                if (subscribed) {
                    _subscribedChannelIds.update { it + channelId }
                } else {
                    _subscribedChannelIds.update { it - channelId }
                }
            }
        }
    }

    fun toggleSubscription(channelId: String, channelName: String, channelThumbnail: String) {
        viewModelScope.launch {
            try {
                val isCurrentlySubscribed = _subscribedChannelIds.value.contains(channelId)
                if (isCurrentlySubscribed) {
                    subscriptionRepository.unsubscribe(channelId)
                    _subscribedChannelIds.update { it - channelId }
                    Toast.makeText(context, "Berhenti berlangganan $channelName", Toast.LENGTH_SHORT).show()
                } else {
                    subscriptionRepository.subscribe(
                        ChannelSubscription(
                            channelId = channelId,
                            channelName = channelName,
                            channelThumbnail = channelThumbnail,
                            subscribedAt = System.currentTimeMillis()
                        )
                    )
                    _subscribedChannelIds.update { it + channelId }
                    Toast.makeText(context, "Berlangganan $channelName", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun toggleWatchLater(video: Video) {
        viewModelScope.launch {
            try {
                android.util.Log.d("QuickActionsViewModel", "Toggling Watch Later for video: ${video.id}")
                val isInWatchLater = playlistRepository.isInWatchLater(video.id)
                android.util.Log.d("QuickActionsViewModel", "Is currently in Watch Later: $isInWatchLater")
                
                if (isInWatchLater) {
                    playlistRepository.removeFromWatchLater(video.id)
                    android.util.Log.d("QuickActionsViewModel", "Dihapus dari Tonton Nanti")
                    Toast.makeText(context, "Dihapus dari Tonton Nanti", Toast.LENGTH_SHORT).show()
                } else {
                    playlistRepository.addToWatchLater(video)
                    android.util.Log.d("QuickActionsViewModel", "Ditambahkan ke Tonton Nanti")
                    Toast.makeText(context, "Ditambahkan ke Tonton Nanti", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                android.util.Log.e("QuickActionsViewModel", "Error toggling Watch Later", e)
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Block the channel of a video — the channel will never appear in the feed again.
     * Uses NusaTubeNeuroEngine.blockChannel to persist the block and scrub any existing
     * channel score, mirroring the "Blocked Channels" UI in User Preferences.
     */
    fun blockChannel(video: Video) {
        if (video.channelId.isBlank()) return
        viewModelScope.launch {
            try {
                NusaTubeNeuroEngine.blockChannel(context, video.channelId)
                FeedInvalidationBus.emit(FeedInvalidationBus.Event.ChannelBlocked(video.channelId))
                Toast.makeText(
                    context,
                    context.getString(id.nusatube.nativeapp.R.string.channel_blocked_toast, video.channelName),
                    Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Mark a video as "Not Interested" - this strongly penalizes the video's topics
     * and channel in the NusaTubeNeuroEngine, making similar content much less likely to appear.
     */
    fun markNotInterested(video: Video) {
        viewModelScope.launch {
            try {
                NusaTubeNeuroEngine.markNotInterested(context, video)
                FeedInvalidationBus.emit(
                    FeedInvalidationBus.Event.NotInterested(video.id, video.channelId)
                )
                Toast.makeText(
                    context,
                    "Baik! Konten serupa akan lebih jarang ditampilkan.",
                    Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Mark a video as "Watched" - signals a positive WATCHED interaction to NusaTubeNeuroEngine,
     * boosting the video's topics and channel in recommendations. Useful for quick-starting
     * the algorithm without replaying the whole video.
     */
    fun markAsWatched(video: Video) {
        viewModelScope.launch {
            try {
                NusaTubeNeuroEngine.onVideoInteraction(
                    context,
                    video,
                    InteractionType.WATCHED,
                    percentWatched = 1.0f
                )
                
                val durationMs = if (video.duration > 0) video.duration * 1000L else 1000L
                val thumbnailUrl = video.thumbnailUrl.takeIf { it.isNotEmpty() }
                    ?: "https://i.ytimg.com/vi/${video.id}/hq720.jpg"
                id.nusatube.nativeapp.data.local.ViewHistory.getInstance(context).savePlaybackPosition(
                    videoId = video.id,
                    position = durationMs,
                    duration = durationMs,
                    title = video.title,
                    thumbnailUrl = thumbnailUrl,
                    channelName = video.channelName,
                    channelId = video.channelId,
                    isMusic = false
                )

                _watchedVideoIds.update { it + video.id }
                FeedInvalidationBus.emit(FeedInvalidationBus.Event.MarkedWatched(video.id))
                Toast.makeText(
                    context,
                    context.getString(id.nusatube.nativeapp.R.string.mark_as_watched_toast),
                    Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Mark a video as "I like this" - signals a positive LIKED interaction to NusaTubeNeuroEngine,
     * boosting the video's topics and channel. Helps users seed the algorithm with content
     * they enjoy without watching the full video in NusaTube.
     */
    fun markAsInteresting(video: Video) {
        viewModelScope.launch {
            try {
                NusaTubeNeuroEngine.onVideoInteraction(
                    context,
                    video,
                    InteractionType.LIKED,
                    percentWatched = 0f
                )
                Toast.makeText(
                    context,
                    context.getString(id.nusatube.nativeapp.R.string.i_like_this_toast),
                    Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Insert [video] immediately after the current position (Play Next).
     */
    fun playVideoNext(video: Video) {
        id.nusatube.nativeapp.player.EnhancedPlayerManager.getInstance().addVideoToQueueNext(video)
    }

    /**
     * Append [video] to the end of the current queue.
     */
    fun addVideoToQueue(video: Video) {
        id.nusatube.nativeapp.player.EnhancedPlayerManager.getInstance().addVideoToQueue(video)
    }

    fun downloadVideo(video: Video) {
        viewModelScope.launch {
            try {
                id.nusatube.nativeapp.ui.screens.player.util.VideoPlayerUtils.promptStoragePermissionIfNeeded(context)

                // Read the user's preferred download quality (with AUTO = best available)
                val targetQuality = playerPreferences.defaultDownloadQuality.first()
                val targetHeight = targetQuality.height 

                Toast.makeText(context, "Mengambil tautan unduhan…", Toast.LENGTH_SHORT).show()
                val streamInfo = withContext(Dispatchers.IO) {
                    repository.getVideoStreamInfo(video.id)
                }

                if (streamInfo != null) {
                    // ── Video-stream selection ────────────────────────────────────────────
                    val combinedStreams = streamInfo.videoStreams
                        ?.filterIsInstance<org.schabi.newpipe.extractor.stream.VideoStream>()
                        ?: emptyList()
                    val videoOnlyStreams = streamInfo.videoOnlyStreams
                        ?.filterIsInstance<org.schabi.newpipe.extractor.stream.VideoStream>()
                        ?: emptyList()

                    fun isMp4Video(s: org.schabi.newpipe.extractor.stream.VideoStream): Boolean {
                        val mime  = (s.format?.mimeType ?: "").lowercase()
                        val fname = (s.format?.name ?: "").lowercase()
                        return mime.contains("mp4") || fname.contains("mpeg") || fname.contains("mp4")
                    }

                    fun isVp9Video(s: org.schabi.newpipe.extractor.stream.VideoStream): Boolean {
                        val mime  = (s.format?.mimeType ?: "").lowercase()
                        val fname = (s.format?.name ?: "").lowercase()
                        return mime.contains("vp9") || mime.contains("vp09") ||
                               fname.contains("vp9") || fname.contains("webm")
                    }

                    fun List<org.schabi.newpipe.extractor.stream.VideoStream>.bestForTarget():
                            org.schabi.newpipe.extractor.stream.VideoStream? {
                        if (isEmpty()) return null
                        if (targetHeight == 0) return maxByOrNull { it.height } // AUTO
                        return filter { it.height <= targetHeight }.maxByOrNull { it.height }
                            ?: minByOrNull { it.height } // fallback: lowest if nothing fits
                    }

                    val bestMp4VideoOnly  = videoOnlyStreams.filter { isMp4Video(it) }.bestForTarget()
                    val bestVp9VideoOnly  = videoOnlyStreams.filter { isVp9Video(it) }.bestForTarget()
                    val bestAnyVideoOnly  = videoOnlyStreams.bestForTarget()
                    val bestCombined      = combinedStreams.bestForTarget()

                    // ── Audio selection (codec-aware) ────────────────────────────────────
                    val allAudio = streamInfo.audioStreams ?: emptyList()

                    fun isAacCompatible(a: org.schabi.newpipe.extractor.stream.AudioStream): Boolean {
                        val mime  = (a.format?.mimeType ?: "").lowercase()
                        val fname = (a.format?.name ?: "").lowercase()
                        if (fname.contains("opus") || fname.contains("vorbis") ||
                            mime.contains("opus") || mime.contains("vorbis") ||
                            fname.contains("webm") || mime.contains("webm")) return false
                        return true
                    }

                    fun isOpusCompatible(a: org.schabi.newpipe.extractor.stream.AudioStream): Boolean {
                        val mime  = (a.format?.mimeType ?: "").lowercase()
                        val fname = (a.format?.name ?: "").lowercase()
                        return fname.contains("webm") || mime.contains("audio/webm") ||
                               fname.contains("opus") || mime.contains("opus")
                    }

                    val selectedStream: org.schabi.newpipe.extractor.stream.VideoStream?
                    val audioUrl: String?
                    val videoCodec: String?

                    when {
                        bestMp4VideoOnly != null &&
                                bestMp4VideoOnly.height > (bestCombined?.height ?: 0) -> {
                            selectedStream = bestMp4VideoOnly
                            val aacAudio = allAudio.filter { isAacCompatible(it) }.maxByOrNull { it.averageBitrate }
                            audioUrl = aacAudio?.content ?: aacAudio?.url
                            videoCodec = null
                        }
                        bestCombined != null -> {
                            selectedStream = bestCombined
                            audioUrl = null
                            videoCodec = null
                        }
                        bestVp9VideoOnly != null &&
                                (bestVp9VideoOnly.height > (bestMp4VideoOnly?.height ?: 0)) -> {
                            selectedStream = bestVp9VideoOnly
                            val opusAudio = allAudio.filter { isOpusCompatible(it) }.maxByOrNull { it.averageBitrate }
                                ?: allAudio.maxByOrNull { it.averageBitrate }
                            audioUrl = opusAudio?.content ?: opusAudio?.url
                            videoCodec = "vp9"
                        }
                        bestMp4VideoOnly != null -> {
                            selectedStream = bestMp4VideoOnly
                            val aacAudio = allAudio.filter { isAacCompatible(it) }.maxByOrNull { it.averageBitrate }
                            audioUrl = aacAudio?.content ?: aacAudio?.url
                            videoCodec = null
                        }
                        else -> {
                            selectedStream = null
                            audioUrl = null
                            videoCodec = null
                        }
                    }

                    // NewPipe DASH VideoStreams store the real URL in .content; .url may be null.
                    val videoUrl = selectedStream?.content ?: selectedStream?.url
                    if (selectedStream != null && videoUrl != null) {
                        val fullVideo = Video(
                            id = video.id,
                            title = video.title.ifBlank { streamInfo.name ?: "Tidak diketahui" },
                            channelName = video.channelName.ifBlank { streamInfo.uploaderName ?: "" },
                            channelId = video.channelId.ifBlank { streamInfo.uploaderUrl?.substringAfterLast("/") ?: "local" },
                            thumbnailUrl = video.thumbnailUrl.ifBlank { streamInfo.thumbnails?.maxByOrNull { it.height }?.url ?: "" },
                            duration = if (video.duration > 0) video.duration else streamInfo.duration.toInt(),
                            viewCount = video.viewCount,
                            uploadDate = video.uploadDate,
                            description = video.description.ifBlank { streamInfo.description?.content ?: "" }
                        )

                        id.nusatube.nativeapp.data.video.downloader.NusaTubeDownloadService.startDownload(
                            context = context,
                            video = fullVideo,
                            url = videoUrl,
                            quality = "${selectedStream.height}p",
                            audioUrl = audioUrl,
                            videoCodec = videoCodec
                        )
                        Toast.makeText(context, "Unduhan dimulai: ${fullVideo.title}", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Aliran yang sesuai tidak tersedia", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(context, "Informasi video tidak dapat dimuat", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
