package id.nusatube.nativeapp.nativeflow

import android.content.Context
import android.net.Uri
import android.util.LruCache
import androidx.media3.common.util.UnstableApi
import id.nusatube.nativeapp.nativeflow.player.sabr.integration.SabrMediaSourceFactory
import id.nusatube.nativeapp.nativeflow.player.sabr.integration.SabrMediaSourceResult
import id.nusatube.nativeapp.nativeflow.player.stream.InnerTubeStreamBridge
import id.nusatube.nativeapp.nativeflow.player.stream.InnerTubeVideoStreamExtractor
import id.nusatube.nativeapp.nativeflow.utils.cipher.CipherDeobfuscator
import id.nusatube.nativeapp.nativeflow.utils.cipher.PipePipeNsigDecoder
import id.nusatube.nativeapp.nativeflow.utils.potoken.VisitorIdentityStore
import id.nusatube.nativeapp.nativeflow.utils.potoken.WebPoTokenSession
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.Description
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamType
import org.schabi.newpipe.extractor.stream.SubtitlesStream
import org.schabi.newpipe.extractor.stream.VideoStream

/** NusaTube model adapter; extraction and SABR framing remain the Flow implementation. */
@UnstableApi
object NativePlaybackBridge {
    private val sessions = LruCache<String, InnerTubeVideoStreamExtractor.VideoExtractionResult>(24)

    fun initialize(context: Context) {
        CipherDeobfuscator.initialize(context)
        PipePipeNsigDecoder.initialize(context)
    }

    suspend fun initializeIdentity(context: Context) {
        val store = VisitorIdentityStore(context)
        id.nusatube.nativeapp.nativeflow.innertube.YouTube.initialize(store)
        WebPoTokenSession.bindIdentityStore(store)
        WebPoTokenSession.prewarm()
    }

    suspend fun streamInfo(videoId: String, allowSabr: Boolean, forceSabr: Boolean = false): StreamInfo? {
        val result = InnerTubeVideoStreamExtractor.extract(videoId, forceSabr = forceSabr) ?: return null
        val useSabr = allowSabr && result.sabrInfo != null && !result.isLive
        val formats = result.playerResponse.streamingData?.adaptiveFormats.orEmpty()
        var videos = InnerTubeStreamBridge.convertVideoFormats(
            if (useSabr) formats.filter { !it.isAudio }.map {
                it.copy(url = Uri.Builder().scheme("sabr").authority(videoId)
                    .appendPath("video").appendPath(it.itag.toString()).build().toString())
            } else result.videoFormats,
        )
        var audios = InnerTubeStreamBridge.convertAudioFormats(
            if (useSabr) formats.filter { it.isAudio }.map {
                it.copy(url = Uri.Builder().scheme("sabr").authority(videoId)
                    .appendPath("audio").appendPath(it.itag.toString())
                    .appendQueryParameter("track", it.audioTrack?.id.orEmpty()).build().toString())
            } else result.audioFormats,
        )
        if (result.isLive && !result.liveHlsUrl.isNullOrBlank()) {
            if (videos.isEmpty()) videos = listOf(VideoStream.Builder()
                .setId("live-video").setContent(result.liveHlsUrl, true)
                .setMediaFormat(MediaFormat.MPEG_4).setResolution("720p")
                .setIsVideoOnly(false).setDeliveryMethod(org.schabi.newpipe.extractor.stream.DeliveryMethod.HLS).build())
            if (audios.isEmpty()) audios = listOf(AudioStream.Builder()
                .setId("live-audio").setContent(result.liveHlsUrl, true)
                .setMediaFormat(MediaFormat.M4A).setAverageBitrate(128)
                .setDeliveryMethod(org.schabi.newpipe.extractor.stream.DeliveryMethod.HLS).build())
        }
        if (!result.isLive && (videos.isEmpty() || audios.isEmpty())) return null
        if (result.isLive && result.liveHlsUrl.isNullOrBlank() && result.liveDashUrl.isNullOrBlank()) return null
        sessions.put(videoId, result)
        val details = result.playerResponse.videoDetails ?: return null
        val url = "https://www.youtube.com/watch?v=$videoId"
        return StreamInfo(0, url, url,
            if (result.isLive) StreamType.LIVE_STREAM else StreamType.VIDEO_STREAM,
            videoId, details.title.orEmpty(), 0).apply {
            setDuration(details.lengthSeconds.toLongOrNull() ?: 0L)
            setUploaderName(details.author.orEmpty())
            setUploaderUrl("https://www.youtube.com/channel/${details.channelId}")
            setViewCount(details.viewCount?.toLongOrNull() ?: 0L)
            setDescription(Description(details.shortDescription.orEmpty(), Description.PLAIN_TEXT))
            setThumbnails(details.thumbnail?.thumbnails.orEmpty().map {
                Image(it.url, it.height ?: -1, it.width ?: -1, Image.ResolutionLevel.UNKNOWN)
            })
            setVideoOnlyStreams(videos)
            setVideoStreams(emptyList())
            setAudioStreams(audios)
            setHlsUrl(result.liveHlsUrl.orEmpty())
            setDashMpdUrl(result.liveDashUrl.orEmpty())
            setSubtitles(result.playerResponse.captions?.playerCaptionsTracklistRenderer
                ?.captionTracks.orEmpty().mapNotNull { caption ->
                    val base = caption.baseUrl ?: return@mapNotNull null
                    val language = caption.languageCode ?: return@mapNotNull null
                    runCatching {
                        SubtitlesStream.Builder().setId(language)
                            .setContent(Uri.parse(base).buildUpon().appendQueryParameter("fmt", "vtt").build().toString(), true)
                            .setMediaFormat(MediaFormat.VTT).setLanguageCode(language)
                            .setAutoGenerated(caption.kind == "asr").build()
                    }.getOrNull()
                })
        }
    }

    suspend fun externalPlaybackUrl(url: String): String? {
        if (!isSabr(url)) return url
        val videoId = Uri.parse(url).host ?: return null
        val response = InnerTubeVideoStreamExtractor.extract(videoId)?.playerResponse ?: return null
        val data = response.streamingData ?: return null
        return data.hlsManifestUrl?.takeIf { it.isNotBlank() }
            ?: data.formats.orEmpty().firstOrNull { !it.url.isNullOrBlank() && it.audioChannels != null }?.url
    }

    fun hasSession(videoId: String): Boolean = sessions.get(videoId) != null

    fun isSabr(url: String?): Boolean = url?.startsWith("sabr://") == true

    fun mediaSource(video: VideoStream?, audio: AudioStream?, positionMs: Long, audioOnly: Boolean = false): SabrMediaSourceResult? =
        mediaSourceUrls(video?.content, audio?.content, positionMs, audioOnly)

    fun mediaSourceUrls(videoUrl: String?, audioUrl: String?, positionMs: Long = 0L, audioOnly: Boolean = false): SabrMediaSourceResult? {
        val url = sequenceOf(videoUrl, audioUrl).firstOrNull { isSabr(it) } ?: return null
        val videoItag = videoUrl?.let { Uri.parse(it).lastPathSegment }
        val audioItag = audioUrl?.let { Uri.parse(it).lastPathSegment }
        val audioTrack = audioUrl?.let { Uri.parse(it).getQueryParameter("track") }.orEmpty()
        val id = Uri.parse(url).host ?: return null
        val result = sessions.get(id) ?: return null
        val base = result.sabrInfo ?: return null
        val formats = result.playerResponse.streamingData?.adaptiveFormats.orEmpty()
        val info = NativeSabrSelection.select(base, formats, videoItag, audioItag, audioTrack)
        return SabrMediaSourceFactory.create(info, id, info.durationMs, positionMs, audioOnly = audioOnly)
    }
}
