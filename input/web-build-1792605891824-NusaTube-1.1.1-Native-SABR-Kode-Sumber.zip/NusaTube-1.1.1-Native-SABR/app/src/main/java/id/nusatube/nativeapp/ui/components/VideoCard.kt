@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package id.nusatube.nativeapp.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.util.Log
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.res.stringResource
import id.nusatube.nativeapp.R
import coil.compose.AsyncImage
import id.nusatube.nativeapp.data.local.PlayerPreferences
import id.nusatube.nativeapp.data.local.VideoHistoryEntry
import id.nusatube.nativeapp.data.local.ViewHistory
import id.nusatube.nativeapp.data.model.DeArrowResult
import id.nusatube.nativeapp.data.model.Video
import id.nusatube.nativeapp.data.repository.DeArrowRepository
import id.nusatube.nativeapp.ui.theme.extendedColors
import id.nusatube.nativeapp.utils.formatDuration
import id.nusatube.nativeapp.utils.formatPremiereDate
import id.nusatube.nativeapp.utils.formatViewCount
import kotlinx.coroutines.flow.collectLatest

private const val AVATAR_TAG = "ChannelAvatarImage"

@Composable
fun VideoCard(
    video: Video,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onChannelClick: ((String) -> Unit)? = null
) {
    var showQuickActions by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val watchProgress by produceState<Float?>(initialValue = null, video.id) {
        ViewHistory.getInstance(context).getVideoHistory(video.id).collectLatest { entry ->
            value = if (entry != null && entry.duration > 0 && entry.progressPercentage in 3f..90f) {
                entry.progressPercentage / 100f
            } else null
        }
    }

    val playerPrefs = remember { PlayerPreferences(context) }
    val deArrowEnabled by playerPrefs.deArrowEnabled.collectAsState(initial = false)
    val deArrowResult by produceState<DeArrowResult?>(
        initialValue = null, key1 = video.id, key2 = deArrowEnabled
    ) {
        value = if (deArrowEnabled) DeArrowRepository.getDeArrowResult(video.id) else null
    }
    val displayTitle = deArrowResult?.title ?: video.title
    val displayThumbnailUrl = deArrowResult?.thumbnailUrl ?: video.thumbnailUrl
    val interactionSource = remember { MutableInteractionSource() }
    Column(
        modifier = modifier
            .width(180.dp)
            .pressScale(interactionSource)
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onLongClick = { showQuickActions = true },
                onClick = onClick
            )
            .padding(4.dp)
    ) {
        // THUMBNAIL BOX
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .thumbnailGradientOverlay()
        ) {
            AsyncImage(
                model = displayThumbnailUrl,
                contentDescription = displayTitle,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            if (video.isUpcoming) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp),
                    color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.2f))
                ) {
                    Text(
                        text = stringResource(R.string.status_upcoming),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            } else if (video.isLive || video.duration > 0) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp),
                    color = if (video.isLive) Color(0xFFCC0000).copy(alpha = 0.9f) else Color.Black.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.2f))
                ) {
                    Text(
                        text = if (video.isLive) stringResource(R.string.status_live) else formatDuration(video.duration),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Watch progress bar
            watchProgress?.let { progress ->
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .height(3.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color.Black.copy(alpha = 0.4f)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // INFO ROW
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Channel Avatar
            ChannelAvatarImage(
                url = video.channelThumbnailUrl,
                contentDescription = video.channelName,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = displayTitle,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold, // Stronger weight for readability
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 18.sp
                )
                
                Spacer(modifier = Modifier.height(2.dp))
                
                // Metadata Row
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val premiereDate = formatPremiereDate(video.uploadDate)
                    Text(
                        text = if (video.isUpcoming)
                            premiereDate?.let { stringResource(R.string.premiere_date_prefix, it) } ?: stringResource(R.string.premiere_soon)
                        else if (video.viewCount >= 0L)
                            stringResource(R.string.video_metadata_short_template, video.channelName, stringResource(R.string.views_template, formatViewCount(video.viewCount)))
                        else
                            "${video.channelName} · ${video.uploadDate}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (video.isUpcoming) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            IconButton(
                onClick = { showQuickActions = true },
                modifier = Modifier
                    .size(24.dp)
                    .offset(x = 4.dp, y = (-4).dp) // Adjust for better alignment
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Opsi",
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
    
    if (showQuickActions) {
         VideoQuickActionsBottomSheet(
            video = video,
            onChannelClick = onChannelClick,
            onDismiss = { showQuickActions = false }
        )
    }
}

@Composable
fun VideoCardHorizontal(
    video: Video,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val playerPrefs = remember { PlayerPreferences(context) }
    val deArrowEnabled by playerPrefs.deArrowEnabled.collectAsState(initial = false)
    val deArrowResult by produceState<DeArrowResult?>(
        initialValue = null, key1 = video.id, key2 = deArrowEnabled
    ) {
        value = if (deArrowEnabled) DeArrowRepository.getDeArrowResult(video.id) else null
    }
    val displayTitle = deArrowResult?.title ?: video.title
    val displayThumbnailUrl = deArrowResult?.thumbnailUrl ?: video.thumbnailUrl
    val watchProgress by produceState<Float?>(initialValue = null, video.id) {
        ViewHistory.getInstance(context).getVideoHistory(video.id).collectLatest { entry ->
            value = if (entry != null && entry.duration > 0 && entry.progressPercentage in 3f..90f) {
                entry.progressPercentage / 100f
            } else null
        }
    }

    var showQuickActions by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .pressScale(interactionSource)
            .combinedClickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onLongClick = { showQuickActions = true },
                onClick = onClick
            )
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .width(140.dp)
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(14.dp)) // Sleek corners
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            AsyncImage(
                model = displayThumbnailUrl,
                contentDescription = displayTitle,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            if (video.isUpcoming) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp),
                    color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = stringResource(R.string.status_upcoming),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            } else if (video.isLive || video.duration > 0) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp),
                    color = if (video.isLive) Color(0xFFCC0000).copy(alpha = 0.9f) else Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (video.isLive) stringResource(R.string.status_live) else formatDuration(video.duration),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }

            // Watch progress bar
            watchProgress?.let { progress ->
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .height(3.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color.Black.copy(alpha = 0.4f)
                )
            }
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = displayTitle,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Column {
                Text(
                    text = video.channelName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.extendedColors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                val premiereDate = formatPremiereDate(video.uploadDate)
                Text(
                    text = if (video.isUpcoming)
                               premiereDate?.let { stringResource(R.string.premiere_date_prefix, it) } ?: stringResource(R.string.premiere_soon)
                           else if (video.viewCount >= 0L)
                               stringResource(R.string.video_metadata_short_template, stringResource(R.string.views_template, formatViewCount(video.viewCount)), video.uploadDate)
                           else
                               "${video.channelName} · ${video.uploadDate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (video.isUpcoming) MaterialTheme.colorScheme.primary
                            else MaterialTheme.extendedColors.textSecondary
                )
            }
        }
    }

    if (showQuickActions) {
        VideoQuickActionsBottomSheet(
            video = video,
            onChannelClick = null,
            onDismiss = { showQuickActions = false }
        )
    }
}

@Composable
fun VideoCardFullWidth(
    video: Video,
    modifier: Modifier = Modifier,
    useInternalPadding: Boolean = true,
    onClick: () -> Unit,
    onChannelClick: ((String) -> Unit)? = null,
    onMoreClick: () -> Unit = {}
) {
    var showQuickActions by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val watchProgress by produceState<Float?>(initialValue = null, video.id) {
        ViewHistory.getInstance(context).getVideoHistory(video.id).collectLatest { entry ->
            value = if (entry != null && entry.duration > 0 && entry.progressPercentage in 3f..90f) {
                entry.progressPercentage / 100f
            } else null
        }
    }

    // DeArrow: replace clickbait titles and thumbnails if enabled
    val playerPrefsFullWidth = remember { PlayerPreferences(context) }
    val deArrowEnabledFullWidth by playerPrefsFullWidth.deArrowEnabled.collectAsState(initial = false)
    val deArrowResultFullWidth by produceState<DeArrowResult?>(
        initialValue = null, key1 = video.id, key2 = deArrowEnabledFullWidth
    ) {
        value = if (deArrowEnabledFullWidth) DeArrowRepository.getDeArrowResult(video.id) else null
    }
    val displayTitle = deArrowResultFullWidth?.title ?: video.title
    val displayThumbnailUrl = deArrowResultFullWidth?.thumbnailUrl ?: video.thumbnailUrl

    val interactionSource = remember { MutableInteractionSource() }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .pressScale(interactionSource)
            .combinedClickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onLongClick = { showQuickActions = true },
                onClick = onClick
            )
            .then(if (useInternalPadding) Modifier.padding(horizontal = 12.dp) else Modifier)
    ) {
        // Thumbnail with duration
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .thumbnailGradientOverlay()
        ) {
            SafeAsyncImage(
                model = displayThumbnailUrl,
                contentDescription = displayTitle,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            if (video.isUpcoming) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp),
                    color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(5.dp),
                    border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.2f))
                ) {
                    Text(
                        text = stringResource(R.string.status_upcoming),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            } else if (video.isLive || video.duration > 0) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp),
                    color = if (video.isLive) Color(0xFFCC0000).copy(alpha = 0.9f) else Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(5.dp),
                    border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.2f))
                ) {
                    Text(
                        text = if (video.isLive) stringResource(R.string.status_live) else formatDuration(video.duration),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Watch progress bar
            watchProgress?.let { progress ->
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .height(3.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color.Black.copy(alpha = 0.4f)
                )
            }
        }

        // Video info section
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Channel avatar
            ChannelAvatarImage(
                url = video.channelThumbnailUrl,
                contentDescription = video.channelName,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .then(
                        if (onChannelClick != null)
                            Modifier.clickable { onChannelClick(video.channelId) }
                        else Modifier
                    )
            )

            // Video details
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = displayTitle,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                val premiereDate = formatPremiereDate(video.uploadDate)
                Text(
                    text = if (video.isUpcoming)
                               premiereDate?.let { stringResource(R.string.premiere_date_prefix, it) } ?: stringResource(R.string.premiere_soon)
                           else if (video.viewCount >= 0L)
                               stringResource(R.string.video_metadata_template, video.channelName, stringResource(R.string.views_template, formatViewCount(video.viewCount)), video.uploadDate)
                           else
                               "${video.channelName} · ${video.uploadDate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (video.isUpcoming) MaterialTheme.colorScheme.primary
                            else MaterialTheme.extendedColors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = if (onChannelClick != null)
                        Modifier.clickable { onChannelClick(video.channelId) }
                    else Modifier
                )
            }

            // More options button
            IconButton(
                onClick = { showQuickActions = true },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Opsi lainnya",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
        }
    }
    
    // Quick actions bottom sheet
    if (showQuickActions) {
        VideoQuickActionsBottomSheet(
            video = video,
            onChannelClick = onChannelClick,
            onDismiss = { showQuickActions = false }
        )
    }
}

/**
 * A horizontal Video Card optimized for side panes (tablets/foldables) or lists.
 * Image on Left, Info on Right.
 */
@Composable
fun CompactVideoCard(
    video: Video,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onMoreClick: () -> Unit = {},
    onChannelClick: ((String) -> Unit)? = null
) {
    var showQuickActions by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val watchProgress by produceState<Float?>(initialValue = null, video.id) {
        ViewHistory.getInstance(context).getVideoHistory(video.id).collectLatest { entry ->
            value = if (entry != null && entry.duration > 0 && entry.progressPercentage in 3f..90f) {
                entry.progressPercentage / 100f
            } else null
        }
    }

    // DeArrow: replace clickbait titles and thumbnails if enabled
    val playerPrefsCompact = remember { PlayerPreferences(context) }
    val deArrowEnabledCompact by playerPrefsCompact.deArrowEnabled.collectAsState(initial = false)
    val deArrowResultCompact by produceState<DeArrowResult?>(
        initialValue = null, key1 = video.id, key2 = deArrowEnabledCompact
    ) {
        value = if (deArrowEnabledCompact) DeArrowRepository.getDeArrowResult(video.id) else null
    }
    val displayTitle = deArrowResultCompact?.title ?: video.title
    val displayThumbnailUrl = deArrowResultCompact?.thumbnailUrl ?: video.thumbnailUrl

    val interactionSource = remember { MutableInteractionSource() }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .pressScale(interactionSource)
            .combinedClickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onLongClick = { showQuickActions = true },
                onClick = onClick
            )
            .padding(vertical = 8.dp, horizontal = 12.dp)
    ) {
        // Thumbnail (Left side)
        Box(
            modifier = Modifier
                .width(168.dp)
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            SafeAsyncImage(
                model = displayThumbnailUrl,
                contentDescription = displayTitle,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            if (video.viewCount < 0L) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp),
                    color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = stringResource(R.string.status_upcoming),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else if (video.isLive || video.duration > 0) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp),
                    color = if (video.isLive) Color(0xFFCC0000).copy(alpha = 0.9f) else Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = if (video.isLive) stringResource(R.string.status_live) else formatDuration(video.duration),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Watch progress bar
            watchProgress?.let { progress ->
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .height(3.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color.Black.copy(alpha = 0.4f)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Info (Right side)
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = displayTitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = video.channelName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.extendedColors.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            
            val premiereDate = formatPremiereDate(video.uploadDate)
            Text(
                text = if (video.viewCount < 0L)
                           premiereDate?.let { stringResource(R.string.premiere_date_prefix, it) } ?: stringResource(R.string.premiere_soon)
                       else stringResource(R.string.video_metadata_short_template, stringResource(R.string.views_template, formatViewCount(video.viewCount)), video.uploadDate),
                style = MaterialTheme.typography.bodySmall,
                color = if (video.viewCount < 0L) MaterialTheme.colorScheme.primary
                        else MaterialTheme.extendedColors.textSecondary.copy(alpha = 0.8f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 11.sp
            )
        }

        // More options button
        IconButton(
            onClick = { showQuickActions = true },
            modifier = Modifier
                .size(24.dp)
                .align(Alignment.Top)
        ) {
            Icon(
                imageVector = Icons.Default.MoreVert,
                contentDescription = "Opsi lainnya",
                tint = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.size(16.dp)
            )
        }
    }
    
    if (showQuickActions) {
         VideoQuickActionsBottomSheet(
            video = video,
            onChannelClick = onChannelClick,
            onDismiss = { showQuickActions = false }
        )
    }
}

@Composable
fun ContinueWatchingShelf(
    entries: List<VideoHistoryEntry>,
    onVideoClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (entries.isEmpty()) return
    val context = LocalContext.current
    Column(modifier = modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.PlayCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = context.getString(R.string.continue_watching_title),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(entries, key = { it.videoId }) { entry ->
                ContinueWatchingCard(
                    entry = entry,
                    onClick = { onVideoClick(entry.videoId) }
                )
            }
        }
    }
}

@Composable
private fun ContinueWatchingCard(
    entry: VideoHistoryEntry,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    Column(
        modifier = Modifier
            .width(200.dp)
            .pressScale(interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onClick = onClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .thumbnailGradientOverlay()
        ) {
            SafeAsyncImage(
                model = entry.thumbnailUrl,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Remaining time badge
            if (entry.duration > 0) {
                val remainingMs = (entry.duration - entry.position).coerceAtLeast(0L)
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = formatContinueWatchingTime(remainingMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            // Progress bar
            LinearProgressIndicator(
                progress = { (entry.progressPercentage / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .height(3.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = Color.Black.copy(alpha = 0.4f)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = entry.title,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            lineHeight = 16.sp
        )
        if (entry.channelName.isNotEmpty()) {
            Text(
                text = entry.channelName,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private fun formatContinueWatchingTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%d:%02d", minutes, seconds)
    }
}


@Composable
fun ShortsShelf(
    shorts: List<Video>,
    onShortClick: (Video) -> Unit
) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = ImageVector.vectorResource(id = R.drawable.ic_shorts),
                contentDescription = "Shorts",
                tint = Color.Red,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = context.getString(R.string.shorts),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(shorts) { short ->
                ShortsCard(video = short, onClick = { onShortClick(short) })
            }
        }
    }
}

@Composable
fun ShortsCard(
    video: Video,
    onClick: () -> Unit
) {
    var showQuickActions by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    Column(
        modifier = Modifier
            .width(160.dp)
            .pressScale(interactionSource)
            .combinedClickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onLongClick = { showQuickActions = true },
                onClick = onClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(9f / 16f)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .thumbnailGradientOverlay()
        ) {
            SafeAsyncImage(
                model = video.thumbnailUrl,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = video.title,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text = stringResource(R.string.views_template, formatViewCount(video.viewCount)),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.extendedColors.textSecondary
        )
    }

    if (showQuickActions) {
        VideoQuickActionsBottomSheet(
            video = video,
            onChannelClick = null,
            onDismiss = { showQuickActions = false }
        )
    }
}

@Composable
private fun SafeAsyncImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Fit
) {
    if (model is ImageVector) {
        Image(
            imageVector = model,
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(MaterialTheme.colorScheme.onSurfaceVariant)
        )
    } else {
        val isValidModel = when (model) {
            is String -> model.isNotEmpty()
            is Int -> true // Resource ID
            else -> false
        }

        if (isValidModel) {
            var hasError by remember(model) { mutableStateOf(false) }
            if (hasError) {
                Box(modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant))
            } else {
                AsyncImage(
                    model = model,
                    contentDescription = contentDescription,
                    modifier = modifier,
                    contentScale = contentScale,
                    onError = { hasError = true }
                )
            }
        } else {
            // Fallback placeholder
            Box(modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant))
        }
    }
}

/**
 * Channel avatar that gracefully degrades on load failure:
 *  1. Tries the original URL (may be high-res, e.g. =s800)
 *  2. On failure, retries with =s88 (low-res) if a size parameter is present
 *  3. On second failure, or no size param, shows the AccountCircle icon
 */
@Composable
fun ChannelAvatarImage(
    url: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier
) {
    var currentModel by remember(url) {
        val initial = url?.takeIf { it.isNotEmpty() } ?: Icons.Default.AccountCircle
        if (initial is ImageVector) {
            Log.d(AVATAR_TAG, "null/empty url for '$contentDescription', using icon")
        } else {
            Log.d(AVATAR_TAG, "init url='$url' for '$contentDescription'")
        }
        mutableStateOf<Any>(initial)
    }
    var didRetry by remember(url) { mutableStateOf(false) }

    when (val model = currentModel) {
        is ImageVector -> Image(
            imageVector = model,
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = ContentScale.Crop,
            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(
                MaterialTheme.colorScheme.onSurfaceVariant
            )
        )
        else -> AsyncImage(
            model = model,
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = ContentScale.Crop,
            onError = { errorResult ->
                val errMsg = errorResult.result.throwable?.message ?: "kesalahan tidak diketahui"
                if (!didRetry) {
                    didRetry = true
                    val src = currentModel as? String ?: run {
                        Log.e(AVATAR_TAG, "Expected String model but got ${currentModel::class.simpleName}")
                        return@AsyncImage
                    }
                    val lowRes = src.replace(Regex("=s\\d+"), "=s88")
                    if (lowRes != src) {
                        Log.w(AVATAR_TAG, "Failed '$src' ($errMsg) → retrying with '$lowRes'")
                        currentModel = lowRes
                    } else {
                        Log.e(AVATAR_TAG, "Failed '$src' ($errMsg), no size param to replace → icon")
                        currentModel = Icons.Default.AccountCircle
                    }
                } else {
                    Log.e(AVATAR_TAG, "Retry also failed for '$model' ($errMsg) → icon")
                    currentModel = Icons.Default.AccountCircle
                }
            }
        )
    }
}
