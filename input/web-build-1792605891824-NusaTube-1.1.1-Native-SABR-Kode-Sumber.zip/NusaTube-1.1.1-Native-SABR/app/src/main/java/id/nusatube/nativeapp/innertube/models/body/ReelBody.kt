package id.nusatube.nativeapp.innertube.models.body

import id.nusatube.nativeapp.innertube.models.Context
import kotlinx.serialization.Serializable

@Serializable
data class ReelBody(
    val context: Context,
    val params: String? = null,
    val sequenceParams: String? = "CA8%3D", // Default param often used for initial reels fetch
)
