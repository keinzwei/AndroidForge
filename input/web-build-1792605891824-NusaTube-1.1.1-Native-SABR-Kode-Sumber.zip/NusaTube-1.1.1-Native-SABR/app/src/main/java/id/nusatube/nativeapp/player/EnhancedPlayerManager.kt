package id.nusatube.nativeapp.player

import android.content.Context
import android.util.Log
import android.view.SurfaceHolder
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import id.nusatube.nativeapp.data.local.PlayerPreferences
import id.nusatube.nativeapp.data.local.SponsorBlockAction

// Modular components
import id.nusatube.nativeapp.player.audio.AudioFeaturesManager
import id.nusatube.nativeapp.player.cache.PlayerCacheManager
import id.nusatube.nativeapp.player.config.PlayerConfig
import id.nusatube.nativeapp.data.model.Video
import id.nusatube.nativeapp.player.error.PlayerErrorHandler
import id.nusatube.nativeapp.player.factory.PlayerFactory
import id.nusatube.nativeapp.player.media.MediaLoader
import id.nusatube.nativeapp.player.quality.QualityManager
import id.nusatube.nativeapp.player.service.BackgroundServiceManager
import id.nusatube.nativeapp.player.sponsorblock.SponsorBlockHandler
import id.nusatube.nativeapp.player.state.EnhancedPlayerState
import id.nusatube.nativeapp.player.stream.StreamProcessor
import id.nusatube.nativeapp.player.surface.SurfaceManager
import id.nusatube.nativeapp.player.tracker.PlaybackTracker

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import id.nusatube.nativeapp.data.model.SponsorBlockSegment
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.SubtitlesStream
import org.schabi.newpipe.extractor.stream.VideoStream

@UnstableApi
class EnhancedPlayerManager private constructor() {
    companion object {
        private const val TAG = PlayerConfig.TAG
        
        @Volatile
        private var instance: EnhancedPlayerManager? = null
        
        fun getInstance(): EnhancedPlayerManager {
            return instance ?: synchronized(this) {
                instance ?: EnhancedPlayerManager().also { instance = it }
            }
        }
    }
    
    // Core player components
    private var player: ExoPlayer? = null
    private var trackSelector: DefaultTrackSelector? = null
    private var bandwidthMeter: DefaultBandwidthMeter? = null
    
    // State management
    private val _playerState = MutableStateFlow(EnhancedPlayerState())
    val playerState: StateFlow<EnhancedPlayerState> = _playerState.asStateFlow()
    
    // Stream data
    private var currentVideoId: String? = null
    private var availableVideoStreams: List<VideoStream> = emptyList()
    private var availableAudioStreams: List<AudioStream> = emptyList()
    private var availableSubtitles: List<SubtitlesStream> = emptyList()
    private var currentVideoStream: VideoStream? = null
    private var currentAudioStream: AudioStream? = null
    private var selectedSubtitleIndex: Int? = null
    
    // Duration and manifest info
    private var currentDurationSeconds: Long = -1
    private var currentDashManifestUrl: String? = null
    private var currentHlsUrl: String? = null
    
    private var isAudioOnlyMode = false

    // Queue management
    private var playbackQueue: List<id.nusatube.nativeapp.data.model.Video> = emptyList()
    private var currentQueueIndex: Int = -1
    private var queueTitle: String? = null
    
    // Application context
    private var appContext: Context? = null
    
    // Coroutine scope
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    /**
     * Set to true while PlaybackRefocusEffect is recovering from a screen-off/on cycle.
     * Prevents onPlaybackStateChanged(STATE_ENDED) from skipping to the next video or
     * seeking to 0 during the transient states that ExoPlayer goes through during recovery.
     */
    @Volatile private var isRecoveringFromBackground = false

    /** Call at the start of a screen-off recovery sequence (before prepare()). */
    fun beginBackgroundRecovery() {
        isRecoveringFromBackground = true
        if (_playerState.value.hasEnded) {
            _playerState.value = _playerState.value.copy(hasEnded = false)
        }
    }

    /** Call after the recovery sequence completes or is abandoned. */
    fun endBackgroundRecovery() {
        isRecoveringFromBackground = false
    }
    
    // Modular components
    private val playerFactory = PlayerFactory()
    private val backgroundServiceManager = BackgroundServiceManager()
    private var cacheManager: PlayerCacheManager? = null
    private var qualityManager: QualityManager? = null
    private var surfaceManager: SurfaceManager? = null
    private var sponsorBlockHandler: SponsorBlockHandler? = null
    private var playbackTracker: PlaybackTracker? = null
    private var errorHandler: PlayerErrorHandler? = null

    private val _streamExpiredEvent = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val streamExpiredEvent: SharedFlow<Unit> = _streamExpiredEvent.asSharedFlow()

    private var audioFeaturesManager: AudioFeaturesManager? = null
    private var mediaLoader: MediaLoader? = null
    
    // Public Queue State
    private val _queueVideos = MutableStateFlow<List<Video>>(emptyList())
    val queueVideos: StateFlow<List<Video>> = _queueVideos.asStateFlow()
    
    private val _currentQueueIndex = MutableStateFlow<Int>(-1)
    val currentQueueIndexState: StateFlow<Int> = _currentQueueIndex.asStateFlow()

    // Public surface ready state
    val isSurfaceReady: Boolean
        get() = surfaceManager?.isSurfaceReady ?: false

    // ===== Initialization =====
    
    fun initialize(context: Context) {
        appContext = context.applicationContext
        
        if (player == null) {
            initializeComponents(context)
            initializePlayer(context)
            setupPlayerListener()
            startPlaybackTracker()
            observePreferences(context)
            Log.d(TAG, "Player initialized")
        }
    }
    
    private fun initializeComponents(context: Context) {
        // Initialize cache manager
        cacheManager = PlayerCacheManager(context).also { it.initialize() }
        
        // Initialize surface manager
        surfaceManager = SurfaceManager(context)
        
        // Initialize sponsor block handler
        sponsorBlockHandler = SponsorBlockHandler(scope)
        
        // Initialize audio features manager
        audioFeaturesManager = AudioFeaturesManager(scope, _playerState)
        
        // Initialize bandwidth meter and track selector via factory
        bandwidthMeter = playerFactory.createBandwidthMeter(context)
        trackSelector = playerFactory.createTrackSelector(context)
        
        // Initialize media loader
        mediaLoader = MediaLoader(_playerState, cacheManager, surfaceManager)
        
        // Initialize quality manager
        qualityManager = QualityManager(
            bandwidthMeter = bandwidthMeter,
            trackSelector = trackSelector,
            stateFlow = _playerState,
            onQualitySwitch = { stream, position ->
                currentVideoStream = stream
                loadMediaInternal(stream, currentAudioStream, position)
            }
        )
        
        // Initialize error handler
        errorHandler = PlayerErrorHandler(
            stateFlow = _playerState,
            onReloadStream = { position, reason -> reloadCurrentStream(position, reason) },
            onQualityDowngrade = { attemptQualityDowngrade() },
            onPlaybackShutdown = { onPlaybackShutdown() },
            onStreamExpired = { scope.launch { _streamExpiredEvent.emit(Unit) } },
            getFailedStreamUrls = { qualityManager?.let { qm ->
                availableVideoStreams.filter { qm.hasStreamFailed(it.getContent()) }.map { it.getContent() }.toSet()
            } ?: emptySet() },
            markStreamFailed = { url -> qualityManager?.markStreamFailed(url) },
            incrementStreamErrors = { qualityManager?.let { it.streamErrorCount } },
            getStreamErrorCount = { qualityManager?.streamErrorCount ?: 0 },
            isAdaptiveQualityEnabled = { qualityManager?.isAdaptiveQualityEnabled ?: true },
            getManualQualityHeight = { qualityManager?.manualQualityHeight },
            getCurrentVideoStream = { currentVideoStream },
            getCurrentAudioStream = { currentAudioStream },
            getAvailableAudioStreams = { availableAudioStreams },
            setCurrentAudioStream = { audio -> currentAudioStream = audio },
            setRecoveryState = { errorHandler?.setRecovery() },
            reloadPlaybackManager = { reloadPlaybackManager() }
        )
        
        // Initialize playback tracker
        playbackTracker = PlaybackTracker(
            scope = scope,
            stateFlow = _playerState,
            onSponsorBlockCheck = { pos -> sponsorBlockHandler?.checkForSkip(pos) },
            onBufferingDetected = {
                qualityManager?.let { qm ->
                    qm.incrementBufferingCount()
                    if (qm.hasReachedBufferingThreshold()) {
                        qm.checkAdaptiveQualityDowngrade(forceCheck = true, player?.currentPosition ?: 0L)
                        qm.resetBufferingCount()
                    }
                }
            },
            onSmoothPlayback = { qualityManager?.resetBufferingCount() },
            onBandwidthCheckNeeded = {
                qualityManager?.let { qm ->
                    if (qm.shouldCheckBandwidth()) {
                        qm.updateBandwidthCheckTime()
                        qm.checkAdaptiveQualityUpgrade(player?.currentPosition ?: 0L)
                    }
                }
            }
        )
    }
    
    private fun initializePlayer(context: Context) {
        val loadControl = playerFactory.createLoadControl(context)
        val renderersFactory = playerFactory.createRenderersFactory(context)
        
        player = playerFactory.createPlayer(
            context = context,
            trackSelector = trackSelector!!,
            loadControl = loadControl,
            renderersFactory = renderersFactory,
            dataSourceFactory = cacheManager?.getDataSourceFactory()
        )
        
        audioFeaturesManager?.setPlayer(player!!)
        
        // Apply initial loop preference
        scope.launch {
            val prefs = PlayerPreferences(context)
            val loopEnabled = prefs.videoLoopEnabled.first()
            player?.repeatMode = if (loopEnabled) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        }
        
        surfaceManager?.reattachSurfaceIfValid(player)
    }

    fun setVolumeBoost(volume: Float) {
        audioFeaturesManager?.setVolumeBoost(player, volume)
    }
    
    private fun observePreferences(context: Context) {
        audioFeaturesManager?.observeSkipSilencePreference(context)
        audioFeaturesManager?.observeStableVolumePreference(context)
        
        val prefs = PlayerPreferences(context)
        scope.launch {
            prefs.sponsorBlockEnabled.collect { isEnabled ->
                sponsorBlockHandler?.setEnabled(isEnabled)
            }
        }

        scope.launch {
            prefs.videoLoopEnabled.collect { isEnabled ->
                player?.repeatMode = if (isEnabled) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            }
        }

        // Collect per-category SponsorBlock actions and update handler
        val sbCategories = listOf("sponsor", "intro", "outro", "selfpromo", "interaction", "music_offtopic")
        sbCategories.forEach { category ->
            scope.launch {
                prefs.sbActionForCategory(category).collect { action ->
                    val current = sponsorBlockHandler?.categoryActions?.toMutableMap() ?: mutableMapOf()
                    current[category] = action
                    sponsorBlockHandler?.categoryActions = current
                }
            }
        }
    }

    // ===== Player Listener =====
    
    private fun setupPlayerListener() {
        mediaLoader?.onSabrError = { _streamExpiredEvent.tryEmit(Unit) }
        player?.addListener(object : Player.Listener {
            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int
            ) {
                mediaLoader?.updateSabrPlayhead(newPosition.positionMs)
                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION && mediaLoader?.isSabrActive() == true) {
                    scope.launch { seekTo(newPosition.positionMs) }
                }
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.height > 0) {
                    _playerState.value = _playerState.value.copy(effectiveQuality = videoSize.height)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                _playerState.value = _playerState.value.copy(
                    isBuffering = playbackState == Player.STATE_BUFFERING,
                    playWhenReady = player?.playWhenReady ?: false,
                    hasEnded = playbackState == Player.STATE_ENDED && !isRecoveringFromBackground
                )
                
                if (playbackState == Player.STATE_ENDED && !isRecoveringFromBackground) {
                    if (_playerState.value.isLooping) {
                        seekTo(0)
                        player?.play()
                    } else if (hasNext()) {
                        playNext()
                    }
                }
                
                if (playbackState == Player.STATE_BUFFERING) {
                    logBandwidthInfo()
                }
            }
            
            override fun onRenderedFirstFrame() {
                Log.d(TAG, "First frame rendered - video renderer working")
                surfaceManager?.setSurfaceReady(true)
                val rendererAvailable = isVideoRendererAvailable()
                Log.d(TAG, "Video renderer confirmed available after first frame: $rendererAvailable")
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _playerState.value = _playerState.value.copy(isPlaying = isPlaying)
            }
            
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                _playerState.value = _playerState.value.copy(playWhenReady = playWhenReady)
            }

            override fun onPlayerError(error: PlaybackException) {
                errorHandler?.handleError(error, player)
            }
        })
    }
    
    fun updateSabrPlayhead(positionMs: Long) { mediaLoader?.updateSabrPlayhead(positionMs) }

    private fun startPlaybackTracker() {
        player?.let { playbackTracker?.start(it) }
    }

    // ===== Offline / Local File Playback =====

    /**
     * Play a local (downloaded) file directly, bypassing all stream requirements.
     * Muxed MP4 files are self-contained with both audio and video tracks.
     */
    fun playLocalFile(videoId: String, filePath: String) {
        Log.d(TAG, "playLocalFile: videoId=$videoId, path=$filePath")
        resetPlaybackStateForNewVideo(videoId)
        currentVideoId = videoId
        startPlaybackTracker()
        loadMediaInternal(
            videoStream = null,
            audioStream = null,
            localFilePath = filePath
        )
    }

    // ===== Stream Management =====
    
    suspend fun setStreams(
        videoId: String,
        videoStream: VideoStream?,
        audioStream: AudioStream,
        videoStreams: List<VideoStream>,
        audioStreams: List<AudioStream>,
        subtitles: List<SubtitlesStream>,
        durationSeconds: Long = -1,
        dashManifestUrl: String? = null,
        localFilePath: String? = null,
        hlsUrl: String? = null,
        startPosition: Long = 0L
    ) {
        Log.d(TAG, "setStreams(id=$videoId, videoHeight=${videoStream?.height})")
        resetPlaybackStateForNewVideo(videoId)
        
        // Reset and load SponsorBlock
        sponsorBlockHandler?.reset()
        sponsorBlockHandler?.loadSegments(videoId)
        
        this.currentDurationSeconds = durationSeconds
        this.currentDashManifestUrl = dashManifestUrl
        this.currentHlsUrl = hlsUrl
        currentVideoId = videoId
        
        // Process streams using StreamProcessor
        availableVideoStreams = StreamProcessor.processVideoStreams(videoStreams)
        availableAudioStreams = StreamProcessor.processAudioStreams(audioStreams)
        availableSubtitles = subtitles
        
        // Ensure playback tracker is running
        startPlaybackTracker()
        
        // Update quality manager with available streams
        qualityManager?.setAvailableStreams(availableVideoStreams)
        qualityManager?.isDashSource = !currentDashManifestUrl.isNullOrEmpty()
        
        // Quality selection: respect user preference
        if (videoStream != null) {
            currentVideoStream = videoStream
            qualityManager?.setCurrentStream(currentVideoStream)
            qualityManager?.setManualMode(videoStream.height)
        } else {
            val smartStream = qualityManager?.selectSmartInitialQuality()
            currentVideoStream = smartStream ?: availableVideoStreams.firstOrNull()
            qualityManager?.setCurrentStream(currentVideoStream)
        }
        currentAudioStream = audioStream
        
        val isAutoMode = (videoStream == null)
        
        // Update state with available options
        _playerState.value = _playerState.value.copy(
            currentVideoId = videoId,
            effectiveQuality = currentVideoStream?.height ?: 0,
            availableQualities = qualityManager?.buildQualityOptions() ?: emptyList(),
            availableAudioTracks = StreamProcessor.toAudioTrackOptions(availableAudioStreams),
            availableSubtitles = StreamProcessor.toSubtitleOptions(subtitles),
            currentQuality = if (isAutoMode) 0 else (currentVideoStream?.height ?: 0),
            currentAudioTrack = availableAudioStreams.indexOf(currentAudioStream).coerceAtLeast(0)
        )

        // Wait for surface to be ready
        val timeout = appContext?.let { ctx ->
            PlayerPreferences(ctx).surfaceReadyTimeoutMs.first()
        } ?: PlayerConfig.DEFAULT_SURFACE_TIMEOUT_MS
        
        surfaceManager?.awaitSurfaceReady(timeout)

        // Load media — pass startPosition as preservePosition so ExoPlayer seeks right after prepare()
        val resumePos = startPosition.takeIf { it > 0L }
        when {
            localFilePath != null -> loadMediaInternal(null, audioStream, localFilePath = localFilePath, preservePosition = resumePos)
            currentVideoStream != null -> loadMediaInternal(currentVideoStream, currentAudioStream, preservePosition = resumePos)
            else -> loadMediaInternal(null, currentAudioStream ?: audioStream, preservePosition = resumePos)
        }
    }

    private fun resetPlaybackStateForNewVideo(videoId: String) {
        mediaLoader?.releaseSabr()
        qualityManager?.resetForNewVideo()
        playbackTracker?.reset()
        currentVideoStream = null
        currentAudioStream = null
        currentDashManifestUrl = null
        currentHlsUrl = null
        selectedSubtitleIndex = null
        
        player?.let { it.stop(); it.clearMediaItems() }
        
        _playerState.value = _playerState.value.copy(
            currentVideoId = videoId, isBuffering = true, error = null,
            hasEnded = false, isPrepared = false, recoveryAttempted = false, currentQuality = 0,
            playWhenReady = player?.playWhenReady ?: true
        )
    }

    private fun loadMediaInternal(
        videoStream: VideoStream?,
        audioStream: AudioStream?,
        preservePosition: Long? = null,
        localFilePath: String? = null
    ) {
        if (localFilePath != null) {
            Log.d(TAG, "loadMediaInternal: Playing local file: $localFilePath")
            mediaLoader?.loadMedia(
                player = player,
                context = appContext,
                videoStream = videoStream,
                audioStream = audioStream ?: availableAudioStreams.firstOrNull(),
                availableVideoStreams = availableVideoStreams,
                currentVideoStream = currentVideoStream,
                dashManifestUrl = null,
                hlsUrl = null,
                durationSeconds = currentDurationSeconds,
                currentDurationSeconds = currentDurationSeconds,
                preservePosition = preservePosition,
                localFilePath = localFilePath
            )
            return
        }

        val audio = audioStream ?: availableAudioStreams.firstOrNull() ?: return
        mediaLoader?.loadMedia(
            player = player,
            context = appContext,
            videoStream = videoStream,
            audioStream = audio,
            availableVideoStreams = availableVideoStreams,
            currentVideoStream = currentVideoStream,
            dashManifestUrl = currentDashManifestUrl,
            hlsUrl = currentHlsUrl,
            durationSeconds = currentDurationSeconds,
            currentDurationSeconds = currentDurationSeconds,
            preservePosition = preservePosition,
            localFilePath = localFilePath
        )
    }

    // ===== Queue Management =====

    fun setQueue(videos: List<Video>, startIndex: Int, title: String? = null) {
        playbackQueue = videos
        currentQueueIndex = startIndex.coerceIn(0, videos.size - 1)
        queueTitle = title
        
        _queueVideos.value = videos
        _currentQueueIndex.value = currentQueueIndex
        
        updateQueueState()
        
        if (videos.isNotEmpty()) {
            val video = videos[currentQueueIndex]
            startPlaybackFromQueue(video)
        }
    }

    fun playNext(): Boolean {
        if (currentQueueIndex < playbackQueue.size - 1) {
            currentQueueIndex++
            _currentQueueIndex.value = currentQueueIndex
            startPlaybackFromQueue(playbackQueue[currentQueueIndex])
            updateQueueState()
            return true
        }
        return false
    }

    fun playPrevious(): Boolean {
        if (currentQueueIndex > 0) {
            currentQueueIndex--
            _currentQueueIndex.value = currentQueueIndex
            startPlaybackFromQueue(playbackQueue[currentQueueIndex])
            updateQueueState()
            return true
        }
        return false
    }

    fun hasNext(): Boolean = currentQueueIndex < playbackQueue.size - 1

    fun hasPrevious(): Boolean = currentQueueIndex > 0 || (player?.currentPosition ?: 0) > 3000

    /**
     * Returns true if there is an active queue with at least one video.
     */
    fun hasActiveQueue(): Boolean = playbackQueue.isNotEmpty()

    /**
     * Insert [video] immediately after the current position (Play Next).
     * If no queue is active but a video is currently playing, silently build a
     * [currentVideo, video] queue starting at index 0 — no playback interruption.
     * If nothing is playing at all, start the video immediately.
     */
    fun addVideoToQueueNext(video: Video) {
        if (playbackQueue.isEmpty()) {
            val current = GlobalPlayerState.currentVideo.value
            if (current != null) {
                playbackQueue = listOf(current, video)
                currentQueueIndex = 0
                _queueVideos.value = playbackQueue
                _currentQueueIndex.value = 0
                updateQueueState()
            } else {
                setQueue(listOf(video), 0)
            }
            return
        }
        val insertAt = currentQueueIndex + 1
        val mutableQueue = playbackQueue.toMutableList()
        mutableQueue.add(insertAt, video)
        playbackQueue = mutableQueue
        _queueVideos.value = mutableQueue
        updateQueueState()
    }

    /**
     * Append [video] to the end of the current queue.
     * If no queue is active but a video is currently playing, silently build a
     * [currentVideo, video] queue starting at index 0 — no playback interruption.
     * If nothing is playing at all, start the video immediately.
     */
    fun addVideoToQueue(video: Video) {
        if (playbackQueue.isEmpty()) {
            val current = GlobalPlayerState.currentVideo.value
            if (current != null) {
                playbackQueue = listOf(current, video)
                currentQueueIndex = 0
                _queueVideos.value = playbackQueue
                _currentQueueIndex.value = 0
                updateQueueState()
            } else {
                setQueue(listOf(video), 0)
            }
            return
        }
        val mutableQueue = playbackQueue.toMutableList()
        mutableQueue.add(video)
        playbackQueue = mutableQueue
        _queueVideos.value = mutableQueue
        updateQueueState()
    }
    
    fun playVideoAtIndex(index: Int) {
        if (index in playbackQueue.indices && index != currentQueueIndex) {
            currentQueueIndex = index
            _currentQueueIndex.value = currentQueueIndex
            startPlaybackFromQueue(playbackQueue[currentQueueIndex])
            updateQueueState()
        }
    }

    private fun startPlaybackFromQueue(video: Video) {
        // Reset player state for new video
        resetPlaybackStateForNewVideo(video.id)
        
        _playerState.value = _playerState.value.copy(
            currentVideoId = video.id,
            isPlaying = true,
            playWhenReady = true,
            isBuffering = true
        )
        
        GlobalPlayerState.setCurrentVideo(video)
    }

    private fun updateQueueState() {
        _playerState.value = _playerState.value.copy(
            hasNext = hasNext(),
            hasPrevious = hasPrevious(),
            queueTitle = queueTitle,
            queueSize = playbackQueue.size
        )
    }

    // ===== Playback Controls =====
    
    fun play() = player?.play()
    fun pause() = player?.pause()
    fun seekTo(position: Long) {
        if (mediaLoader?.isSabrActive() == true) {
            val playing = player?.playWhenReady ?: true
            player?.stop()
            player?.clearMediaItems()
            loadMediaInternal(currentVideoStream, currentAudioStream, position.coerceAtLeast(0L))
            player?.playWhenReady = playing
        } else {
            player?.seekTo(position)
        }
    }
    
    fun toggleLoop(enabled: Boolean) {
        _playerState.value = _playerState.value.copy(isLooping = enabled)
    }
    
    fun stop() {
        mediaLoader?.releaseSabr()
        playbackTracker?.stop()
        player?.stop()
        player?.clearMediaItems()
        qualityManager?.resetForNewVideo()
        _playerState.value = _playerState.value.copy(isPlaying = false, currentVideoId = null)
    }

    fun getPlayer(): ExoPlayer? = player
    fun getCurrentPosition(): Long = player?.currentPosition ?: 0L
    fun getDuration(): Long = player?.duration ?: 0L
    fun isPlaying(): Boolean = player?.isPlaying ?: false

    // ===== Quality & Audio Management =====
    
    fun switchQualityByHeight(height: Int) = qualityManager?.switchQualityByHeight(height, player?.currentPosition ?: 0L)
    fun switchQuality(height: Int) = switchQualityByHeight(height)
    
    fun switchAudioTrack(index: Int) {
        if (index in availableAudioStreams.indices) {
            currentAudioStream = availableAudioStreams[index]
            val position = player?.currentPosition ?: 0L
            val wasPlaying = player?.isPlaying ?: false
            loadMediaInternal(currentVideoStream, currentAudioStream, preservePosition = position)
            if (wasPlaying) player?.play()
            _playerState.value = _playerState.value.copy(currentAudioTrack = index)
        }
    }

    fun selectSubtitle(index: Int?) {
        if (selectedSubtitleIndex != index) {
            selectedSubtitleIndex = index
            Log.d(TAG, "Subtitle selected: $index")
        }
    }

    // ===== Audio Features =====
    
    fun setPlaybackSpeed(speed: Float) = audioFeaturesManager?.setPlaybackSpeed(player, speed)
    fun toggleSkipSilence(isEnabled: Boolean) = audioFeaturesManager?.toggleSkipSilence(isEnabled, appContext)

    fun toggleStableVolume(isEnabled: Boolean) = audioFeaturesManager?.toggleStableVolume(isEnabled, appContext)
    
    fun toggleSponsorBlock(isEnabled: Boolean) {
        sponsorBlockHandler?.setEnabled(isEnabled)
        appContext?.let { ctx ->
            scope.launch { PlayerPreferences(ctx).setSponsorBlockEnabled(isEnabled) }
        }
    }
    
    val sponsorSegments: StateFlow<List<SponsorBlockSegment>>
        get() = sponsorBlockHandler?.sponsorSegments ?: MutableStateFlow(emptyList())

    val skipEvent: SharedFlow<SponsorBlockSegment>
        get() = sponsorBlockHandler?.skipEvent ?: MutableSharedFlow()

    val sbMuteEvent: SharedFlow<Boolean>
        get() = sponsorBlockHandler?.muteEvent ?: MutableSharedFlow()

    val sbToastEvent: SharedFlow<SponsorBlockSegment>
        get() = sponsorBlockHandler?.toastEvent ?: MutableSharedFlow()

    val sbCategoryActions: Map<String, SponsorBlockAction>
        get() = sponsorBlockHandler?.categoryActions ?: emptyMap()

    // ===== Surface Management =====

    fun attachVideoSurface(holder: SurfaceHolder?, forceAttach: Boolean = false): Boolean? {
        val attached = surfaceManager?.attachVideoSurface(holder, player, forceAttach)
        if (attached == true) {
            val p = player
            if (p != null && currentVideoStream != null && currentAudioStream != null) {
                if (isAudioOnlyMode) {
                    Log.d(TAG, "attachVideoSurface: was in audio-only mode — restoring video stream")
                    isAudioOnlyMode = false
                    val pos = p.currentPosition
                    loadMediaInternal(currentVideoStream, currentAudioStream, preservePosition = pos)
                } else if (p.currentMediaItem == null) {
                    Log.d(TAG, "attachVideoSurface: no media item — loading media now")
                    loadMediaInternal(currentVideoStream, currentAudioStream)
                } else if (p.playbackState == Player.STATE_IDLE) {
                    Log.d(TAG, "attachVideoSurface: surface back and player IDLE — calling prepare()")
                    p.prepare()
                    if (p.playWhenReady) p.play()
                }
            }
        }
        return attached
    }
    fun detachVideoSurface(holder: SurfaceHolder? = null) = surfaceManager?.detachVideoSurface(holder, player, appContext)
    fun clearSurface() = surfaceManager?.clearSurface(player)
    suspend fun awaitSurfaceReady(timeoutMillis: Long = 1000) = surfaceManager?.awaitSurfaceReady(timeoutMillis) ?: false

    /**
     * Switch to audio-only mode by detaching the video surface.
     * This allows playback to continue without rendering video frames.
     */
    fun switchToAudioOnly() {
        if (isAudioOnlyMode) return
        Log.d(TAG, "Switching to audio-only mode")
        isAudioOnlyMode = true
        
        surfaceManager?.detachVideoSurface(null, player, appContext)
        // Set surface ready to false so it doesn't try to auto-reattach
        surfaceManager?.setSurfaceReady(false)
        
        // Reload as audio-only stream (bandwidth saving)
        val pos = player?.currentPosition ?: 0L
        loadMediaInternal(null, currentAudioStream, preservePosition = pos)
    }
    
    fun setSurfaceReady(ready: Boolean) {
        surfaceManager?.setSurfaceReady(ready)
        if (ready) {
            val p = player
            if (p != null && currentVideoStream != null && currentAudioStream != null) {
                when {
                    p.currentMediaItem == null -> {
                        Log.d(TAG, "setSurfaceReady: no media item yet, loading media")
                        loadMediaInternal(currentVideoStream, currentAudioStream)
                    }
                    p.playbackState == Player.STATE_IDLE -> {
                        Log.d(TAG, "setSurfaceReady: player idle, calling prepare() to recover")
                        p.prepare()
                        if (p.playWhenReady) p.play()
                    }
                }
            }
        }
    }
    
    fun retryLoadMediaIfSurfaceReady() {
        if (isSurfaceReady && currentVideoStream != null && currentAudioStream != null) {
            loadMediaInternal(currentVideoStream, currentAudioStream)
        }
    }

    // ===== Cache & Background Service =====
    
    fun getCacheSize(): Long = cacheManager?.getCacheSize() ?: 0L
    fun clearCache() = cacheManager?.clearCache()
    
    fun startBackgroundService(videoId: String, title: String, channel: String, thumbnail: String) =
        backgroundServiceManager.startService(appContext, videoId, title, channel, thumbnail)
    
    fun stopBackgroundService() = backgroundServiceManager.stopService(appContext)

    // ===== Bandwidth & Renderer Info =====
    
    fun getBandwidthEstimate(): Long = bandwidthMeter?.bitrateEstimate ?: 0L
    
    fun logBandwidthInfo() {
        val mbps = getBandwidthEstimate() / 1_000_000.0
        Log.d(TAG, "Bandwidth: ${"%.2f".format(mbps)} Mbps")
    }
    
    fun isVideoRendererAvailable(): Boolean {
        player?.let { p ->
            if (p.playbackState == Player.STATE_IDLE || p.playbackState == Player.STATE_BUFFERING) return true
            if (p.currentTracks.groups.any { it.type == C.TRACK_TYPE_VIDEO && it.isSelected }) return true
            trackSelector?.currentMappedTrackInfo?.let { info ->
                for (i in 0 until info.rendererCount) {
                    if (info.getTrackGroups(i).length > 0 && p.getRendererType(i) == C.TRACK_TYPE_VIDEO) return true
                }
            }
        }
        return false
    }

    // ===== Clear & Release =====

    fun clearCurrentVideo() {
        player?.stop()
        player?.clearMediaItems()
        qualityManager?.resetForNewVideo()
        currentVideoId = null
        currentVideoStream = null
        currentAudioStream = null
        _playerState.value = _playerState.value.copy(
            isPlaying = false, currentVideoId = null, currentQuality = 0,
            bufferedPercentage = 0f, isBuffering = false, isPrepared = false, hasEnded = false
        )
    }

    fun clearAll() {
        clearCurrentVideo()
        playbackQueue = emptyList()
        currentQueueIndex = -1
        _queueVideos.value = emptyList()
        _currentQueueIndex.value = -1
        queueTitle = null
        _playerState.value = _playerState.value.copy(
            hasNext = false, hasPrevious = false, queueTitle = null, queueSize = 0
        )
    }

    fun isQueueActive(): Boolean = playbackQueue.isNotEmpty()

    fun release() {
        mediaLoader?.releaseSabr()
        Log.d(TAG, "release() called")
        playbackTracker?.stop()
        audioFeaturesManager?.clearPlayer()
        surfaceManager?.release(player)
        player?.release()
        player = null
        trackSelector = null
        appContext = null
        cacheManager?.release()
        cacheManager = null
        _playerState.value = EnhancedPlayerState()
        Log.d(TAG, "Player released")
    }

    // ===== Error Recovery =====
    
    private fun reloadCurrentStream(preservePosition: Long?, reason: String) {
        val video = currentVideoStream ?: return
        val audio = currentAudioStream ?: availableAudioStreams.firstOrNull() ?: return
        val pos = preservePosition ?: player?.currentPosition ?: 0L
        Log.d(TAG, "Reloading ${video.height}p at ${pos}ms ($reason)")
        player?.stop()
        player?.clearMediaItems()
        loadMediaInternal(video, audio, pos)
    }
    
    private fun reloadPlaybackManager() {
        try {
            Thread.sleep(PlayerConfig.ERROR_RETRY_DELAY_MS)
            val pos = player?.currentPosition ?: 0L
            player?.stop()
            player?.clearMediaItems()

            if (qualityManager?.isAdaptiveQualityEnabled == false) {
                reloadCurrentStream(pos, "manual-quality-reload")
                return
            }

            currentVideoStream?.let { stream ->
                if (qualityManager?.hasStreamFailed(stream.getContent()) == true) {
                    val working = qualityManager?.getWorkingStreams()?.maxByOrNull { it.height }
                    if (working != null) {
                        currentVideoStream = working
                        qualityManager?.resetStreamErrors()
                    } else {
                        onPlaybackShutdown()
                        return
                    }
                }
            }

            currentVideoStream?.let { loadMediaInternal(it, currentAudioStream, pos) }
        } catch (e: Exception) {
            Log.e(TAG, "Error reloading", e)
            onPlaybackShutdown()
        }
    }
    
    private fun attemptQualityDowngrade() {
        val newStream = qualityManager?.attemptQualityDowngrade()
        if (newStream != null) {
            currentVideoStream = newStream
            loadMediaInternal(newStream, currentAudioStream)
        } else {
            _playerState.value = _playerState.value.copy(
                error = "Unable to play - all quality options failed", isPlaying = false, isBuffering = false
            )
            onPlaybackShutdown()
        }
    }
    
    private fun onPlaybackShutdown() = errorHandler?.handlePlaybackShutdown(player)

    /**
     * Called by [PlaybackRefocusEffect] when the player is stuck in an unrecoverable state
     * after a screen-off/on cycle (duration still 0 after all poll attempts).
     */
    fun handleRefocusStuck(videoId: String?) {
        val p = player ?: return
        errorHandler?.handleRefocusStuck(p, videoId)
    }
}

// Backward compatibility type aliases
typealias EnhancedPlayerState = id.nusatube.nativeapp.player.state.EnhancedPlayerState
typealias QualityOption = id.nusatube.nativeapp.player.state.QualityOption
typealias AudioTrackOption = id.nusatube.nativeapp.player.state.AudioTrackOption
typealias SubtitleOption = id.nusatube.nativeapp.player.state.SubtitleOption
