package id.nusatube.nativeapp.nativeflow

import id.nusatube.nativeapp.data.video.downloader.NusaTubeDownloadMission
import id.nusatube.nativeapp.data.video.downloader.MissionStatus
import id.nusatube.nativeapp.nativeflow.player.sabr.integration.SabrSegmentBuffer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.coroutineContext

/** Saves the same attested SABR session used by playback, then reuses NusaTube's muxer. */
object NativeSabrDownload {
    suspend fun download(mission: NusaTubeDownloadMission, audioOnly: Boolean): Boolean = coroutineScope {
        if (!NativePlaybackBridge.hasSession(mission.video.id)) {
            NativePlaybackBridge.streamInfo(mission.video.id, allowSabr = true, forceSabr = true)
        }
        val source = NativePlaybackBridge.mediaSourceUrls(
            if (audioOnly) null else mission.url,
            if (audioOnly) mission.url else mission.audioUrl,
        ) ?: return@coroutineScope false
        val stream = source.orchestrator
        val ended = AtomicBoolean(false)
        val failed = AtomicReference<String?>(null)
        stream.onEndOfTrack = { ended.set(true) }
        stream.onError = { _, message, recoverable ->
            if (!recoverable) {
                failed.set(message)
                stream.stop()
            }
        }
        stream.onSegmentEnd = { stream.updatePlayhead(it) }
        stream.setAudioOnly(audioOnly)
        stream.start()
        val monitor = launch {
            while (mission.status == MissionStatus.RUNNING && !ended.get() && failed.get() == null) delay(250)
            if (!ended.get()) stream.stop()
        }
        try {
            val audio = async(Dispatchers.IO) {
                copy(stream.audioBuffer,
                    if (audioOnly) mission.savePath else "${mission.savePath}.audio.tmp", mission, true)
            }
            val video = if (!audioOnly) async(Dispatchers.IO) {
                copy(stream.videoBuffer, "${mission.savePath}.video.tmp", mission, false)
            } else null
            audio.await()
            video?.await()
            ended.get() && failed.get() == null && mission.status == MissionStatus.RUNNING
        } finally {
            monitor.cancel()
            stream.release()
        }
    }

    private suspend fun copy(buffer: SabrSegmentBuffer, path: String, mission: NusaTubeDownloadMission, audio: Boolean) {
        val file = File(path)
        file.parentFile?.mkdirs()
        file.outputStream().buffered().use { output ->
            val bytes = ByteArray(64 * 1024)
            while (true) {
                coroutineContext.ensureActive()
                val count = runInterruptible(Dispatchers.IO) { buffer.read(bytes, 0, bytes.size) }
                if (count < 0) break
                output.write(bytes, 0, count)
                mission.updateProgress(count.toLong(), audio)
            }
        }
    }
}
