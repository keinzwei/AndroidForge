package id.nusatube.nativeapp.innertube.models.body

import id.nusatube.nativeapp.innertube.models.Context
import kotlinx.serialization.Serializable

@Serializable
data class GetQueueBody(
    val context: Context,
    val videoIds: List<String>?,
    val playlistId: String?,
)
