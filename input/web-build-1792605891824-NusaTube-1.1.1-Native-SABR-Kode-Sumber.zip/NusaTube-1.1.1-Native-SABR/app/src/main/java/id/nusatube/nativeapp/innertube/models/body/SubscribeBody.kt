package id.nusatube.nativeapp.innertube.models.body

import id.nusatube.nativeapp.innertube.models.Context
import kotlinx.serialization.Serializable

@Serializable
data class SubscribeBody(
    val channelIds: List<String>,
    val context: Context,
)
