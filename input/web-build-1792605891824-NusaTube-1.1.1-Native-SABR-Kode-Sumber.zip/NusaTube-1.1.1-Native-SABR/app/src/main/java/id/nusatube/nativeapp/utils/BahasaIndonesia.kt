package id.nusatube.nativeapp.utils

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import java.util.Locale

/** Bahasa Indonesia also applies when the device language is English. */
object BahasaIndonesia {
    val locale: Locale = Locale.forLanguageTag("id-ID")

    fun wrap(base: Context): Context {
        Locale.setDefault(locale)
        val configuration = Configuration(base.resources.configuration).apply {
            setLocales(LocaleList(locale))
            setLayoutDirection(locale)
        }
        return base.createConfigurationContext(configuration)
    }
}
