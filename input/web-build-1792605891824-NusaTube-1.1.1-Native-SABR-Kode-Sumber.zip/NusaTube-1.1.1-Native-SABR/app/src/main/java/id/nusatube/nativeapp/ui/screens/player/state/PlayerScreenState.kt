package id.nusatube.nativeapp.ui.screens.player.state

import android.content.Context
import android.media.AudioManager
import androidx.compose.runtime.*
import id.nusatube.nativeapp.player.seekbarpreview.SeekbarPreviewThumbnailHelper
import id.nusatube.nativeapp.ui.components.SubtitleCue
import id.nusatube.nativeapp.ui.components.SubtitleStyle

class PlayerScreenState {
    // UI Visibility States
    var showControls by mutableStateOf(true)
    var isFullscreen by mutableStateOf(false)
    var isInPipMode by mutableStateOf(false)
    var lastInteractionTimestamp by mutableLongStateOf(System.currentTimeMillis())
    
    // Playback Position
    var currentPosition by mutableLongStateOf(0L)
    var bufferedPosition by mutableLongStateOf(0L)
    var duration by mutableLongStateOf(0L)
    
    // Dialog States
    var showQualitySelector by mutableStateOf(false)
    var showAudioTrackSelector by mutableStateOf(false)
    var showSubtitleSelector by mutableStateOf(false)
    var showSettingsMenu by mutableStateOf(false)
    var showDownloadDialog by mutableStateOf(false)
    var showPlaybackSpeedSelector by mutableStateOf(false)
    var showSubtitleStyleCustomizer by mutableStateOf(false)
    var showSleepTimerSheet by mutableStateOf(false)
    var showDlnaDialog by mutableStateOf(false)
    
    // Bottom Sheet States
    var showQuickActions by mutableStateOf(false)
    var showCommentsSheet by mutableStateOf(false)
    var showDescriptionSheet by mutableStateOf(false)
    var showChaptersSheet by mutableStateOf(false)
    var showPlaylistQueueSheet by mutableStateOf(false)
    
    // Comment Sorting
    var isTopComments by mutableStateOf(true)
    
    // Gesture States
    var brightnessLevel by mutableFloatStateOf(0.5f)
    var volumeLevel by mutableFloatStateOf(0.5f)
    var maxVolumeLevel by mutableFloatStateOf(2.0f) // Allow up to 200%
    var showBrightnessOverlay by mutableStateOf(false)
    var showVolumeOverlay by mutableStateOf(false)
    
    // Seek Animation States
    var showSeekForwardAnimation by mutableStateOf(false)
    var seekAccumulation by mutableIntStateOf(10)
    var lastSeekTime by mutableLongStateOf(0L)
    var showSeekBackAnimation by mutableStateOf(false)
    
    // Subtitle States
    var subtitlesEnabled by mutableStateOf(false)
    var currentSubtitles by mutableStateOf<List<SubtitleCue>>(emptyList())
    var selectedSubtitleUrl by mutableStateOf<String?>(null)
    var subtitleStyle by mutableStateOf(SubtitleStyle())
    
    // Video Display
    var resizeMode by mutableIntStateOf(0) // 0=Fit, 1=Fill, 2=Zoom

    // Pinch-to-Zoom State
    var zoomScale by mutableFloatStateOf(1f)
    var zoomOffsetX by mutableFloatStateOf(0f)
    var zoomOffsetY by mutableFloatStateOf(0f)

    // Speed Control
    var isSpeedBoostActive by mutableStateOf(false)
    var normalSpeed by mutableFloatStateOf(1.0f)
    
    // Shorts/Music Prompt
    var showShortsPrompt by mutableStateOf(false)
    var hasShownShortsPrompt by mutableStateOf(false)
    
    // Seekbar Preview
    var seekbarPreviewHelper by mutableStateOf<SeekbarPreviewThumbnailHelper?>(null)
   
    fun resetForNewVideo() {
        lastInteractionTimestamp = System.currentTimeMillis()
        showControls = true
        currentPosition = 0L
        duration = 0L
        subtitlesEnabled = false
        currentSubtitles = emptyList()
        selectedSubtitleUrl = null
        seekbarPreviewHelper = null
        showBrightnessOverlay = false
        showVolumeOverlay = false
        showSeekBackAnimation = false
        showSeekForwardAnimation = false
        hasShownShortsPrompt = false
        showShortsPrompt = false
        showPlaylistQueueSheet = false
        // Reset dialogs
        showDownloadDialog = false
        showQualitySelector = false
        showAudioTrackSelector = false
        showSubtitleSelector = false
        showSettingsMenu = false
        showPlaybackSpeedSelector = false
        showSubtitleStyleCustomizer = false
        showSleepTimerSheet = false
        showDlnaDialog = false
        // Reset bottom sheets
        showQuickActions = false
        showCommentsSheet = false
        showDescriptionSheet = false
        showChaptersSheet = false
        zoomScale = 1f
        zoomOffsetX = 0f
        zoomOffsetY = 0f
    }
    
    fun cycleResizeMode() {
        resizeMode = (resizeMode + 1) % 3
    }
    
    fun toggleFullscreen() {
        isFullscreen = !isFullscreen
    }
    
    fun enableSubtitles(url: String, subtitles: List<SubtitleCue>) {
        selectedSubtitleUrl = url
        currentSubtitles = subtitles
        subtitlesEnabled = subtitles.isNotEmpty()
    }
    
    fun disableSubtitles() {
        subtitlesEnabled = false
        selectedSubtitleUrl = null
        currentSubtitles = emptyList()
    }

    fun onInteraction() {
        lastInteractionTimestamp = System.currentTimeMillis()
    }
}

@Composable
fun rememberPlayerScreenState(): PlayerScreenState {
    return remember { PlayerScreenState() }
}

data class AudioSystemInfo(
    val audioManager: AudioManager,
    val maxVolume: Int
)

@Composable
fun rememberAudioSystemInfo(context: Context): AudioSystemInfo {
    return remember {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        AudioSystemInfo(
            audioManager = audioManager,
            maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        )
    }
}
