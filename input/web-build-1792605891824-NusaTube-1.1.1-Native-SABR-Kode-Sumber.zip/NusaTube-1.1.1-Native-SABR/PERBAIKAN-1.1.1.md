# NusaTube 1.1.1 Native SABR

Perbaikan atas versi 1.1.0:

- Shorts disembunyikan dari Beranda, pencarian beserta halaman lanjutannya, kanal, langganan, rekomendasi, dan daftar video playlist dari YouTube.
- Rak Shorts, tab Shorts pada kanal, menu Shorts tersimpan, pengaturan kualitas Shorts, dan ajakan membuka pemutar Shorts disembunyikan.
- Penyaringan memakai penanda `isShortFormContent` dari extractor serta URL `/shorts/`. Video biasa tidak disembunyikan hanya karena berdurasi pendek.
- Preferensi Shorts yang aktif pada pemasangan lama tidak mengaktifkan kembali rak atau navigasi Shorts setelah pembaruan.
- Latar tema gelap, header, kategori, footer, serta bilah sistem menggunakan hitam pekat `#000000`.
- Panah Kembali pada halaman kanal memakai warna teks tema yang terang. Warna konten bawaan juga mengikuti tema, termasuk judul kanal dan ikon.

Identitas pemasangan: `id.nusatube.nativeclient`, versionCode `101`, versionName `1.1.1-native-sabr`. Gunakan keystore dari cadangan tanda tangan 1.1.0 untuk memperbarui aplikasi yang sudah terpasang.

## Membangun APK

Kebutuhan: JDK 17, Android SDK platform 35, build-tools 34.0.0, dan koneksi untuk mengunduh dependensi. Gradle 8.9 disediakan melalui wrapper.

1. Salin `release.keystore` dan pengaturan tanda tangan dari cadangan ke folder utama proyek. Keystore dan kata sandi tidak disertakan dalam kode sumber.
2. Isi `sdk.dir` pada `local.properties` sesuai lokasi Android SDK komputer Anda.
3. Jalankan:

```bash
chmod +x gradlew
./gradlew clean :app:testNativeEngine :app:assembleFossRelease --no-daemon
```

APK berada di `app/build/outputs/apk/foss/release/`. Rangkaian `testNativeEngine` juga mencakup lima tes regresi penyaringan Shorts pada rilis ini.

Jangan menghapus aplikasi lama sebelum memasang pembaruan bila ingin mempertahankan data aplikasi.
