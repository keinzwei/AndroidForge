# Pedoman interaksi

Gunakan komunikasi yang sopan, bahas perubahan teknis secara terbuka, dan hormati privasi pengguna maupun kontributor.
