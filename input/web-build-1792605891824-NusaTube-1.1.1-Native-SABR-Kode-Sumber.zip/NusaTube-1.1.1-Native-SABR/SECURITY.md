# Pelaporan keamanan

Sampaikan laporan secara privat kepada pengelola salinan aplikasi ini. Jangan sertakan akun, token, cookie, atau keystore dalam laporan publik.
