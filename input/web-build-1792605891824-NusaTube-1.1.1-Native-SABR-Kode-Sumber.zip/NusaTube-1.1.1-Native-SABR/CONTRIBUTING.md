# Kontribusi

Gunakan JDK 17. Jalankan build dan `testNativeEngine` sebelum mengirim perubahan. Pertahankan pemberitahuan lisensi komponen dan jangan memasukkan keystore atau local.properties.
