# Dukungan NusaTube

Sertakan versi aplikasi, versi Android, langkah reproduksi, dan log masalah ketika melaporkan kendala kepada pengelola turunan ini.
