# Atribusi komponen NusaTube

NusaTube 1.1.0 merupakan turunan baru dari basis aplikasi dan mesin pemutar yang dilampirkan pengguna.
Header, footer, dan kategori diadaptasi dari NusaTube 1.0.6, yang mengatribusikan tata letaknya kepada Youtube-Clone-KMP 1.0.0 (KhubaibKhan4), AGPL-3.0.
Distribusi gabungan ini memakai AGPL-3.0; lisensi GPL-3.0 komponen asal tetap disertakan dalam `licenses/GPL-3.0.txt`.
Identitas produk telah diubah; nama dan tautan dalam atribusi di bawah adalah identitas historis pemilik komponen.

# Attribution and license notices

This distribution is a modified EchoTube build, not an official release from
EchoTube or Flow. The combined work is distributed under GNU GPL version 3;
the complete license text is retained in `License`.

## EchoTube

Source: https://github.com/brysonhwang/EchoTube

Original EchoTube project by its respective authors, including Aditya Yadav.
Existing notices, source headers, and the upstream README are preserved.
Base commit: `b6db862807a1692da37f529c2e978a13f4fbd449`.

## Flow

Source: https://github.com/Flow-Tube/Flow/tree/v3.0.0

Copyright (c) 2025-2026 A-EDev and contributors. GNU GPLv3.
Imported from release commit `9b592728f96de4efdb3b0041331bb3b44bfe054c`.
The native player extraction, SABR, protobuf/UMP, cipher and PoToken code is
adapted under `com.echotube.iad1tya.nativeflow`. Package names and integration
boundaries were changed for EchoTube; the relevant upstream headers are retained.
Native player HTTP transport is adapted from Flow's player/playerWeb request
bodies to use EchoTube's existing OkHttp stack.

Flow credits PipePipe for its SABR and InnerTube playback implementation and
documentation, and Metrolist for the cipher/PoToken implementation. Those
upstream attributions are preserved in copied source files.

- https://codeberg.org/NullPointerException/PipePipe
- https://github.com/MetrolistGroup/Metrolist
- https://github.com/TeamNewPipe/NewPipeExtractor
- https://github.com/androidx/media

Third-party dependencies retain their own licenses. This archive includes the
corresponding application source and build instructions for this modified build.
No upstream signing key, account credentials, or Firebase configuration is included.
