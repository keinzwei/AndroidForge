# Mesin pemutar NusaTube

Mesin Native InnerTube + SABR dari basis terlampir dipertahankan. Lapisan request, attestation, cipher, decoder SABR, buffer, pilihan kualitas, dan integrasi Media3 tetap digunakan. Pengaturan wilayah serta bahasa konteks permintaan disesuaikan ke Indonesia.

Suite `testNativeEngine` menguji protokol dan adapter tanpa mengikutkan tes UI upstream yang sudah tidak sesuai API. Sumber dan atribusi seluruh komponen dijelaskan dalam `THIRD-PARTY-NOTICES.md`.
